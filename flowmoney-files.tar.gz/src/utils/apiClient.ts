import { auth } from '../lib/firebase.ts';
import { useAuthStore } from '../store/useAuthStore.ts';

/**
 * Helper para realizar peticiones HTTP a la API del backend con manejo automático de sesión:
 * - Inyecta el token Bearer en los encabezados.
 * - Si la respuesta retorna status 401 (token expirado), fuerza la renovación del token con user.getIdToken(true).
 * - Reintenta la llamada UNA vez con el nuevo token.
 * - Si el reintento también falla o el token no se pudo renovar, muestra el mensaje
 *   "Tu sesión expiró, vuelve a iniciar sesión", limpia la sesión y redirige al login.
 */
export async function fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
  const store = useAuthStore.getState();
  const token = store.token;

  const buildHeaders = (t: string | null): Headers => {
    const headers = new Headers(options.headers || {});
    if (t && !headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${t}`);
    }
    return headers;
  };

  let res = await fetch(url, {
    ...options,
    headers: buildHeaders(token),
  });

  // Si recibimos status 401
  if (res.status === 401) {
    console.warn(`[fetchWithAuth] 401 recibido en ${url}. Intentando refresco forzado con user.getIdToken(true)...`);
    const user = auth.currentUser;
    let freshToken: string | null = null;

    if (user) {
      try {
        freshToken = await user.getIdToken(true);
        if (freshToken) {
          store.setToken(freshToken);
        }
      } catch (err) {
        console.error('[fetchWithAuth] Falló el refresco forzado de token:', err);
      }
    }

    if (freshToken) {
      // Reintentar la llamada UNA sola vez
      res = await fetch(url, {
        ...options,
        headers: buildHeaders(freshToken),
      });
    }

    // Si el reintento también falla (o no hubo token fresco)
    if (res.status === 401) {
      console.warn('[fetchWithAuth] Reintento falló con 401. Redirigiendo a pantalla de inicio de sesión...');
      await store.logout();
      useAuthStore.setState({ error: 'Tu sesión expiró, vuelve a iniciar sesión' });
      window.dispatchEvent(
        new CustomEvent('session_expired', {
          detail: { message: 'Tu sesión expiró, vuelve a iniciar sesión' },
        })
      );
    }
  }

  return res;
}
