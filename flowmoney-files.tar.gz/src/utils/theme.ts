export type ThemeMode = 'light' | 'dark' | 'system';

const THEME_STORAGE_KEY = 'flowmoney_theme_preference';

/**
 * Tokens del design system Apple (iOS).
 * Disponibles en CSS como variables (--ios-blue, etc.) y aquí para uso en TS.
 */
export const appleColors = {
  // System colors
  blue:    '#007AFF',
  indigo:  '#5856D6',
  purple:  '#AF52DE',
  pink:    '#FF2D55',
  red:     '#FF3B30',
  orange:  '#FF9500',
  yellow:  '#FFCC00',
  green:   '#34C759',
  mint:    '#00C7BE',
  teal:    '#30B0C7',
  cyan:    '#32ADE6',

  // Semantic
  label:        '#000000',
  secondaryLabel:  'rgba(60, 60, 67, 0.6)',
  tertiaryLabel: 'rgba(60, 60, 67, 0.3)',

  // Backgrounds (light)
  bgPrimary:    '#F2F2F7',
  bgSecondary:  '#FFFFFF',
  bgTertiary:   '#EFEFF4',
  bgElevated:   '#FFFFFF',

  // Backgrounds (dark)
  bgPrimaryDark:    '#000000',
  bgSecondaryDark:  '#1C1C1E',
  bgTertiaryDark:   '#2C2C2E',
  bgElevatedDark:   '#2C2C2E',
} as const;

/**
 * Aplica el tema a document.documentElement y retorna si el modo oscuro quedó activo.
 */
export function applyTheme(theme: ThemeMode): boolean {
  localStorage.setItem(THEME_STORAGE_KEY, theme);

  let isDark = false;
  if (theme === 'dark') {
    isDark = true;
  } else if (theme === 'light') {
    isDark = false;
  } else {
    isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  if (isDark) {
    document.documentElement.classList.add('dark');
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#000000');
  } else {
    document.documentElement.classList.remove('dark');
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#F2F2F7');
  }

  return isDark;
}

/**
 * Obtiene la preferencia actual almacenada o por defecto 'system'.
 */
export function getSavedTheme(): ThemeMode {
  const saved = localStorage.getItem(THEME_STORAGE_KEY) as ThemeMode | null;
  if (saved && ['light', 'dark', 'system'].includes(saved)) {
    return saved;
  }
  return 'system';
}

/**
 * Escucha cambios del sistema operativo si el usuario tiene seleccionado 'system'.
 */
export function initThemeListener(): () => void {
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  const handler = (e: MediaQueryListEvent) => {
    const currentPreference = getSavedTheme();
    if (currentPreference === 'system') {
      if (e.matches) {
        document.documentElement.classList.add('dark');
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#000000');
      } else {
        document.documentElement.classList.remove('dark');
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#F2F2F7');
      }
    }
  };

  applyTheme(getSavedTheme());
  mediaQuery.addEventListener('change', handler);
  return () => mediaQuery.removeEventListener('change', handler);
}

