/**
 * Constantes y utilidades centralizadas de monedas para FlowMoney
 * La moneda por defecto en toda la aplicación y demostraciones es PEN (Soles - S/.)
 */

export interface CurrencyInfo {
  code: string;
  symbol: string;
  name: string;
  label: string;
}

export const DEFAULT_CURRENCY = 'PEN';

export const SUPPORTED_CURRENCIES: CurrencyInfo[] = [
  { code: 'PEN', symbol: 'S/.', name: 'Sol Peruano', label: 'PEN (S/.) - Sol Peruano' },
  { code: 'USD', symbol: '$', name: 'Dólar Estadounidense', label: 'USD ($) - Dólar USA' },
  { code: 'EUR', symbol: '€', name: 'Euro', label: 'EUR (€) - Euro' },
  { code: 'MXN', symbol: '$', name: 'Peso Mexicano', label: 'MXN ($) - Peso Mexicano' },
  { code: 'COP', symbol: '$', name: 'Peso Colombiano', label: 'COP ($) - Peso Colombiano' },
  { code: 'ARS', symbol: '$', name: 'Peso Argentino', label: 'ARS ($) - Peso Argentino' },
  { code: 'CLP', symbol: '$', name: 'Peso Chileno', label: 'CLP ($) - Peso Chileno' },
  { code: 'BRL', symbol: 'R$', name: 'Real Brasileño', label: 'BRL (R$) - Real Brasileño' },
  { code: 'GBP', symbol: '£', name: 'Libra Esterlina', label: 'GBP (£) - Libra Esterlina' },
];

export const getCurrencySymbol = (code?: string): string => {
  if (!code) return 'S/.';
  const c = code.trim().toUpperCase();
  switch (c) {
    case 'PEN':
      return 'S/.';
    case 'EUR':
      return '€';
    case 'GBP':
      return '£';
    case 'BRL':
      return 'R$';
    case 'USD':
    case 'MXN':
    case 'COP':
    case 'ARS':
    case 'CLP':
    default:
      return '$';
  }
};

export const formatCurrencyAmount = (
  amount: number | string | undefined | null,
  currency: string = DEFAULT_CURRENCY
): string => {
  const num = Number(amount || 0);
  const symbol = getCurrencySymbol(currency);
  return `${symbol} ${num.toFixed(2)}`;
};
