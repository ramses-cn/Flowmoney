import { useEffect, useRef, useState, useCallback } from 'react';
import {
  collection,
  query,
  where,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { db, auth } from '../lib/firebase.ts';

export interface UseRealtimeSyncOptions {
  /** ID único de grupo o lista de IDs de grupo a monitorear */
  groupIds?: string | string[];
  /** Callback para volver a pedir los datos actualizados al backend */
  onRefresh: () => void | Promise<void>;
  /** Si la suscripción debe estar activa (ej: solo en lentes pareja/grupos o vista activa) */
  enabled?: boolean;
  /** Identificador para logs y depuración */
  label?: string;
  /** Intervalo en milisegundos para el polling de fallback (por defecto 30,000ms = 30s) */
  fallbackPollingIntervalMs?: number;
}

export interface UseRealtimeSyncResult {
  /** Indica si la conexión por Firestore onSnapshot está activa y saludable */
  isRealtimeActive: boolean;
  /** Indica si está activo el mecanismo de respaldo por polling de 30s */
  isPollingFallback: boolean;
  /** Timestamp del último evento en vivo recibido */
  lastEventAt: Date | null;
  /** Función para disparar manualmente un refresco inmediato */
  refreshNow: () => void;
}

/**
 * Hook para sincronización reactiva en tiempo real (Fase 5 FlowMoney)
 * Utiliza Firestore onSnapshot como bus de señalización de eventos ligeros.
 * Si la conexión falla, conmuta automáticamente a polling suave cada 30s.
 */
export function useRealtimeSync({
  groupIds,
  onRefresh,
  enabled = true,
  label = 'RealtimeSync',
  fallbackPollingIntervalMs = 30000,
}: UseRealtimeSyncOptions): UseRealtimeSyncResult {
  const [isRealtimeActive, setIsRealtimeActive] = useState<boolean>(false);
  const [isPollingFallback, setIsPollingFallback] = useState<boolean>(false);
  const [lastEventAt, setLastEventAt] = useState<Date | null>(null);

  // Mantener referencia al callback para evitar re-suscripciones innecesarias
  const refreshCallbackRef = useRef(onRefresh);
  refreshCallbackRef.current = onRefresh;

  // Debounce para agrupar múltiples eventos ráfaga en una sola recarga
  const refreshDebounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const triggerRefresh = useCallback(() => {
    if (refreshDebounceTimerRef.current) {
      clearTimeout(refreshDebounceTimerRef.current);
    }
    refreshDebounceTimerRef.current = setTimeout(() => {
      refreshCallbackRef.current();
    }, 300);
  }, []);

  useEffect(() => {
    if (!enabled) {
      setIsRealtimeActive(false);
      setIsPollingFallback(false);
      return;
    }

    // Normalizar IDs de grupo
    const rawIds = Array.isArray(groupIds) ? groupIds : groupIds ? [groupIds] : [];
    const validGroupIds = rawIds.filter((id): id is string => typeof id === 'string' && id.trim().length > 0);

    if (validGroupIds.length === 0) {
      setIsRealtimeActive(false);
      setIsPollingFallback(false);
      return;
    }

    let isMounted = true;
    let firestoreUnsubscribe: Unsubscribe | null = null;
    let pollingIntervalId: NodeJS.Timeout | null = null;

    // Función para activar el polling de fallback (cada 30s)
    const startFallbackPolling = (reason: string) => {
      if (!isMounted) return;
      console.warn(`[${label}] Activando fallback polling (cada ${fallbackPollingIntervalMs / 1000}s): ${reason}`);
      setIsRealtimeActive(false);
      setIsPollingFallback(true);

      if (!pollingIntervalId) {
        pollingIntervalId = setInterval(() => {
          if (isMounted) {
            refreshCallbackRef.current();
          }
        }, fallbackPollingIntervalMs);
      }
    };

    // Función para conectar el listener de Firestore
    const subscribeToFirestore = () => {
      try {
        if (!db) {
          startFallbackPolling('Instancia de Firestore db no disponible');
          return;
        }

        // Construir query de Firestore filtrando por los grupos especificados
        let q;
        if (validGroupIds.length === 1) {
          q = query(collection(db, 'events'), where('group_id', '==', validGroupIds[0]));
        } else if (validGroupIds.length <= 30) {
          q = query(collection(db, 'events'), where('group_id', 'in', validGroupIds));
        } else {
          // Firestore limita a 30 elementos en cláusula 'in'
          q = query(collection(db, 'events'), where('group_id', 'in', validGroupIds.slice(0, 30)));
        }

        let isInitialSnapshot = true;

        firestoreUnsubscribe = onSnapshot(
          q,
          (snapshot) => {
            if (!isMounted) return;

            setIsRealtimeActive(true);
            setIsPollingFallback(false);

            // Detener polling de respaldo si estaba activo al recuperarse la conexión
            if (pollingIntervalId) {
              clearInterval(pollingIntervalId);
              pollingIntervalId = null;
            }

            // Ignorar los documentos preexistentes en la primera lectura inicial
            if (isInitialSnapshot) {
              isInitialSnapshot = false;
              return;
            }

            // Comprobar si hay documentos nuevos añadidos
            const newEvents = snapshot.docChanges().filter((change) => change.type === 'added');
            if (newEvents.length > 0) {
              setLastEventAt(new Date());
              console.log(
                `[${label}] Evento en vivo detectado (${newEvents.length} cambios). Refrescando datos de Cloud SQL...`
              );
              triggerRefresh();
            }
          },
          (error) => {
            if (!isMounted) return;
            startFallbackPolling(error.message || 'Error en stream de Firestore');
          }
        );
      } catch (err: any) {
        startFallbackPolling(err.message || 'Error inesperado al inicializar Firestore');
      }
    };

    // Si Firebase Auth aún está inicializando, esperar estado de usuario
    if (auth.currentUser) {
      subscribeToFirestore();
    } else {
      const authUnsub = onAuthStateChanged(auth, (user) => {
        authUnsub();
        if (isMounted) {
          if (user) {
            subscribeToFirestore();
          } else {
            // Usuario sin sesión de Firebase activa, usar fallback
            startFallbackPolling('Usuario no autenticado en Firebase client');
          }
        }
      });
    }

    return () => {
      isMounted = false;
      if (firestoreUnsubscribe) {
        try {
          firestoreUnsubscribe();
        } catch (_) {}
      }
      if (pollingIntervalId) {
        clearInterval(pollingIntervalId);
      }
      if (refreshDebounceTimerRef.current) {
        clearTimeout(refreshDebounceTimerRef.current);
      }
    };
  }, [
    enabled,
    JSON.stringify(groupIds),
    label,
    fallbackPollingIntervalMs,
    triggerRefresh,
  ]);

  return {
    isRealtimeActive,
    isPollingFallback,
    lastEventAt,
    refreshNow: triggerRefresh,
  };
}
