import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  sendSignInLinkToEmail,
  isSignInWithEmailLink,
  signInWithEmailLink,
  signOut,
  onAuthStateChanged,
  onIdTokenChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { getFirestore } from 'firebase/firestore';

// Importar configuración de Firebase generada para el applet
import configData from '../../firebase-applet-config.json';

const firebaseConfig = {
  apiKey: configData.apiKey || import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: configData.authDomain || `${configData.projectId}.firebaseapp.com`,
  projectId: configData.projectId,
  storageBucket: configData.storageBucket || `${configData.projectId}.appspot.com`,
  messagingSenderId: configData.messagingSenderId,
  appId: configData.appId,
};

// Inicialización singleton
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const db = getFirestore(app, configData.firestoreDatabaseId);

/**
 * Subida de avatar de perfil a Firebase Storage (con fallback seguro en base64)
 */
export async function uploadAvatarImage(file: File, uid: string): Promise<string> {
  try {
    const filename = `avatars/${uid}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const storageRef = ref(storage, filename);
    const snapshot = await uploadBytes(storageRef, file);
    return await getDownloadURL(snapshot.ref);
  } catch (error) {
    console.warn('[Firebase Storage] Usando data URL local para avatar:', error);
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}

/**
 * Subida de foto de ticket / recibo a Firebase Storage (con fallback seguro en base64)
 */
export async function uploadReceiptImage(file: File, uid: string): Promise<string> {
  try {
    const filename = `receipts/${uid}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const storageRef = ref(storage, filename);
    const snapshot = await uploadBytes(storageRef, file);
    return await getDownloadURL(snapshot.ref);
  } catch (error) {
    console.warn('[Firebase Storage] Usando data URL local para comprobante:', error);
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}

// Proveedor de Google
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

/**
 * Inicio de sesión mediante Google Popup
 */
export async function loginWithGoogle(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

/**
 * Envío de enlace de acceso seguro por correo (Email Link / Passwordless)
 */
export async function sendEmailLoginLink(email: string): Promise<void> {
  const actionCodeSettings = {
    url: window.location.origin + window.location.pathname,
    handleCodeInApp: true,
  };

  await sendSignInLinkToEmail(auth, email, actionCodeSettings);
  window.localStorage.setItem('emailForSignIn', email);
}

/**
 * Completar inicio de sesión cuando el usuario llega mediante el enlace de correo
 */
export async function completeEmailLogin(): Promise<FirebaseUser | null> {
  if (isSignInWithEmailLink(auth, window.location.href)) {
    let email = window.localStorage.getItem('emailForSignIn');
    if (!email) {
      email = window.prompt('Por favor ingresa tu correo para confirmar el acceso:');
    }
    if (email) {
      const result = await signInWithEmailLink(auth, email, window.location.href);
      window.localStorage.removeItem('emailForSignIn');
      return result.user;
    }
  }
  return null;
}

/**
 * Cerrar sesión
 */
export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

export { onAuthStateChanged, onIdTokenChanged };
export type { FirebaseUser };
