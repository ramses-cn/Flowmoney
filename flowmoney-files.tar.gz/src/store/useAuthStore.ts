import { create } from 'zustand';
import {
  auth,
  loginWithGoogle as fbLoginWithGoogle,
  sendEmailLoginLink as fbSendEmailLoginLink,
  completeEmailLogin as fbCompleteEmailLogin,
  logoutUser as fbLogoutUser,
  onAuthStateChanged,
  onIdTokenChanged,
  FirebaseUser,
} from '../lib/firebase.ts';
import { Profile, Category, Account } from '../types/flowmoney.ts';
import { DEFAULT_CURRENCY } from '../constants/currencies.ts';

interface AuthState {
  firebaseUser: FirebaseUser | null;
  profile: Profile | null;
  categories: Category[];
  accounts: Account[];
  token: string | null;
  isLoading: boolean;
  isInitialized: boolean;
  isDemoSession: boolean;
  error: string | null;

  // Acciones
  initializeAuth: () => () => void;
  syncBackendProfile: (user: FirebaseUser, idToken: string) => Promise<Profile | null>;
  loginWithGoogle: () => Promise<void>;
  sendEmailLink: (email: string) => Promise<void>;
  checkEmailLinkCallback: () => Promise<boolean>;
  loginAsDemoUser: (demoUid?: string, name?: string) => Promise<void>;
  logout: () => Promise<void>;
  deleteMyAccount: () => Promise<{ success: boolean; message?: string; groupsWithBalance?: Array<{ id: string; name: string; balance: number }> }>;
  resetUserData: () => Promise<boolean>;
  clearError: () => void;
  setToken: (token: string | null) => void;
  forceRefreshToken: (force?: boolean) => Promise<string | null>;
  setProfile: (profile: Profile) => void;
  updateAccountBalance: (accountId: string, newBalance: number) => void;
  updateProfileData: (updates: { full_name?: string; avatar_url?: string; default_currency?: string; theme?: 'light' | 'dark' | 'system' }) => Promise<Profile | null>;
  addAccount: (acc: { name: string; type: string; currency: string; current_balance: number; color: string }) => Promise<Account | null>;
  deleteAccount: (accountId: string) => Promise<boolean>;
  updateCategoryBudget: (categoryId: string, monthly_budget: number) => Promise<boolean>;
  toggleCategoryActive: (categoryId: string, is_active: boolean) => Promise<boolean>;
  addCustomCategory: (cat: { name: string; icon?: string; color?: string; type?: 'expense' | 'income'; monthly_budget?: number }) => Promise<Category | null>;
  updateCategory: (categoryId: string, updates: { name?: string; icon?: string; color?: string; monthly_budget?: number }) => Promise<Category | null>;
  deleteCustomCategory: (categoryId: string) => Promise<{ success: boolean; wasDeactivated?: boolean; message?: string }>;
  reorderCategories: (orderedIds: string[]) => Promise<boolean>;
  fetchAllCategories: () => Promise<Category[]>;
  fetchAccounts: () => Promise<void>;
  fetchCategories: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  firebaseUser: null,
  profile: null,
  categories: [],
  accounts: [],
  token: null,
  isLoading: true,
  isInitialized: false,
  isDemoSession: false,
  error: null,

  clearError: () => set({ error: null }),

  setProfile: (profile: Profile) => set({ profile }),

  updateAccountBalance: (accountId: string, newBalance: number) => {
    set((state) => ({
      accounts: state.accounts.map((acc) =>
        acc.id === accountId ? { ...acc, current_balance: newBalance } : acc
      ),
    }));
  },

  updateProfileData: async (updates) => {
    const token = get().token;
    if (!token) return null;
    try {
      const res = await fetch('/api/profile/me', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      if (!res.ok) {
        throw new Error('Error actualizando perfil');
      }
      const data = await res.json();
      if (data.profile) {
        set({ profile: data.profile });
        return data.profile;
      }
      return null;
    } catch (err: any) {
      console.error('[AuthStore] Error en updateProfileData:', err);
      return null;
    }
  },

  addAccount: async (accData) => {
    const token = get().token;
    if (!token) return null;
    try {
      const res = await fetch('/api/accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(accData),
      });
      if (!res.ok) throw new Error('Error creando cuenta');
      const data = await res.json();
      if (data.account) {
        set((state) => ({ accounts: [...state.accounts, data.account] }));
        return data.account;
      }
      return null;
    } catch (err) {
      console.error('[AuthStore] Error en addAccount:', err);
      return null;
    }
  },

  deleteAccount: async (accountId: string) => {
    const token = get().token;
    if (!token) return false;
    try {
      const res = await fetch(`/api/accounts/${accountId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.ok) {
        set((state) => ({
          accounts: state.accounts.filter((a) => a.id !== accountId),
        }));
        return true;
      }
      return false;
    } catch (err) {
      console.error('[AuthStore] Error en deleteAccount:', err);
      return false;
    }
  },

  updateCategoryBudget: async (categoryId: string, monthly_budget: number) => {
    const token = get().token;
    if (!token) return false;
    try {
      const res = await fetch(`/api/categories/${categoryId}/budget`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ monthly_budget }),
      });
      if (res.ok) {
        set((state) => ({
          categories: state.categories.map((c) =>
            c.id === categoryId ? { ...c, monthly_budget } : c
          ),
        }));
        return true;
      }
      return false;
    } catch (err) {
      console.error('[AuthStore] Error en updateCategoryBudget:', err);
      return false;
    }
  },

  toggleCategoryActive: async (categoryId: string, is_active: boolean) => {
    const token = get().token;
    if (!token) return false;
    try {
      const res = await fetch(`/api/categories/${categoryId}/toggle`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ is_active }),
      });
      if (res.ok) {
        // Actualizar la lista en el store: si se desactiva, lo quitamos de categories (que solo tiene activas)
        // o si queremos actualizar su estado local:
        if (is_active) {
          // Volver a consultar las categorías activas
          await get().fetchCategories();
        } else {
          set((state) => ({
            categories: state.categories.filter((c) => c.id !== categoryId),
          }));
        }
        return true;
      }
      return false;
    } catch (err) {
      console.error('[AuthStore] Error en toggleCategoryActive:', err);
      return false;
    }
  },

  addCustomCategory: async (catData) => {
    const token = get().token;
    if (!token) return null;
    try {
      const res = await fetch('/api/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(catData),
      });
      if (!res.ok) throw new Error('Error al crear categoría');
      const data = await res.json();
      if (data.category) {
        set((state) => ({ categories: [...state.categories, data.category] }));
        return data.category;
      }
      return null;
    } catch (err) {
      console.error('[AuthStore] Error en addCustomCategory:', err);
      return null;
    }
  },

  updateCategory: async (categoryId, updates) => {
    const token = get().token;
    if (!token) return null;
    try {
      const res = await fetch(`/api/categories/${categoryId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error('Error al actualizar categoría');
      const data = await res.json();
      if (data.category) {
        set((state) => ({
          categories: state.categories.map((c) =>
            c.id === categoryId ? { ...c, ...data.category } : c
          ),
        }));
        return data.category;
      }
      return null;
    } catch (err) {
      console.error('[AuthStore] Error en updateCategory:', err);
      return null;
    }
  },

  deleteCustomCategory: async (categoryId) => {
    const token = get().token;
    if (!token) return { success: false };
    try {
      const res = await fetch(`/api/categories/${categoryId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        set((state) => ({
          categories: state.categories.filter((c) => c.id !== categoryId),
        }));
        return { success: true, wasDeactivated: data.wasDeactivated, message: data.message };
      }
      return { success: false, message: data.error };
    } catch (err) {
      console.error('[AuthStore] Error en deleteCustomCategory:', err);
      return { success: false };
    }
  },

  reorderCategories: async (orderedIds: string[]) => {
    const token = get().token;
    if (!token) return false;
    try {
      // Optimistic update
      set((state) => {
        const catMap = new Map(state.categories.map((c) => [c.id, c]));
        const reordered = orderedIds.map((id) => catMap.get(id)).filter(Boolean) as Category[];
        // Agregar las que no estén en orderedIds al final
        const remaining = state.categories.filter((c) => !orderedIds.includes(c.id));
        return { categories: [...reordered, ...remaining] };
      });

      const res = await fetch('/api/categories/reorder', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ orderedIds }),
      });
      return res.ok;
    } catch (err) {
      console.error('[AuthStore] Error en reorderCategories:', err);
      return false;
    }
  },

  fetchAllCategories: async () => {
    const token = get().token;
    if (!token) return [];
    try {
      const res = await fetch('/api/categories?all=true', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        return data.categories || [];
      }
      return [];
    } catch (err) {
      console.error('[AuthStore] Error en fetchAllCategories:', err);
      return [];
    }
  },

  fetchAccounts: async () => {
    const token = get().token;
    if (!token) return;
    try {
      const res = await fetch('/api/accounts', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        set({ accounts: data.accounts || [] });
      }
    } catch (err) {
      console.error('[AuthStore] Error en fetchAccounts:', err);
    }
  },

  fetchCategories: async () => {
    const token = get().token;
    if (!token) return;
    try {
      const res = await fetch('/api/categories', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        set({ categories: data.categories || [] });
      }
    } catch (err) {
      console.error('[AuthStore] Error en fetchCategories:', err);
    }
  },

  /**
   * Sincroniza el usuario autenticado con PostgreSQL (Cloud SQL) llamando a /api/profile/upsert
   */
  syncBackendProfile: async (user: FirebaseUser, idToken: string) => {
    const maxRetries = 2;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const response = await fetch('/api/profile/upsert', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${idToken}`,
          },
          body: JSON.stringify({
            full_name: user.displayName || (user.email ? user.email.split('@')[0] : 'Usuario FlowMoney'),
            avatar_url: user.photoURL || undefined,
            default_currency: DEFAULT_CURRENCY,
          }),
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          let errMsg = errData.message || errData.error || 'Error al sincronizar con el backend';
          if (errMsg.toLowerCase().includes('cloud sql')) {
            errMsg = 'Error de conexión. Reintentando sincronización...';
          }

          if (response.status === 401) {
            set({
              firebaseUser: null,
              token: null,
              profile: null,
              isLoading: false,
              isInitialized: true,
              isDemoSession: false,
              error: errMsg,
            });
            return null;
          }

          throw new Error(errMsg);
        }

        const result = await response.json();
        const profileData: Profile = result.data.profile;
        const categories: Category[] = result.data.categories || [];
        const accounts: Account[] = result.data.accounts || [];

        const isDemo = idToken.startsWith('demo-token-') || user.uid.startsWith('demo_');

        // Corregido (F3): Token ahora en sessionStorage en lugar de localStorage.
        // sessionStorage se limpia al cerrar la pestaña, reduciendo la ventana de
        // exposición a ataques XSS persistentes. El token sigue siendo necesario
        // para que el usuario no tenga que re-loguear al recargar la página.
        // Para una migración completa a cookies httpOnly se requiere rediseñar
        // la auth con un endpoint /api/auth/session que emita cookies.
        try {
          sessionStorage.setItem('flowmoney_token', idToken);
        } catch (e) {
          // Fallback if sessionStorage blocked (private mode)
        }

        set({
          firebaseUser: user,
          token: idToken,
          profile: profileData,
          categories,
          accounts,
          isLoading: false,
          isInitialized: true,
          isDemoSession: isDemo,
          error: null,
        });

        return profileData;
      } catch (err: any) {
        if (attempt < maxRetries && (err.name === 'TypeError' || err.message?.includes('Failed to fetch'))) {
          await new Promise((r) => setTimeout(r, 800));
          continue;
        }
        console.error('[AuthStore] Error en syncBackendProfile:', err);
        
        // Si el usuario está autenticado con Firebase pero la API falló temporalmente,
        // generar perfil local resiliente para no bloquear el acceso al usuario
        if (user && user.uid) {
          const fallbackProfile: Profile = {
            id: user.uid,
            email: user.email || '',
            full_name: user.displayName || (user.email ? user.email.split('@')[0] : 'Usuario FlowMoney'),
            avatar_url: user.photoURL || undefined,
            default_currency: DEFAULT_CURRENCY,
            theme: 'system',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };
          const fallbackAccounts: Account[] = [
            {
              id: `acc_main_${user.uid.slice(0, 8)}`,
              user_id: user.uid,
              name: 'Cuenta Principal',
              type: 'checking',
              currency: DEFAULT_CURRENCY,
              current_balance: 0,
              color: '#4F46E5',
              is_archived: false,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            },
          ];

          set({
            firebaseUser: user,
            token: idToken,
            profile: fallbackProfile,
            categories: [],
            accounts: fallbackAccounts,
            isLoading: false,
            isInitialized: true,
            error: null,
          });

          return fallbackProfile;
        }

        set({ error: err.message, isLoading: false, isInitialized: true });
        return null;
      }
    }
    return null;
  },

  /**
   * Iniciar sesión con Google OAuth
   */
  loginWithGoogle: async () => {
    set({ isLoading: true, error: null });
    try {
      const user = await fbLoginWithGoogle();
      const idToken = await user.getIdToken();
      await get().syncBackendProfile(user, idToken);
    } catch (err: any) {
      console.error('[AuthStore] Error en loginWithGoogle:', err);
      // Mensaje amigable si el usuario cerró el popup
      if (err.code === 'auth/popup-closed-by-user') {
        set({ isLoading: false, error: 'Inicio de sesión cancelado por el usuario.' });
      } else if (err.code === 'auth/popup-blocked') {
        set({
          isLoading: false,
          error: 'El navegador bloqueó la ventana emergente. Habilita popups o utiliza el modo demo.',
        });
      } else {
        set({ isLoading: false, error: err.message || 'Fallo al autenticar con Google.' });
      }
      throw err;
    }
  },

  /**
   * Enviar enlace de autenticación por email (Passwordless)
   */
  sendEmailLink: async (email: string) => {
    set({ isLoading: true, error: null });
    try {
      await fbSendEmailLoginLink(email);
      set({ isLoading: false });
    } catch (err: any) {
      console.error('[AuthStore] Error en sendEmailLink:', err);
      set({ isLoading: false, error: err.message || 'Error al enviar el enlace de acceso' });
      throw err;
    }
  },

  /**
   * Verificar si la URL actual proviene de un enlace por correo
   */
  checkEmailLinkCallback: async () => {
    try {
      const user = await fbCompleteEmailLogin();
      if (user) {
        const idToken = await user.getIdToken();
        await get().syncBackendProfile(user, idToken);
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('[AuthStore] Error en checkEmailLinkCallback:', err);
      set({ error: err.message || 'Enlace inválido o expirado' });
      return false;
    }
  },

  /**
   * Inicio de sesión rápido para Modo Demostración
   */
  loginAsDemoUser: async (demoUid = 'demo_user_123', name = 'Carlos Sandoval') => {
    set({ isLoading: true, error: null });
    try {
      const safeUid = demoUid.startsWith('demo_') ? demoUid : `demo_${demoUid}`;
      const demoToken = `demo-token-${safeUid}`;
      const fakeFirebaseUser = {
        uid: safeUid,
        email: `${safeUid}@flowmoney.app`,
        displayName: name,
        photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
        getIdToken: async () => demoToken,
      } as unknown as FirebaseUser;

      await get().syncBackendProfile(fakeFirebaseUser, demoToken);
    } catch (err: any) {
      set({ isLoading: false, error: err.message });
    }
  },

  /**
   * Cerrar sesión activa
   */
  logout: async () => {
    try {
      await fbLogoutUser();
    } catch (err) {
      console.warn('Logout Firebase error:', err);
    }
    try {
      sessionStorage.removeItem('flowmoney_token');
    } catch (e) {}
    set({
      firebaseUser: null,
      profile: null,
      categories: [],
      accounts: [],
      token: null,
      isLoading: false,
      isDemoSession: false,
      error: null,
    });
  },

  /**
   * Eliminar la cuenta del usuario y todos sus datos asociados
   */
  deleteMyAccount: async () => {
    const token = get().token;
    if (!token) return { success: false, message: 'No hay sesión activa' };
    set({ isLoading: true, error: null });
    try {
      const res = await fetch('/api/profile/me', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const errorMsg = data.message || data.error || 'Error al eliminar la cuenta';
        set({ isLoading: false, error: errorMsg });
        return {
          success: false,
          message: errorMsg,
          groupsWithBalance: data.groupsWithBalance || [],
        };
      }
      await get().logout();
      return { success: true, message: data.message };
    } catch (err: any) {
      console.error('[AuthStore] Error en deleteMyAccount:', err);
      set({ isLoading: false, error: err.message });
      return { success: false, message: err.message || 'Error de conexión al eliminar la cuenta' };
    }
  },

  /**
   * Reiniciar todos los registros y transacciones del usuario a 0
   * Establece moneda Soles (PEN) y limpia deudas, gastos, grupos y suscripciones.
   */
  resetUserData: async () => {
    const token = get().token;
    if (!token) return false;
    set({ isLoading: true, error: null });
    try {
      const res = await fetch('/api/profile/reset-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || err.error || 'Error al reiniciar los registros');
      }
      const data = await res.json();
      if (data.profile) {
        set({
          profile: data.profile,
          accounts: data.accounts || [],
          categories: data.categories || [],
          isLoading: false,
        });
      } else {
        await get().fetchAccounts();
        await get().fetchCategories();
        set({ isLoading: false });
      }
      return true;
    } catch (err: any) {
      console.error('[AuthStore] Error en resetUserData:', err);
      set({ isLoading: false, error: err.message });
      return false;
    }
  },

  setToken: (token: string | null) => {
    set({ token });
  },

  forceRefreshToken: async (force: boolean = true) => {
    const user = auth.currentUser || get().firebaseUser;
    if (!user) {
      if (get().isDemoSession) return get().token;
      return null;
    }
    try {
      const refreshedToken = await user.getIdToken(force);
      set({ token: refreshedToken });
      return refreshedToken;
    } catch (err) {
      console.error('[AuthStore] Error forzando refresh de token:', err);
      return null;
    }
  },

  /**
   * Inicializar el observador de estado de Firebase
   * - onAuthStateChanged: maneja inicio/cierre de sesión
   * - onIdTokenChanged: actualiza el token guardado en el store cuando Firebase lo refresca automáticamente
   */
  initializeAuth: () => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const idToken = await user.getIdToken();
          await get().syncBackendProfile(user, idToken);
        } catch (err) {
          console.error('[AuthStore] Error obteniendo token onAuthStateChanged:', err);
          set({ isLoading: false, isInitialized: true });
        }
      } else {
        // Solo limpiar si no estábamos en un token de demo local
        const currentToken = get().token;
        if (!currentToken?.startsWith('demo-token-')) {
          set({
            firebaseUser: null,
            profile: null,
            categories: [],
            accounts: [],
            token: null,
            isLoading: false,
            isInitialized: true,
          });
        } else {
          set({ isLoading: false, isInitialized: true });
        }
      }
    });

    // Listener para refresco automático de token por Firebase SDK (cada hora o renovación)
    const unsubscribeToken = onIdTokenChanged(auth, async (user) => {
      if (user) {
        try {
          const freshToken = await user.getIdToken();
          const currentToken = get().token;
          if (freshToken && freshToken !== currentToken && !get().isDemoSession) {
            set({ token: freshToken });
          }
        } catch (err) {
          console.error('[AuthStore] Error en onIdTokenChanged:', err);
        }
      }
    });

    return () => {
      unsubscribeAuth();
      unsubscribeToken();
    };
  },
}));
