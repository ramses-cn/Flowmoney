/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Expense } from '../types/flowmoney.ts';

interface CategoryBreakdownBarProps {
  expenses: Expense[];
  currency: string;
  formatMoney: (amount: number, currency: string) => string;
}

const CATEGORY_COLORS: Record<string, { bg: string; bar: string; text: string }> = {
  Comida: { bg: 'bg-amber-100', bar: 'bg-amber-500', text: 'text-amber-800' },
  Transporte: { bg: 'bg-blue-100', bar: 'bg-blue-500', text: 'text-blue-800' },
  Alojamiento: { bg: 'bg-purple-100', bar: 'bg-purple-500', text: 'text-purple-800' },
  Entretenimiento: { bg: 'bg-pink-100', bar: 'bg-pink-500', text: 'text-pink-800' },
  Servicios: { bg: 'bg-emerald-100', bar: 'bg-emerald-500', text: 'text-emerald-800' },
  General: { bg: 'bg-slate-100', bar: 'bg-slate-500', text: 'text-slate-800' },
  Otros: { bg: 'bg-slate-100', bar: 'bg-slate-500', text: 'text-slate-800' }
};

export const CategoryBreakdownBar: React.FC<CategoryBreakdownBarProps> = ({
  expenses,
  currency,
  formatMoney
}) => {
  if (expenses.length === 0) return null;

  // Calcular totales por categoría
  const totals: Record<string, number> = {};
  let grandTotal = 0;

  expenses.forEach(e => {
    const cat = (e as any).categoria || e.category_name || 'Otros';
    const amount = Number((e as any).monto_equivalente_moneda_dominante || (e as any).monto_total || e.amount || 0);
    totals[cat] = (totals[cat] || 0) + amount;
    grandTotal += amount;
  });

  if (grandTotal === 0) return null;

  // Ordenar de mayor a menor gasto
  const sortedCategories = Object.entries(totals)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5); // top 5

  return (
    <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80 mb-6" id="category-breakdown-card">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-black text-slate-800">Distribución de Gastos por Categoría</span>
          <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-0.5 rounded-full">
            Sin Muro de Pago
          </span>
        </div>
        <span className="text-xs font-bold text-slate-500">
          Total: <span className="text-slate-900 font-black">{formatMoney(grandTotal, currency)}</span>
        </span>
      </div>

      {/* Barra segmentada horizontal */}
      <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex mb-3">
        {sortedCategories.map(([cat, amount]) => {
          const pct = (amount / grandTotal) * 100;
          const styling = CATEGORY_COLORS[cat] || CATEGORY_COLORS.Otros;
          return (
            <div
              key={cat}
              className={`${styling.bar} transition-all duration-500`}
              style={{ width: `${pct}%` }}
              title={`${cat}: ${pct.toFixed(1)}%`}
            />
          );
        })}
      </div>

      {/* Leyenda y detalles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-xs">
        {sortedCategories.map(([cat, amount]) => {
          const pct = (amount / grandTotal) * 100;
          const styling = CATEGORY_COLORS[cat] || CATEGORY_COLORS.Otros;
          return (
            <div key={cat} className="p-2 bg-slate-50 rounded-2xl border border-slate-200/60">
              <div className="flex items-center gap-1.5 mb-1">
                <span className={`w-2 h-2 rounded-full ${styling.bar}`} />
                <span className="font-bold text-slate-700 truncate text-[11px]">{cat}</span>
              </div>
              <p className="font-mono font-black text-slate-900 text-xs">
                {formatMoney(amount, currency)}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">
                {pct.toFixed(1)}%
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
