/**
 * AppleDesignShowcase — Componente demostración del design system Apple
 * ============================================================
 * Muestra todos los elementos del design system en una sola pantalla.
 * Útil para validar visualmente antes de producción.
 */
import React, { useState } from 'react';
import {
  User, Users, Heart, Receipt, Bell, Check, ChevronRight,
  AlertCircle, AlertTriangle, Info, Sparkles, Plus, Settings,
  TrendingUp, TrendingDown, Wallet, CreditCard, PiggyBank,
} from 'lucide-react';
import { motion } from 'motion/react';
import { appleColors } from '../utils/theme.ts';

export const AppleDesignShowcase: React.FC = () => {
  const [selectedSegment, setSelectedSegment] = useState<'personal' | 'couple' | 'group'>('personal');
  const [toggleOn, setToggleOn] = useState(true);

  return (
    <div
      className="min-h-screen px-6 py-8 safe-area-top safe-area-bottom"
      style={{ background: 'var(--ios-bg-primary)', color: 'var(--ios-label)' }}
    >
      <div className="max-w-md mx-auto space-y-8">
        {/* Large title */}
        <div className="animate-fade-in">
          <h1 className="large-title">Diseño Apple</h1>
          <p className="text-[17px] mt-1" style={{ color: 'var(--ios-label-secondary)' }}>
            Sistema de diseño FlowMoney · iOS 17 inspired
          </p>
        </div>

        {/* Apple colors palette */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Paleta iOS
          </h2>
          <div className="grid grid-cols-4 gap-2">
            {[
              { name: 'Blue', color: appleColors.blue },
              { name: 'Indigo', color: appleColors.indigo },
              { name: 'Purple', color: appleColors.purple },
              { name: 'Pink', color: appleColors.pink },
              { name: 'Red', color: appleColors.red },
              { name: 'Orange', color: appleColors.orange },
              { name: 'Yellow', color: appleColors.yellow },
              { name: 'Green', color: appleColors.green },
              { name: 'Mint', color: appleColors.mint },
              { name: 'Teal', color: appleColors.teal },
              { name: 'Cyan', color: appleColors.cyan },
            ].map((c) => (
              <div key={c.name} className="flex flex-col items-center gap-1.5">
                <div
                  className="w-full aspect-square rounded-[10px]"
                  style={{
                    background: c.color,
                    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)'
                  }}
                />
                <span className="text-[10px] font-medium" style={{ color: 'var(--ios-label-secondary)' }}>
                  {c.name}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Segmented control */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Segmented Control
          </h2>
          <div className="segmented-control w-full">
            <button
              onClick={() => setSelectedSegment('personal')}
              className="segmented-control-item flex-1 flex items-center justify-center gap-1.5"
              style={{
                color: selectedSegment === 'personal' ? 'var(--ios-blue)' : 'var(--ios-label-secondary)',
                fontWeight: selectedSegment === 'personal' ? 600 : 500
              }}
            >
              <User className="w-3.5 h-3.5" />
              Personal
            </button>
            <button
              onClick={() => setSelectedSegment('couple')}
              className="segmented-control-item flex-1 flex items-center justify-center gap-1.5"
              style={{
                color: selectedSegment === 'couple' ? 'var(--ios-pink)' : 'var(--ios-label-secondary)',
                fontWeight: selectedSegment === 'couple' ? 600 : 500
              }}
            >
              <Heart className="w-3.5 h-3.5" />
              Pareja
            </button>
            <button
              onClick={() => setSelectedSegment('group')}
              className="segmented-control-item flex-1 flex items-center justify-center gap-1.5"
              style={{
                color: selectedSegment === 'group' ? 'var(--ios-green)' : 'var(--ios-label-secondary)',
                fontWeight: selectedSegment === 'group' ? 600 : 500
              }}
            >
              <Users className="w-3.5 h-3.5" />
              Grupo
            </button>
            <motion.div
              layoutId="showcaseSegmented"
              className="segmented-control-thumb"
              style={{
                top: 2, bottom: 2,
                left: selectedSegment === 'personal' ? 2 : selectedSegment === 'couple' ? '33.33%' : '66.66%',
                width: '33.33%',
              }}
              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
            />
          </div>
        </section>

        {/* Balance hero card */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Hero Card
          </h2>
          <div
            className="rounded-[20px] p-6 relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #007AFF 0%, #5856D6 50%, #AF52DE 100%)',
              boxShadow: '0 12px 32px rgba(0, 122, 255, 0.25), 0 4px 12px rgba(88, 86, 214, 0.15)'
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-white/80">
                <Wallet className="w-4 h-4" />
                <span className="text-[12px] font-medium tracking-tight uppercase">Balance Total</span>
              </div>
              <Sparkles className="w-4 h-4 text-white/70" />
            </div>
            <div className="text-white">
              <div className="text-[34px] font-bold tracking-tight tabular-nums" style={{ letterSpacing: '-0.022em' }}>
                S/ 4,287.50
              </div>
              <div className="flex items-center gap-1.5 mt-1.5 text-[13px] text-white/85">
                <TrendingUp className="w-3.5 h-3.5" />
                <span className="font-semibold tabular-nums">+12.5%</span>
                <span className="text-white/60">vs mes anterior</span>
              </div>
            </div>
          </div>
        </section>

        {/* Stats grid */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Stats Cards
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <div
              className="rounded-[16px] p-4"
              style={{
                background: 'var(--ios-bg-elevated)',
                border: '0.5px solid var(--ios-separator)',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div
                className="w-9 h-9 rounded-[10px] flex items-center justify-center mb-3"
                style={{ background: 'rgba(255, 59, 48, 0.12)', color: 'var(--ios-red)' }}
              >
                <TrendingDown className="w-5 h-5" />
              </div>
              <div className="text-[22px] font-bold tracking-tight tabular-nums" style={{ letterSpacing: '-0.015em' }}>
                S/ 1,842
              </div>
              <div className="text-[12px] mt-0.5" style={{ color: 'var(--ios-label-secondary)' }}>
                Gastos hoy
              </div>
            </div>

            <div
              className="rounded-[16px] p-4"
              style={{
                background: 'var(--ios-bg-elevated)',
                border: '0.5px solid var(--ios-separator)',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div
                className="w-9 h-9 rounded-[10px] flex items-center justify-center mb-3"
                style={{ background: 'rgba(52, 199, 89, 0.12)', color: 'var(--ios-green)' }}
              >
                <PiggyBank className="w-5 h-5" />
              </div>
              <div className="text-[22px] font-bold tracking-tight tabular-nums" style={{ letterSpacing: '-0.015em' }}>
                S/ 890
              </div>
              <div className="text-[12px] mt-0.5" style={{ color: 'var(--ios-label-secondary)' }}>
                Ahorro
              </div>
            </div>
          </div>
        </section>

        {/* iOS List (Settings app style) */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Lista iOS
          </h2>
          <div
            className="overflow-hidden"
            style={{
              background: 'var(--ios-bg-elevated)',
              borderRadius: '16px',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <div className="list-row-apple">
              <div
                className="sf-symbol-circle"
                style={{ background: 'var(--ios-blue)' }}
              >
                <CreditCard className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-[15px] font-medium" style={{ color: 'var(--ios-label)' }}>Cuentas</div>
                <div className="text-[12px]" style={{ color: 'var(--ios-label-secondary)' }}>3 cuentas conectadas</div>
              </div>
              <ChevronRight className="w-4 h-4" style={{ color: 'var(--ios-label-tertiary)' }} />
            </div>

            <div className="list-row-apple">
              <div
                className="sf-symbol-circle"
                style={{ background: 'var(--ios-orange)' }}
              >
                <Bell className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-[15px] font-medium" style={{ color: 'var(--ios-label)' }}>Notificaciones</div>
                <div className="text-[12px]" style={{ color: 'var(--ios-label-secondary)' }}>Email · Push</div>
              </div>
              {/* iOS Toggle */}
              <button
                onClick={() => setToggleOn(!toggleOn)}
                className="relative w-[51px] h-[31px] rounded-full transition-all"
                style={{
                  background: toggleOn ? 'var(--ios-green)' : 'rgba(120, 120, 128, 0.16)',
                }}
              >
                <div
                  className="absolute top-[2px] w-[27px] h-[27px] bg-white rounded-full shadow-md transition-all"
                  style={{
                    left: toggleOn ? '22px' : '2px',
                    boxShadow: '0 3px 8px rgba(0, 0, 0, 0.15), 0 1px 1px rgba(0, 0, 0, 0.06)'
                  }}
                />
              </button>
            </div>

            <div className="list-row-apple">
              <div
                className="sf-symbol-circle"
                style={{ background: 'var(--ios-purple)' }}
              >
                <Receipt className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-[15px] font-medium" style={{ color: 'var(--ios-label)' }}>Reportes</div>
                <div className="text-[12px]" style={{ color: 'var(--ios-label-secondary)' }}>Programar PDF</div>
              </div>
              <ChevronRight className="w-4 h-4" style={{ color: 'var(--ios-label-tertiary)' }} />
            </div>

            <div className="list-row-apple">
              <div
                className="sf-symbol-circle"
                style={{ background: 'var(--ios-gray-2)' }}
              >
                <Settings className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="text-[15px] font-medium" style={{ color: 'var(--ios-label)' }}>Preferencias</div>
                <div className="text-[12px]" style={{ color: 'var(--ios-label-secondary)' }}>Tema · Idioma</div>
              </div>
              <ChevronRight className="w-4 h-4" style={{ color: 'var(--ios-label-tertiary)' }} />
            </div>
          </div>
        </section>

        {/* Alert banners */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Alertas
          </h2>
          <div className="space-y-2">
            <div
              className="flex items-start gap-3 p-3.5 rounded-[14px]"
              style={{ background: 'rgba(255, 59, 48, 0.08)', border: '0.5px solid rgba(255, 59, 48, 0.2)' }}
            >
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--ios-red)' }} />
              <div className="flex-1">
                <div className="text-[14px] font-semibold" style={{ color: 'var(--ios-label)' }}>
                  Presupuesto excedido
                </div>
                <div className="text-[12px] mt-0.5" style={{ color: 'var(--ios-label-secondary)' }}>
                  Has superado el límite de Comida este mes en S/ 45.
                </div>
              </div>
            </div>

            <div
              className="flex items-start gap-3 p-3.5 rounded-[14px]"
              style={{ background: 'rgba(255, 149, 0, 0.08)', border: '0.5px solid rgba(255, 149, 0, 0.2)' }}
            >
              <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--ios-orange)' }} />
              <div className="flex-1">
                <div className="text-[14px] font-semibold" style={{ color: 'var(--ios-label)' }}>
                  80% del presupuesto
                </div>
                <div className="text-[12px] mt-0.5" style={{ color: 'var(--ios-label-secondary)' }}>
                  Transporta está a punto de llegar al límite mensual.
                </div>
              </div>
            </div>

            <div
              className="flex items-start gap-3 p-3.5 rounded-[14px]"
              style={{ background: 'rgba(0, 122, 255, 0.08)', border: '0.5px solid rgba(0, 122, 255, 0.2)' }}
            >
              <Info className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--ios-blue)' }} />
              <div className="flex-1">
                <div className="text-[14px] font-semibold" style={{ color: 'var(--ios-label)' }}>
                  Nueva categoría sugerida
                </div>
                <div className="text-[12px] mt-0.5" style={{ color: 'var(--ios-label-secondary)' }}>
                  Gemini detectó gastos recurrentes en "Streaming".
                </div>
              </div>
            </div>

            <div
              className="flex items-start gap-3 p-3.5 rounded-[14px]"
              style={{ background: 'rgba(52, 199, 89, 0.08)', border: '0.5px solid rgba(52, 199, 89, 0.2)' }}
            >
              <Check className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--ios-green)' }} />
              <div className="flex-1">
                <div className="text-[14px] font-semibold" style={{ color: 'var(--ios-label)' }}>
                  Meta de ahorro alcanzada
                </div>
                <div className="text-[12px] mt-0.5" style={{ color: 'var(--ios-label-secondary)' }}>
                  ¡Has llegado al 100% de tu meta mensual!
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Buttons */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Botones
          </h2>
          <div className="space-y-2.5">
            <button className="btn-apple-primary w-full">Continuar con Google</button>
            <button className="btn-apple-secondary w-full">Cancelar</button>
            <button
              className="w-full py-[14px] rounded-[12px] font-medium text-[15px] text-white transition-all active:scale-[0.98]"
              style={{
                background: 'var(--ios-green)',
                boxShadow: '0 1px 2px rgba(52, 199, 89, 0.3), 0 4px 12px rgba(52, 199, 89, 0.18)'
              }}
            >
              Confirmar gasto
            </button>
            <button
              className="w-full py-[14px] rounded-[12px] font-medium text-[15px] text-white transition-all active:scale-[0.98]"
              style={{
                background: 'var(--ios-red)',
                boxShadow: '0 1px 2px rgba(255, 59, 48, 0.3), 0 4px 12px rgba(255, 59, 48, 0.18)'
              }}
            >
              Eliminar
            </button>
          </div>
        </section>

        {/* Inputs */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            Inputs
          </h2>
          <input className="input-apple" placeholder="Buscar..." />
          <input className="input-apple" type="email" placeholder="Email" />
        </section>

        {/* FAB */}
        <section className="space-y-3 animate-slide-up">
          <h2 className="text-[20px] font-semibold tracking-tight" style={{ color: 'var(--ios-label)' }}>
            FAB (Floating Action Button)
          </h2>
          <div className="flex justify-center py-4">
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.92 }}
              className="w-14 h-14 rounded-[20px] flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #007AFF 0%, #5856D6 100%)',
                color: '#FFFFFF',
                boxShadow: '0 8px 24px rgba(0, 122, 255, 0.4), 0 2px 8px rgba(88, 86, 214, 0.25)'
              }}
            >
              <Plus className="w-7 h-7 stroke-[2.5]" />
            </motion.button>
          </div>
        </section>
      </div>
    </div>
  );
};
