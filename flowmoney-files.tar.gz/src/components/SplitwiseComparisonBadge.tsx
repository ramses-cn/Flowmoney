/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Zap, ShieldCheck, Check, X, ArrowRight, Share2, Receipt, Coins, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SplitwiseComparisonBadgeProps {
  compact?: boolean;
}

export const SplitwiseComparisonBadge: React.FC<SplitwiseComparisonBadgeProps> = ({ compact = false }) => {
  const [showModal, setShowModal] = useState(false);

  const features = [
    {
      title: 'Límite de gastos diarios',
      splitwise: 'Máximo 4 gastos al día (bloqueo artificial)',
      us: '100% Ilimitado, sin restricciones',
      icon: Zap,
      superior: true
    },
    {
      title: 'Pantalla de espera obligatoria',
      splitwise: 'Temporizador de 10 segundos antes de guardar',
      us: 'Instantáneo (0 segundos de espera)',
      icon: Clock,
      superior: true
    },
    {
      title: 'Escaneo de tickets y recibos (OCR con IA)',
      splitwise: 'Solo en versión de pago (Splitwise Pro $39.99/año)',
      us: 'Gratis e ilimitado con Gemini Multimodal',
      icon: Receipt,
      superior: true
    },
    {
      title: 'Desglose plato por plato ("Quién comió qué")',
      splitwise: 'Manual y confuso, requiere apps externas',
      us: 'Interactivo: asigna platos a personas y reparte propina/impuestos',
      icon: Sparkles,
      superior: true
    },
    {
      title: 'Compartir resumen por WhatsApp',
      splitwise: 'Obliga a tus amigos a registrarse y bajar la app',
      us: '1 Clic: genera mensaje listo con emojis y balances para WhatsApp',
      icon: Share2,
      superior: true
    },
    {
      title: 'Medios de pago en Latinoamérica y España',
      splitwise: 'Enfocado en Venmo/PayPal (EE.UU.)',
      us: 'Yape, Plin, Mercado Pago, Pix, Bizum, CBU/CLABE integrados',
      icon: Coins,
      superior: true
    },
    {
      title: 'Conversión de divisas en tiempo real',
      splitwise: 'Funcionalidad de pago o tasas fijas',
      us: 'Conversión automática multi-moneda para viajes',
      icon: Coins,
      superior: true
    }
  ];

  return (
    <>
      <div 
        id="splitwise-better-banner"
        onClick={() => setShowModal(true)}
        className="bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-700 text-white rounded-2xl p-3 sm:p-3.5 shadow-md flex items-center justify-between gap-3 cursor-pointer hover:shadow-lg hover:scale-[1.005] transition-all group border border-emerald-400/30"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0 backdrop-blur-xs">
            <Sparkles className="w-4 h-4 text-emerald-200 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-400/30 text-emerald-100 px-2 py-0.5 rounded-full border border-emerald-300/30">
                Mejor que Splitwise
              </span>
              <span className="text-xs font-bold text-white truncate">
                100% Ilimitado · Cero esperas de 10s · Escáner IA Incluido
              </span>
            </div>
            {!compact && (
              <p className="text-[11px] text-emerald-100/90 mt-0.5 truncate hidden sm:block">
                Sin muro de pago Pro, desglose interactivo de boletas y exportación directa para WhatsApp.
              </p>
            )}
          </div>
        </div>

        <button 
          id="splitwise-compare-btn"
          type="button"
          className="flex-shrink-0 bg-white text-emerald-800 text-[11px] font-black py-1.5 px-3 rounded-xl shadow-xs group-hover:bg-emerald-50 transition-all flex items-center gap-1 cursor-pointer"
        >
          <span>Ver ventajas</span>
          <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

      {/* Modal Comparativo */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4" id="modal-splitwise-comparison">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-100 max-h-[90vh] flex flex-col"
            >
              <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-800">¿Por qué somos mejores que Splitwise?</h3>
                    <p className="text-xs text-slate-500">Diseñado sin las restricciones comerciales y frustraciones de Splitwise</p>
                  </div>
                </div>
                <button 
                  id="close-comparison-modal-btn"
                  onClick={() => setShowModal(false)}
                  className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-xl transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="overflow-y-auto space-y-3 pr-1 flex-1 py-2">
                {features.map((f, i) => {
                  const Icon = f.icon;
                  return (
                    <div 
                      key={i} 
                      className="p-3.5 bg-slate-50 hover:bg-emerald-50/40 rounded-2xl border border-slate-200/80 transition-all"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="w-4 h-4 text-emerald-600" />
                        <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">{f.title}</h4>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="bg-red-50/70 border border-red-200/60 rounded-xl p-2.5 flex items-start gap-2">
                          <X className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-[10px] font-bold text-red-700 uppercase">Splitwise</p>
                            <p className="text-slate-600 font-medium leading-relaxed">{f.splitwise}</p>
                          </div>
                        </div>

                        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-start gap-2">
                          <Check className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-[10px] font-bold text-emerald-700 uppercase">GastosGrupales AI</p>
                            <p className="text-emerald-900 font-bold leading-relaxed">{f.us}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <p className="text-[11px] text-slate-500">
                  Totalmente libre, impulsado por IA y optimizado para compartir gastos sin fricción.
                </p>
                <button
                  id="understand-comparison-btn"
                  onClick={() => setShowModal(false)}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold py-2 px-4 rounded-xl transition-all cursor-pointer"
                >
                  ¡Genial, a dividir gastos!
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
