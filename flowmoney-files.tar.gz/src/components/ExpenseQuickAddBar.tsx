/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, ArrowRight, Loader2 } from 'lucide-react';

interface ExpenseQuickAddBarProps {
  onQuickAdd: (promptText: string) => Promise<void>;
  groupCurrency: string;
  loading: boolean;
}

export const ExpenseQuickAddBar: React.FC<ExpenseQuickAddBarProps> = ({
  onQuickAdd,
  groupCurrency,
  loading
}) => {
  const [text, setText] = useState('');

  const suggestions = [
    `Almuerzo 60 ${groupCurrency} entre todos`,
    `Uber 25 ${groupCurrency} pagado por mí`,
    `Supermercado 120 ${groupCurrency}`
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || loading) return;
    await onQuickAdd(text.trim());
    setText('');
  };

  const handleSelectSuggestion = (s: string) => {
    setText(s);
  };

  return (
    <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80 mb-6" id="expense-quick-add-bar">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-black text-slate-800">
            Registro Rápido con IA
          </span>
          <span className="text-[10px] font-bold bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full border border-indigo-100 hidden sm:inline">
            Lenguaje natural
          </span>
        </div>
        <span className="text-[11px] text-slate-400">
          Escribe como hablas y la IA creará el gasto
        </span>
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={loading}
            placeholder={`Ej: "Cena de 85 ${groupCurrency} con Carlos y María", "Taxi al aeropuerto 30 ${groupCurrency}"...`}
            className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-2xl py-2.5 px-4 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all disabled:opacity-50"
          />
        </div>

        <button
          id="quick-add-ai-submit-btn"
          type="submit"
          disabled={!text.trim() || loading}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs py-2.5 px-4 rounded-2xl transition-all shadow-sm shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer flex-shrink-0"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-indigo-200" />
              <span className="hidden sm:inline">Interpretando...</span>
            </>
          ) : (
            <>
              <span>Registrar con IA</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </>
          )}
        </button>
      </form>

      {/* Sugerencias clicables */}
      <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto pb-1 text-[11px]">
        <span className="text-slate-400 font-medium flex-shrink-0">Ejemplos:</span>
        {suggestions.map((s, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleSelectSuggestion(s)}
            className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-2.5 py-1 rounded-xl whitespace-nowrap transition-colors cursor-pointer font-medium"
          >
            "{s}"
          </button>
        ))}
      </div>
    </div>
  );
};
