import React, { useState } from 'react';
import { SmartAlert } from '../../types/flowmoney.ts';
import { AlertCircle, AlertTriangle, Info, X, ChevronRight } from 'lucide-react';

interface SmartAlertsBannerProps {
  alerts: SmartAlert[];
  readAlertIds?: Set<string>;
  onAlertClick?: (alert: SmartAlert) => void;
  onDismiss?: (id: string) => void;
}

export const SmartAlertsBanner: React.FC<SmartAlertsBannerProps> = ({
  alerts,
  readAlertIds,
  onAlertClick,
  onDismiss,
}) => {
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());

  const visibleAlerts = alerts.filter(
    (a) => !dismissedIds.has(a.id) && (!readAlertIds || !readAlertIds.has(a.id))
  );

  if (visibleAlerts.length === 0) return null;

  const handleDismiss = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDismissedIds((prev) => new Set([...prev, id]));
    if (onDismiss) onDismiss(id);
  };

  const handleCardClick = (alert: SmartAlert) => {
    if (onAlertClick) {
      onAlertClick(alert);
    }
  };

  return (
    <div className="space-y-2 mb-4 animate-fade-in">
      {visibleAlerts.slice(0, 3).map((alert) => {
        const isDanger = alert.type === 'danger';
        const isWarning = alert.type === 'warning';
        const isInfo = alert.type === 'info';

        return (
          <div
            key={alert.id}
            onClick={() => handleCardClick(alert)}
            role={onAlertClick ? 'button' : undefined}
            tabIndex={onAlertClick ? 0 : undefined}
            className={`group p-3 rounded-2xl border flex items-start space-x-3 transition-all relative overflow-hidden cursor-pointer ${
              isDanger
                ? 'bg-rose-50/90 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/60 text-rose-950 dark:text-rose-200 hover:border-rose-300'
                : isWarning
                ? 'bg-amber-50/90 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-950 dark:text-amber-200 hover:border-amber-300'
                : 'bg-indigo-50/90 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900/60 text-indigo-950 dark:text-indigo-200 hover:border-indigo-300'
            }`}
          >
            <div className="mt-0.5 flex-shrink-0">
              {isDanger && <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400" />}
              {isWarning && <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />}
              {isInfo && <Info className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
            </div>

            <div className="flex-1 pr-6">
              <div className="text-xs font-bold leading-tight">{alert.title}</div>
              <div className="text-[11px] opacity-90 mt-0.5 leading-relaxed">{alert.message}</div>

              <div className="mt-1.5 flex items-center space-x-1 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 group-hover:underline">
                <span>{alert.actionLabel || 'Ver detalles'}</span>
                <ChevronRight className="w-3 h-3" />
              </div>
            </div>

            <button
              onClick={(e) => handleDismiss(alert.id, e)}
              className="absolute top-2.5 right-2.5 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors hover:bg-black/5 dark:hover:bg-white/5"
              title="Marcar como leída / descartar"
              aria-label="Cerrar alerta"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
