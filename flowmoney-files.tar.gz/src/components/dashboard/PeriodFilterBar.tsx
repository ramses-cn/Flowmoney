import React, { useState } from 'react';
import {
  Calendar,
  Filter,
  X,
  ChevronDown,
  RotateCcw,
  Check,
  Tag,
  CreditCard,
  Layers,
} from 'lucide-react';
import {
  DashboardPeriod,
  DynamicFilters,
  Category,
  Account,
} from '../../types/flowmoney.ts';

interface PeriodFilterBarProps {
  currentPeriod: DashboardPeriod;
  onSelectPeriod: (period: DashboardPeriod) => void;
  customStartDate?: string;
  customEndDate?: string;
  onChangeCustomDates?: (start: string, end: string) => void;
  filters: DynamicFilters;
  onChangeFilters: (filters: DynamicFilters) => void;
  categories: Category[];
  accounts: Account[];
  onOpenConfigureWidgets?: () => void;
}

const PERIOD_BUTTONS: { id: DashboardPeriod; label: string }[] = [
  { id: 'today', label: 'Hoy' },
  { id: 'week', label: 'Semana' },
  { id: 'month', label: 'Mes' },
  { id: 'year', label: 'Año' },
  { id: 'last_7_days', label: '7 días' },
  { id: 'last_30_days', label: '30 días' },
  { id: 'last_90_days', label: '90 días' },
  { id: 'custom', label: 'Personalizado' },
];

export const PeriodFilterBar: React.FC<PeriodFilterBarProps> = ({
  currentPeriod,
  onSelectPeriod,
  customStartDate = '',
  customEndDate = '',
  onChangeCustomDates,
  filters,
  onChangeFilters,
  categories,
  accounts,
  onOpenConfigureWidgets,
}) => {
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [startDate, setStartDate] = useState(customStartDate);
  const [endDate, setEndDate] = useState(customEndDate);

  const hasActiveFilters =
    Boolean(filters.categoryId && filters.categoryId !== 'all') ||
    Boolean(filters.accountId && filters.accountId !== 'all') ||
    Boolean(filters.type && filters.type !== 'all') ||
    currentPeriod === 'custom';

  const handleApplyCustomDates = (e: React.FormEvent) => {
    e.preventDefault();
    if (startDate && endDate && onChangeCustomDates) {
      onChangeCustomDates(startDate, endDate);
    }
  };

  const handleClearFilters = () => {
    onChangeFilters({
      categoryId: undefined,
      accountId: undefined,
      type: 'all',
    });
  };

  return (
    <div className="space-y-2">
      {/* Barra de Períodos estilo Pills Desplazables Horizontalmente */}
      <div className="flex items-center justify-between gap-1.5">
        <div className="flex-1 overflow-x-auto no-scrollbar flex items-center space-x-1.5 py-0.5">
          {PERIOD_BUTTONS.map((btn) => (
            <button
              key={btn.id}
              type="button"
              onClick={() => onSelectPeriod(btn.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all shrink-0 ${
                currentPeriod === btn.id
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-2xs font-bold'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-slate-300'
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>

        {/* Botón Filtros Avanzados */}
        <div className="flex items-center space-x-1 shrink-0">
          <button
            type="button"
            onClick={() => setShowFilterDrawer(!showFilterDrawer)}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center space-x-1 border transition-all ${
              hasActiveFilters
                ? 'bg-indigo-50 dark:bg-indigo-950/70 border-indigo-300 dark:border-indigo-700 text-indigo-600 dark:text-indigo-400'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Filtros dinámicos combinables"
          >
            <Filter className="w-3.5 h-3.5" />
            {hasActiveFilters && (
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 dark:bg-indigo-400" />
            )}
          </button>
        </div>
      </div>

      {/* Rango de fechas personalizado si el período es custom */}
      {currentPeriod === 'custom' && (
        <form
          onSubmit={handleApplyCustomDates}
          className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-wrap items-center gap-2 text-xs animate-fade-in shadow-2xs"
        >
          <div className="flex items-center space-x-1.5">
            <Calendar className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span className="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">
              Desde:
            </span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              required
              className="px-2 py-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 text-xs"
            />
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="font-semibold text-slate-600 dark:text-slate-400 text-[11px]">
              Hasta:
            </span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              required
              className="px-2 py-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 text-xs"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs"
          >
            Aplicar Rango
          </button>
        </form>
      )}

      {/* Panel Desplegable de Filtros Dinámicos Combinables */}
      {showFilterDrawer && (
        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-3 animate-fade-in shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
              <Filter className="w-3.5 h-3.5 text-indigo-500" />
              <span>Filtros Dinámicos Combinables</span>
            </span>
            {hasActiveFilters && (
              <button
                type="button"
                onClick={handleClearFilters}
                className="text-[10px] text-rose-500 hover:underline flex items-center space-x-0.5"
              >
                <RotateCcw className="w-2.5 h-2.5" />
                <span>Limpiar filtros</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Filtro por Categoría */}
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center space-x-1">
                <Tag className="w-3 h-3 text-indigo-500" />
                <span>Categoría</span>
              </label>
              <select
                value={filters.categoryId || 'all'}
                onChange={(e) =>
                  onChangeFilters({
                    ...filters,
                    categoryId: e.target.value === 'all' ? undefined : e.target.value,
                  })
                }
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-800 dark:text-slate-200 text-xs"
              >
                <option value="all">Todas las categorías</option>
                {categories
                  .filter((c) => c.is_active !== false)
                  .map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
              </select>
            </div>

            {/* Filtro por Cuenta */}
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center space-x-1">
                <CreditCard className="w-3 h-3 text-indigo-500" />
                <span>Cuenta / Origen</span>
              </label>
              <select
                value={filters.accountId || 'all'}
                onChange={(e) =>
                  onChangeFilters({
                    ...filters,
                    accountId: e.target.value === 'all' ? undefined : e.target.value,
                  })
                }
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-800 dark:text-slate-200 text-xs"
              >
                <option value="all">Todas las cuentas</option>
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} ({acc.currency})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
