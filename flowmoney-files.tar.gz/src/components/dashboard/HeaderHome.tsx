import React, { useState } from 'react';
import {
  Bell,
  BellOff,
  Sparkles,
  X,
  Check,
  CheckCheck,
  ChevronRight,
  AlertCircle,
  AlertTriangle,
  Info,
  Sliders,
  FileSpreadsheet,
  User,
  Users,
  Heart,
} from 'lucide-react';
import { motion } from 'motion/react';
import { ExpenseLens, SmartAlert } from '../../types/flowmoney.ts';
import { RealtimeStatusBadge } from '../common/RealtimeStatusBadge.tsx';
import { useAuthStore } from '../../store/useAuthStore.ts';

interface HeaderHomeProps {
  currentLens: ExpenseLens;
  onSelectLens: (lens: ExpenseLens) => void;
  alerts: SmartAlert[];
  unreadAlertsCount: number;
  readAlertIds: Set<string>;
  onAlertClick: (alert: SmartAlert) => void;
  onMarkAllAsRead: () => void;
  onMarkAlertAsRead: (id: string, e?: React.MouseEvent) => void;
  onOpenAlertsModal?: () => void;
  onOpenConfigureWidgets?: () => void;
  onOpenTools?: () => void;
  realtimeStatus?: {
    isRealtimeActive: boolean;
    isPollingFallback: boolean;
    lastEventAt?: Date | null;
    onManualRefresh?: () => void;
  };
}

/**
 * HeaderHome rediseñado con estética Apple (iOS large title + segmented control):
 * - Large title estilo iOS (34pt bold, tracking tight)
 * - Segmented control con píldora blanca (Apple HIG)
 * - Glassmorphism en header sticky
 * - Badges con colores iOS (blue, pink, green)
 * - SF Symbol-style icons
 */
export const HeaderHome: React.FC<HeaderHomeProps> = ({
  currentLens,
  onSelectLens,
  alerts,
  unreadAlertsCount,
  readAlertIds,
  onAlertClick,
  onMarkAllAsRead,
  onMarkAlertAsRead,
  onOpenConfigureWidgets,
  onOpenTools,
  realtimeStatus,
}) => {
  const { profile } = useAuthStore();
  const userName = profile?.full_name ? profile.full_name.split(' ')[0] : null;

  const [showNotificationsDrawer, setShowNotificationsDrawer] = useState(false);
  const [filterMode, setFilterMode] = useState<'all' | 'unread'>('unread');

  const filteredAlerts = alerts.filter((a) => {
    if (filterMode === 'unread') {
      return !readAlertIds.has(a.id);
    }
    return true;
  });

  const handleCardClick = (alert: SmartAlert) => {
    setShowNotificationsDrawer(false);
    onAlertClick(alert);
  };

  const greeting = (() => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Buenos días';
    if (hour < 19) return 'Buenas tardes';
    return 'Buenas noches';
  })();

  // Color por lens (Apple semantic colors)
  const lensColors: Record<ExpenseLens, string> = {
    personal: 'var(--ios-blue)',
    couple: 'var(--ios-pink)',
    group: 'var(--ios-green)',
  };

  return (
    <header
      className="sticky top-0 z-30 pt-3 pb-3 safe-area-top transition-colors"
      style={{
        background: 'rgba(242, 242, 247, 0.85)',
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        borderBottom: '0.5px solid var(--ios-separator)'
      }}
    >
      {/* Barra superior: Logo + Saludo + Acciones */}
      <div className="flex items-center justify-between px-1 mb-3">
        {/* Logo FlowMoney & Saludo */}
        <div className="flex items-center space-x-2.5">
          <div
            className="w-9 h-9 rounded-[10px] flex items-center justify-center text-white"
            style={{
              background: 'linear-gradient(135deg, #007AFF 0%, #5856D6 100%)',
              boxShadow: '0 1px 3px rgba(0, 122, 255, 0.35), 0 2px 8px rgba(88, 86, 214, 0.20)'
            }}
          >
            <span className="font-bold text-[13px] tracking-tight">FM</span>
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span
                className="text-[15px] font-semibold leading-none tracking-tight"
                style={{ color: 'var(--ios-label)', letterSpacing: '-0.015em' }}
              >
                {greeting}{userName ? `, ${userName}` : ''}
              </span>
              <span
                className="text-[9px] font-bold px-1.5 py-0.5 rounded-[5px]"
                style={{
                  background: 'rgba(0, 122, 255, 0.10)',
                  color: 'var(--ios-blue)',
                  border: '0.5px solid rgba(0, 122, 255, 0.20)'
                }}
              >
                PRO
              </span>
            </div>
            <p
              className="text-[11px] mt-1 leading-none"
              style={{ color: 'var(--ios-label-secondary)' }}
            >
              Control en tiempo real de tus finanzas
            </p>
          </div>
        </div>

        {/* Acciones */}
        <div className="flex items-center space-x-1">
          {realtimeStatus && (currentLens === 'couple' || currentLens === 'group') && (
            <RealtimeStatusBadge
              isRealtimeActive={realtimeStatus.isRealtimeActive}
              isPollingFallback={realtimeStatus.isPollingFallback}
              lastEventAt={realtimeStatus.lastEventAt}
              onManualRefresh={realtimeStatus.onManualRefresh}
            />
          )}

          {onOpenTools && (
            <button
              onClick={onOpenTools}
              className="p-2 rounded-[10px] transition-all active:scale-90"
              style={{ color: 'var(--ios-blue)' }}
              title="Herramientas: Reportes en PDF/Excel y configuración de alertas"
              aria-label="Herramientas y Reportes"
            >
              <FileSpreadsheet className="w-[18px] h-[18px]" />
            </button>
          )}

          {onOpenConfigureWidgets && (
            <button
              onClick={onOpenConfigureWidgets}
              className="p-2 rounded-[10px] transition-all active:scale-90"
              style={{ color: 'var(--ios-label-secondary)' }}
              title="Personalizar widgets y módulos del dashboard"
              aria-label="Configurar dashboard"
            >
              <Sliders className="w-[18px] h-[18px]" />
            </button>
          )}

          <div className="relative">
            <button
              onClick={() => setShowNotificationsDrawer(!showNotificationsDrawer)}
              className="p-2 rounded-[10px] relative transition-all active:scale-90"
              style={{ color: 'var(--ios-label-secondary)' }}
              title={unreadAlertsCount > 0 ? `${unreadAlertsCount} alertas activas` : 'Sin alertas activas'}
              aria-label="Campana de notificaciones"
            >
              <Bell className="w-[20px] h-[20px]" />
              {unreadAlertsCount > 0 && (
                <span
                  className="absolute top-1 right-1 flex h-[16px] min-w-[16px] items-center justify-center rounded-full px-1 text-[10px] font-bold text-white animate-pulse"
                  style={{ background: 'var(--ios-red)' }}
                >
                  {unreadAlertsCount}
                </span>
              )}
            </button>

            {/* Backdrop */}
            {showNotificationsDrawer && (
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowNotificationsDrawer(false)}
              />
            )}

            {/* Drawer iOS-style */}
            {showNotificationsDrawer && (
              <div
                className="absolute right-0 top-11 w-80 sm:w-[360px] p-4 z-50 animate-fade-in space-y-3"
                style={{
                  background: 'var(--ios-bg-elevated)',
                  borderRadius: '16px',
                  boxShadow: '0 24px 56px rgba(0, 0, 0, 0.18), 0 8px 16px rgba(0, 0, 0, 0.08)',
                  border: '0.5px solid var(--ios-separator)'
                }}
              >
                {/* Cabecera */}
                <div
                  className="flex items-center justify-between pb-2.5"
                  style={{ borderBottom: '0.5px solid var(--ios-separator)' }}
                >
                  <div className="flex items-center space-x-1.5 text-[13px] font-semibold" style={{ color: 'var(--ios-label)' }}>
                    <Sparkles className="w-4 h-4" style={{ color: 'var(--ios-blue)' }} />
                    <span>Alertas Inteligentes</span>
                    {unreadAlertsCount > 0 && (
                      <span
                        className="ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold"
                        style={{
                          background: 'rgba(255, 59, 48, 0.12)',
                          color: 'var(--ios-red)'
                        }}
                      >
                        {unreadAlertsCount}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    {unreadAlertsCount > 0 && (
                      <button
                        onClick={onMarkAllAsRead}
                        className="text-[11px] font-medium flex items-center space-x-1 px-2 py-1 rounded-[8px] transition-all active:scale-90"
                        style={{ color: 'var(--ios-blue)' }}
                        title="Marcar todas como leídas"
                      >
                        <CheckCheck className="w-3.5 h-3.5" />
                        <span>Leídas</span>
                      </button>
                    )}
                    <button
                      onClick={() => setShowNotificationsDrawer(false)}
                      className="p-1 rounded-[8px] transition-all active:scale-90"
                      style={{ color: 'var(--ios-label-tertiary)' }}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Segmented control iOS-style */}
                {alerts.length > 0 && (
                  <div className="segmented-control w-full">
                    <button
                      onClick={() => setFilterMode('unread')}
                      className="segmented-control-item flex-1"
                      style={{
                        color: filterMode === 'unread' ? 'var(--ios-label)' : 'var(--ios-label-secondary)',
                        fontWeight: filterMode === 'unread' ? 600 : 500
                      }}
                    >
                      Pendientes ({unreadAlertsCount})
                    </button>
                    <button
                      onClick={() => setFilterMode('all')}
                      className="segmented-control-item flex-1"
                      style={{
                        color: filterMode === 'all' ? 'var(--ios-label)' : 'var(--ios-label-secondary)',
                        fontWeight: filterMode === 'all' ? 600 : 500
                      }}
                    >
                      Todas ({alerts.length})
                    </button>
                    <div
                      className="segmented-control-thumb"
                      style={{
                        top: 2,
                        bottom: 2,
                        left: filterMode === 'unread' ? 2 : '50%',
                        right: filterMode === 'unread' ? '50%' : 2,
                      }}
                    />
                  </div>
                )}

                {/* Listado de Alertas */}
                {filteredAlerts.length === 0 ? (
                  <div className="text-center py-7 px-4 space-y-2">
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center mx-auto"
                      style={{
                        background: 'var(--ios-bg-tertiary)',
                        color: 'var(--ios-label-tertiary)'
                      }}
                    >
                      <BellOff className="w-6 h-6" />
                    </div>
                    <div className="text-[13px] font-semibold" style={{ color: 'var(--ios-label)' }}>
                      {filterMode === 'unread' ? '¡Estás al día!' : 'No hay alertas disponibles'}
                    </div>
                    <p className="text-[12px]" style={{ color: 'var(--ios-label-secondary)' }}>
                      {filterMode === 'unread'
                        ? 'No tienes alertas pendientes de leer en este momento.'
                        : 'Las alertas generadas aparecerán en esta sección.'}
                    </p>
                  </div>
                ) : (
                  <div className="max-h-72 overflow-y-auto space-y-2 pr-0.5">
                    {filteredAlerts.map((a) => {
                      const isRead = readAlertIds.has(a.id);
                      const isDanger = a.type === 'danger';
                      const isWarning = a.type === 'warning';
                      const isInfo = a.type === 'info';

                      return (
                        <div
                          key={a.id}
                          onClick={() => handleCardClick(a)}
                          className="group p-3 rounded-[12px] text-xs cursor-pointer transition-all relative"
                          style={{
                            background: isRead
                              ? 'var(--ios-bg-tertiary)'
                              : isDanger
                              ? 'rgba(255, 59, 48, 0.06)'
                              : isWarning
                              ? 'rgba(255, 149, 0, 0.06)'
                              : 'rgba(0, 122, 255, 0.06)',
                            border: '0.5px solid var(--ios-separator)',
                            opacity: isRead ? 0.7 : 1
                          }}
                        >
                          <div className="flex items-start space-x-2.5">
                            {/* Icono */}
                            <div className="mt-0.5 shrink-0">
                              {isDanger && <AlertCircle className="w-4 h-4" style={{ color: 'var(--ios-red)' }} />}
                              {isWarning && <AlertTriangle className="w-4 h-4" style={{ color: 'var(--ios-orange)' }} />}
                              {isInfo && <Info className="w-4 h-4" style={{ color: 'var(--ios-blue)' }} />}
                            </div>

                            {/* Contenido */}
                            <div className="flex-1 pr-6">
                              <div className="flex items-center space-x-1.5">
                                <span className="font-semibold text-[12px]" style={{ color: 'var(--ios-label)' }}>
                                  {a.title}
                                </span>
                                {!isRead && (
                                  <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: 'var(--ios-red)' }} />
                                )}
                              </div>
                              <div className="text-[11px] mt-0.5 leading-relaxed" style={{ color: 'var(--ios-label-secondary)' }}>
                                {a.message}
                              </div>

                              <div className="mt-2 flex items-center justify-between">
                                <span
                                  className="inline-flex items-center space-x-1 text-[10px] font-semibold"
                                  style={{ color: 'var(--ios-blue)' }}
                                >
                                  <span>{a.actionLabel || 'Ir a la sección'}</span>
                                  <ChevronRight className="w-3 h-3" />
                                </span>

                                {isRead && (
                                  <span className="text-[10px] flex items-center space-x-0.5" style={{ color: 'var(--ios-label-tertiary)' }}>
                                    <Check className="w-3 h-3" />
                                    <span>Leída</span>
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Botón marcar leída */}
                            {!isRead && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onMarkAlertAsRead(a.id, e);
                                }}
                                className="absolute top-2.5 right-2.5 p-1 rounded-[6px] transition-all active:scale-90"
                                style={{ color: 'var(--ios-label-tertiary)' }}
                                title="Marcar como leída"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Selector de Lente — iOS Segmented Control */}
      <div className="segmented-control w-full">
        <button
          type="button"
          onClick={() => onSelectLens('personal')}
          className="segmented-control-item flex-1 flex items-center justify-center space-x-1.5"
          style={{
            color: currentLens === 'personal' ? 'var(--ios-blue)' : 'var(--ios-label-secondary)',
            fontWeight: currentLens === 'personal' ? 600 : 500
          }}
        >
          <User className="w-3.5 h-3.5" />
          <span>Personal</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectLens('couple')}
          className="segmented-control-item flex-1 flex items-center justify-center space-x-1.5"
          style={{
            color: currentLens === 'couple' ? 'var(--ios-pink)' : 'var(--ios-label-secondary)',
            fontWeight: currentLens === 'couple' ? 600 : 500
          }}
        >
          <Heart className="w-3.5 h-3.5" />
          <span>Pareja</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectLens('group')}
          className="segmented-control-item flex-1 flex items-center justify-center space-x-1.5"
          style={{
            color: currentLens === 'group' ? 'var(--ios-green)' : 'var(--ios-label-secondary)',
            fontWeight: currentLens === 'group' ? 600 : 500
          }}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Grupos</span>
        </button>

        {/* Píldora animada que sigue el tab activo */}
        <motion.div
          layoutId="activeLensTabPill"
          className="segmented-control-thumb"
          style={{
            top: 2,
            bottom: 2,
            left: currentLens === 'personal' ? 2 : currentLens === 'couple' ? '33.33%' : '66.66%',
            width: '33.33%',
          }}
          transition={{ type: 'spring', stiffness: 450, damping: 32 }}
        />
      </div>
    </header>
  );
};
