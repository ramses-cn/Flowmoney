import React, { useState } from 'react';
import { DashboardCoupleData } from '../../types/flowmoney.ts';
import { Heart, Plus, ArrowUpRight, ArrowDownLeft, CheckCircle2, User, Users, ShieldCheck } from 'lucide-react';

interface LensCoupleProps {
  data: DashboardCoupleData | null;
  currency: string;
  onOpenAddExpense: () => void;
  onRefreshData?: () => void;
}

export const LensCouple: React.FC<LensCoupleProps> = ({
  data,
  currency,
  onOpenAddExpense,
  onRefreshData,
}) => {
  const [showCreateCoupleModal, setShowCreateCoupleModal] = useState(false);
  const [partnerName, setPartnerName] = useState('');

  if (!data) {
    return (
      <div className="py-12 text-center text-xs text-slate-400">
        Cargando finanzas de pareja desde Cloud Run...
      </div>
    );
  }

  const {
    hasCoupleGroup,
    coupleGroup,
    partnerInfo,
    netBalance,
    partnerOwesMe,
    iOwePartner,
    sharedExpenses,
    myPersonalExpenses,
    myPersonalTotal,
  } = data;

  const partnerDisplayName = partnerInfo?.full_name || 'Tu pareja';

  return (
    <div className="space-y-4 animate-fade-in">
      {/* 1. Card de Balance Neto (Quién debe a quién) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs font-bold text-rose-500 uppercase tracking-wider">
            <Heart className="w-4 h-4 fill-rose-500" />
            <span>Balance de Pareja</span>
          </div>

          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-600 flex items-center justify-center text-[10px] font-bold">
              {partnerDisplayName.slice(0, 1)}
            </div>
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {partnerDisplayName}
            </span>
          </div>
        </div>

        {/* Estado del balance */}
        <div className="text-center py-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200/60 dark:border-slate-800">
          {netBalance > 0 ? (
            <div className="space-y-1">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center justify-center space-x-1">
                <ArrowDownLeft className="w-4 h-4 text-emerald-500" />
                <span>{partnerDisplayName} te debe</span>
              </div>
              <div className="text-3xl font-black text-emerald-600 dark:text-emerald-400">
                +{currency} {partnerOwesMe.toFixed(2)}
              </div>
              <p className="text-[11px] text-slate-400">
                Has cubierto más gastos compartidos este período.
              </p>
            </div>
          ) : netBalance < 0 ? (
            <div className="space-y-1">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center justify-center space-x-1">
                <ArrowUpRight className="w-4 h-4 text-rose-500" />
                <span>Le debes a {partnerDisplayName}</span>
              </div>
              <div className="text-3xl font-black text-rose-600 dark:text-rose-400">
                -{currency} {iOwePartner.toFixed(2)}
              </div>
              <p className="text-[11px] text-slate-400">
                {partnerDisplayName} ha cubierto más gastos compartidos.
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-1">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-white">
                Están completamente al día
              </div>
              <p className="text-xs text-slate-400">
                No hay deudas pendientes entre ambos.
              </p>
            </div>
          )}
        </div>

        {/* Acceso rápido a registrar gasto de pareja */}
        <button
          onClick={onOpenAddExpense}
          className="w-full py-2.5 px-4 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 rounded-2xl text-xs font-bold transition-colors flex items-center justify-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Añadir gasto con mi pareja</span>
        </button>
      </div>

      {/* 2. Card de Gastos Compartidos Recientes */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Gastos Compartidos Recientes
          </h3>
          <span className="text-xs text-slate-400">
            {sharedExpenses.length} registrados
          </span>
        </div>

        {sharedExpenses.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">
            No hay gastos compartidos registrados todavía.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {sharedExpenses.map((exp) => (
              <div key={exp.id} className="py-2.5 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs"
                    style={{
                      backgroundColor: `${exp.category_color || '#EC4899'}1A`,
                      color: exp.category_color || '#EC4899',
                    }}
                  >
                    {(exp.category_name || 'C').slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                      {exp.description}
                    </div>
                    <div className="text-[10px] text-slate-400 flex items-center space-x-1.5 mt-0.5">
                      <span>Pagado por: {exp.paid_by_name || 'Tú'}</span>
                      <span>&bull;</span>
                      <span>{exp.expense_date}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-black text-slate-900 dark:text-white">
                    {exp.currency} {Number(exp.amount).toFixed(2)}
                  </div>
                  <div className="text-[10px] text-rose-500 font-medium">
                    Compartido 50/50
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. Card "Mi Dinero" (Gastos Personales dentro de la Relación para Transparencia) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              "Mi Dinero" (Transparencia)
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Tus gastos personales propios, sin afectar el balance de pareja
            </p>
          </div>
          <div className="text-right font-black text-xs text-slate-800 dark:text-slate-200">
            {currency} {myPersonalTotal.toFixed(2)}
          </div>
        </div>

        {myPersonalExpenses.length === 0 ? (
          <div className="text-center py-4 text-xs text-slate-400">
            No has registrado gastos personales en este período.
          </div>
        ) : (
          <div className="space-y-2 pt-1">
            {myPersonalExpenses.map((exp) => (
              <div
                key={exp.id}
                className="p-2.5 bg-slate-50 dark:bg-slate-950/70 rounded-2xl border border-slate-200/50 dark:border-slate-800/70 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-semibold text-slate-800 dark:text-slate-200">
                    {exp.description}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {exp.category_name} &bull; {exp.expense_date}
                  </div>
                </div>
                <div className="font-bold text-slate-900 dark:text-white">
                  {currency} {Number(exp.amount).toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
