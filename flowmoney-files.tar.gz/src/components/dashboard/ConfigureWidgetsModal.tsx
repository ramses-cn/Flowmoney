import React from 'react';
import {
  X,
  Check,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  LayoutGrid,
  Shield,
  Sliders,
} from 'lucide-react';
import {
  DashboardWidgetConfig,
  DashboardWidgetId,
  DashboardPeriod,
  UserDashboardPreferences,
} from '../../types/flowmoney.ts';

interface ConfigureWidgetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserDashboardPreferences;
  onSavePreferences: (updated: UserDashboardPreferences) => Promise<void>;
}

const WIDGET_INFO: Record<
  DashboardWidgetId,
  { label: string; description: string; iconEmoji: string }
> = {
  balance: {
    label: 'Balance Total',
    description: 'Saldo disponible y cálculo de patrimonio en tus cuentas',
    iconEmoji: '💳',
  },
  income: {
    label: 'Ingresos del Periodo',
    description: 'Total de entradas y salarios recibidos',
    iconEmoji: '📈',
  },
  expenses: {
    label: 'Gastos del Periodo',
    description: 'Total de salidas y consumos registrados',
    iconEmoji: '📉',
  },
  savings: {
    label: 'Ahorro Calculado',
    description: 'Diferencia neta (Ingresos - Gastos) y tasa de ahorro',
    iconEmoji: '🌱',
  },
  budget: {
    label: 'Progreso de Presupuesto',
    description: 'Barra de cumplimiento del límite mensual y ritmo diario',
    iconEmoji: '🎯',
  },
  recent_expenses: {
    label: 'Gastos Recientes',
    description: 'Lista de los últimos movimientos para edición rápida',
    iconEmoji: '🧾',
  },
  categories: {
    label: 'Principales Categorías',
    description: 'Distribución de consumo por categoría activa',
    iconEmoji: '🏷️',
  },
  upcoming_payments: {
    label: 'Próximos Pagos',
    description: 'Vencimientos cercanos de cuentas, cuotas y servicios',
    iconEmoji: '📅',
  },
  alerts: {
    label: 'Alertas Inteligentes',
    description: 'Avisos de desvíos, presupuestos excedidos y recordatorios',
    iconEmoji: '⚡',
  },
  subscriptions: {
    label: 'Suscripciones Fijas',
    description: 'Servicios recurrentes (Netflix, Spotify, etc.) y costo mensual',
    iconEmoji: '🔄',
  },
  debts: {
    label: 'Deudas y Saldos Pendientes',
    description: 'Préstamos o saldos compartidos que debes o te deben',
    iconEmoji: '🤝',
  },
};

const PERIOD_LABELS: { id: DashboardPeriod; label: string }[] = [
  { id: 'today', label: 'Hoy' },
  { id: 'week', label: 'Esta Semana' },
  { id: 'month', label: 'Este Mes' },
  { id: 'year', label: 'Este Año' },
  { id: 'last_7_days', label: 'Últimos 7 días' },
  { id: 'last_30_days', label: 'Últimos 30 días' },
  { id: 'last_90_days', label: 'Últimos 90 días' },
];

export const ConfigureWidgetsModal: React.FC<ConfigureWidgetsModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onSavePreferences,
}) => {
  const [widgets, setWidgets] = React.useState<DashboardWidgetConfig[]>([]);
  const [defaultPeriod, setDefaultPeriod] = React.useState<DashboardPeriod>('month');
  const [isSaving, setIsSaving] = React.useState(false);

  React.useEffect(() => {
    if (isOpen) {
      // Clonar para edición
      setWidgets(
        [...preferences.widgets].sort((a, b) => a.order - b.order)
      );
      setDefaultPeriod(preferences.default_period || 'month');
    }
  }, [isOpen, preferences]);

  if (!isOpen) return null;

  const handleToggleWidget = (id: DashboardWidgetId) => {
    setWidgets((prev) =>
      prev.map((w) => (w.id === id ? { ...w, enabled: !w.enabled } : w))
    );
  };

  const handleMoveWidget = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= widgets.length) return;

    const newWidgets = [...widgets];
    const temp = newWidgets[index];
    newWidgets[index] = newWidgets[targetIndex];
    newWidgets[targetIndex] = temp;

    // Recalcular orden secuencial
    const updated = newWidgets.map((w, idx) => ({ ...w, order: idx + 1 }));
    setWidgets(updated);
  };

  const handleResetDefaults = () => {
    const defaultWidgets: DashboardWidgetConfig[] = [
      { id: 'balance', enabled: true, order: 1 },
      { id: 'income', enabled: true, order: 2 },
      { id: 'expenses', enabled: true, order: 3 },
      { id: 'savings', enabled: true, order: 4 },
      { id: 'budget', enabled: true, order: 5 },
      { id: 'recent_expenses', enabled: true, order: 6 },
      { id: 'categories', enabled: true, order: 7 },
      { id: 'upcoming_payments', enabled: true, order: 8 },
      { id: 'alerts', enabled: true, order: 9 },
      { id: 'subscriptions', enabled: true, order: 10 },
      { id: 'debts', enabled: true, order: 11 },
    ];
    setWidgets(defaultWidgets);
    setDefaultPeriod('month');
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSavePreferences({
        default_period: defaultPeriod,
        widgets: widgets.map((w, idx) => ({ ...w, order: idx + 1 })),
      });
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const enabledCount = widgets.filter((w) => w.enabled).length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg max-h-[85vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Cabecera */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Personalizar Dashboard
              </h2>
              <p className="text-[11px] text-slate-400">
                Mostrar solo lo que necesitas: activa, oculta y reordena
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Cuerpo con Scroll */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Período por defecto */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
              Período predeterminado al abrir FlowMoney
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
              {PERIOD_LABELS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setDefaultPeriod(p.id)}
                  className={`py-1.5 px-2.5 rounded-xl text-xs font-semibold text-center border transition-all ${
                    defaultPeriod === p.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/70 border-indigo-600 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                      : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Widgets Configuración */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                Módulos y Widgets del Dashboard ({enabledCount} visibles)
              </label>
              <button
                type="button"
                onClick={handleResetDefaults}
                className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold hover:underline flex items-center space-x-1"
              >
                <RotateCcw className="w-2.5 h-2.5" />
                <span>Restablecer</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-400">
              Usa las flechas para ordenar qué información aparece primero.
            </p>

            <div className="space-y-1.5">
              {widgets.map((widget, idx) => {
                const info = WIDGET_INFO[widget.id] || {
                  label: widget.id,
                  description: '',
                  iconEmoji: '📊',
                };
                return (
                  <div
                    key={widget.id}
                    className={`p-2.5 rounded-2xl border transition-all flex items-center justify-between gap-2.5 ${
                      widget.enabled
                        ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-2xs'
                        : 'bg-slate-50/70 dark:bg-slate-950/40 border-slate-200/50 dark:border-slate-800/40 opacity-50'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0 flex-1">
                      <span className="text-base select-none">{info.iconEmoji}</span>
                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {info.label}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate">
                          {info.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1 shrink-0">
                      {/* Subir / Bajar */}
                      <button
                        type="button"
                        onClick={() => handleMoveWidget(idx, 'up')}
                        disabled={idx === 0}
                        title="Mover arriba"
                        className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveWidget(idx, 'down')}
                        disabled={idx === widgets.length - 1}
                        title="Mover abajo"
                        className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      {/* Toggle visible */}
                      <button
                        type="button"
                        onClick={() => handleToggleWidget(widget.id)}
                        title={widget.enabled ? 'Ocultar widget' : 'Activar widget'}
                        className={`p-1.5 rounded-xl border transition-colors ml-1 ${
                          widget.enabled
                            ? 'bg-indigo-50 dark:bg-indigo-950/70 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400'
                            : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'
                        }`}
                      >
                        {widget.enabled ? (
                          <Eye className="w-3.5 h-3.5" />
                        ) : (
                          <EyeOff className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-2 px-5 py-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-colors"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center space-x-1.5 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors disabled:opacity-50"
          >
            <Check className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Guardando...' : 'Guardar y Aplicar'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
