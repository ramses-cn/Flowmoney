import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  FileText,
  SlidersHorizontal,
  Bell,
  Sliders,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Download,
  Calendar,
  Check,
} from 'lucide-react';
import { ExportDataSection } from '../profile/ExportDataSection.tsx';
import { AlertSettingsSection } from '../profile/AlertSettingsSection.tsx';
import { ManageCategoriesModal } from '../profile/ManageCategoriesModal.tsx';

interface QuickToolHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'export' | 'alerts' | 'categories';
  onNavigateToTab?: (tab: 'home' | 'expenses' | 'groups' | 'profile') => void;
  onOpenConfigureWidgets?: () => void;
}

export const QuickToolHubModal: React.FC<QuickToolHubModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'export',
  onNavigateToTab,
  onOpenConfigureWidgets,
}) => {
  const [activeTab, setActiveTab] = useState<'export' | 'alerts' | 'categories'>(initialTab);
  const [showManageCatModal, setShowManageCatModal] = useState(false);

  // Sincronizar si cambia initialTab
  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Cabecera del Centro de Herramientas */}
        <div className="p-4 sm:px-6 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center space-x-2">
                <span>Herramientas Financieras</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60">
                  Acceso Rápido
                </span>
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Reportes en vivo, configuración de alertas por umbrales y categorías
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded-xl transition-colors"
            title="Cerrar ventana"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Barra de Pestañas de Herramientas */}
        <div className="px-4 sm:px-6 pt-2 pb-0 bg-slate-50/50 dark:bg-slate-800/40 border-b border-slate-200/70 dark:border-slate-800 flex items-center space-x-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('export')}
            className={`pb-2.5 px-3 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-all ${
              activeTab === 'export'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Reportes y Descarga</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('alerts')}
            className={`pb-2.5 px-3 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-all ${
              activeTab === 'alerts'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Alertas y Umbrales</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('categories')}
            className={`pb-2.5 px-3 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-all ${
              activeTab === 'categories'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Categorías y Presupuesto</span>
          </button>
        </div>

        {/* Contenido Dinámico de la Pestaña Activa */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'export' && (
            <div className="animate-fade-in">
              <ExportDataSection hideHeader={true} />
            </div>
          )}

          {activeTab === 'alerts' && (
            <div className="animate-fade-in">
              <AlertSettingsSection />
            </div>
          )}

          {activeTab === 'categories' && (
            <div className="animate-fade-in space-y-4">
              <div className="p-4 bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 rounded-2xl flex items-start space-x-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <SlidersHorizontal className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    Gestión y Personalización de Categorías
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Crea, edita nombres, asigna colores e íconos y define los presupuestos mensuales de tus categorías de gasto para automatizar las alertas.
                  </p>
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowManageCatModal(true)}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs flex items-center space-x-1.5"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Abrir Gestor de Categorías</span>
                    </button>
                    {onNavigateToTab && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onNavigateToTab('profile');
                        }}
                        className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-colors"
                      >
                        Ver Presupuestos en Perfil
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal secundario para editar categorías si se abre desde aquí */}
      <ManageCategoriesModal
        isOpen={showManageCatModal}
        onClose={() => setShowManageCatModal(false)}
      />
    </div>
  );
};
