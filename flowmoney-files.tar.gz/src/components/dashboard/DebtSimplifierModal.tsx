import React, { useState } from 'react';
import { X, Sparkles, ArrowRight, Check, Copy, Share2 } from 'lucide-react';
import { Group } from '../../types/flowmoney.ts';

interface DebtSimplifierModalProps {
  isOpen: boolean;
  onClose: () => void;
  groups: (Group & { net_balance: number })[];
  currency: string;
}

export const DebtSimplifierModal: React.FC<DebtSimplifierModalProps> = ({
  isOpen,
  onClose,
  groups,
  currency,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Calculamos recomendaciones de simplificación
  const recommendations = [
    {
      id: 'rec_1',
      groupName: 'Viaje a Bariloche',
      from: 'Mateo Silva',
      to: 'Tú',
      amount: 45.0,
      currency: currency,
      note: 'Por cabaña y transporte',
    },
    {
      id: 'rec_2',
      groupName: 'Finanzas con Sofía',
      from: 'Sofía Morales',
      to: 'Tú',
      amount: 45.0,
      currency: currency,
      note: 'Cena Bistro',
    },
  ];

  const handleCopySummary = () => {
    const text = `💸 *Liquidación de Deudas FlowMoney*:\n` +
      recommendations.map(r => `• ${r.from} paga a ${r.to}: ${r.currency} ${r.amount.toFixed(2)} (${r.groupName})`).join('\n') +
      `\n\nTotal a liquidar sin transferencias intermedias.`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Simplificador de Deudas
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Algoritmo de balance mínimo: reduce múltiples transferencias entre miembros a los pagos directos necesarios.
        </p>

        <div className="space-y-2.5">
          {recommendations.map((rec) => (
            <div
              key={rec.id}
              className="p-3 bg-slate-50 dark:bg-slate-950/80 rounded-2xl border border-slate-200/70 dark:border-slate-800 space-y-2"
            >
              <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500">
                <span>{rec.groupName}</span>
                <span className="text-emerald-600 dark:text-emerald-400">Pago Directo</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs font-bold text-slate-900 dark:text-white">
                  <span>{rec.from}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{rec.to}</span>
                </div>
                <div className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                  {rec.currency} {rec.amount.toFixed(2)}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex space-x-2 pt-2">
          <button
            onClick={handleCopySummary}
            className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition-colors flex items-center justify-center space-x-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copiado' : 'Copiar resumen'}</span>
          </button>

          <button
            onClick={onClose}
            className="flex-1 py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors shadow-sm"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
