import React from 'react';
import { Home, Receipt, Plus, Users, User } from 'lucide-react';
import { motion } from 'motion/react';

export type TabType = 'home' | 'expenses' | 'add' | 'groups' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenAddModal: () => void;
}

/**
 * BottomNav rediseñado con estética Apple (iOS Tab Bar):
 * - Frosted glass con saturación (backdrop-blur + saturate)
 * - Indicador píldora con spring animation
 * - Color azul iOS (#007AFF) en tab activo
 * - Botón central "+" con elevación y gradiente
 * - Border-radius generoso y sombra multicapa
 */
export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onSelectTab, onOpenAddModal }) => {
  const tabs: { id: TabType; label: string; icon: React.FC<{ className?: string; style?: React.CSSProperties }> }[] = [
    { id: 'home', label: 'Inicio', icon: Home },
    { id: 'expenses', label: 'Gastos', icon: Receipt },
    { id: 'groups', label: 'Grupos', icon: Users },
    { id: 'profile', label: 'Perfil', icon: User },
  ];

  return (
    <nav
      id="bottom-navigation-bar"
      className="fixed bottom-3 sm:bottom-4 left-3 right-3 sm:left-1/2 sm:-translate-x-1/2 z-40 w-[calc(100%-1.5rem)] sm:w-full sm:max-w-md safe-area-x"
      style={{
        background: 'rgba(255, 255, 255, 0.72)',
        backdropFilter: 'blur(24px) saturate(180%)',
        WebkitBackdropFilter: 'blur(24px) saturate(180%)',
        border: '0.5px solid rgba(255, 255, 255, 0.18)',
        borderRadius: '28px',
        boxShadow: '0 12px 32px rgba(0, 0, 0, 0.08), 0 4px 8px rgba(0, 0, 0, 0.04)'
      }}
    >
      <div className="flex items-center justify-between h-[64px] px-3 relative">
        {/* Tab 1: Home */}
        <button
          id="nav-tab-home"
          type="button"
          onClick={() => onSelectTab('home')}
          className="relative flex-1 flex flex-col items-center justify-center h-full py-1 focus:outline-none group"
        >
          <div className="relative z-10 flex flex-col items-center">
            <Home
              className="w-[22px] h-[22px] transition-all duration-200"
              style={{
                color: activeTab === 'home' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transform: activeTab === 'home' ? 'scale(1.05)' : 'scale(1)',
                transition: 'all 0.2s var(--ease-apple)'
              }}
            />
            <span
              className="text-[10px] font-semibold mt-1 tracking-tight"
              style={{
                color: activeTab === 'home' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transition: 'color 0.2s var(--ease-apple)'
              }}
            >
              Inicio
            </span>
          </div>
          {activeTab === 'home' && (
            <motion.div
              layoutId="bottomNavIndicator"
              className="absolute inset-x-2 inset-y-2 rounded-[12px] -z-0"
              style={{ background: 'rgba(0, 122, 255, 0.10)' }}
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            />
          )}
        </button>

        {/* Tab 2: Gastos */}
        <button
          id="nav-tab-expenses"
          type="button"
          onClick={() => onSelectTab('expenses')}
          className="relative flex-1 flex flex-col items-center justify-center h-full py-1 focus:outline-none group"
        >
          <div className="relative z-10 flex flex-col items-center">
            <Receipt
              className="w-[22px] h-[22px]"
              style={{
                color: activeTab === 'expenses' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transform: activeTab === 'expenses' ? 'scale(1.05)' : 'scale(1)',
                transition: 'all 0.2s var(--ease-apple)'
              }}
            />
            <span
              className="text-[10px] font-semibold mt-1 tracking-tight"
              style={{
                color: activeTab === 'expenses' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transition: 'color 0.2s var(--ease-apple)'
              }}
            >
              Gastos
            </span>
          </div>
          {activeTab === 'expenses' && (
            <motion.div
              layoutId="bottomNavIndicator"
              className="absolute inset-x-2 inset-y-2 rounded-[12px] -z-0"
              style={{ background: 'rgba(0, 122, 255, 0.10)' }}
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            />
          )}
        </button>

        {/* Tab 3: Botón Central Añadir Gasto — Apple FAB */}
        <div className="relative -mt-7 px-1 z-20">
          <motion.button
            id="nav-tab-add"
            type="button"
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={onOpenAddModal}
            className="w-14 h-14 rounded-[20px] flex items-center justify-center transition-shadow focus:outline-none"
            style={{
              background: 'linear-gradient(135deg, #007AFF 0%, #5856D6 100%)',
              color: '#FFFFFF',
              boxShadow: '0 8px 24px rgba(0, 122, 255, 0.4), 0 2px 8px rgba(88, 86, 214, 0.25)',
              border: '3px solid var(--ios-bg-primary)'
            }}
            aria-label="Añadir nuevo gasto"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </motion.button>
        </div>

        {/* Tab 4: Grupos */}
        <button
          id="nav-tab-groups"
          type="button"
          onClick={() => onSelectTab('groups')}
          className="relative flex-1 flex flex-col items-center justify-center h-full py-1 focus:outline-none group"
        >
          <div className="relative z-10 flex flex-col items-center">
            <Users
              className="w-[22px] h-[22px]"
              style={{
                color: activeTab === 'groups' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transform: activeTab === 'groups' ? 'scale(1.05)' : 'scale(1)',
                transition: 'all 0.2s var(--ease-apple)'
              }}
            />
            <span
              className="text-[10px] font-semibold mt-1 tracking-tight"
              style={{
                color: activeTab === 'groups' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transition: 'color 0.2s var(--ease-apple)'
              }}
            >
              Grupos
            </span>
          </div>
          {activeTab === 'groups' && (
            <motion.div
              layoutId="bottomNavIndicator"
              className="absolute inset-x-2 inset-y-2 rounded-[12px] -z-0"
              style={{ background: 'rgba(0, 122, 255, 0.10)' }}
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            />
          )}
        </button>

        {/* Tab 5: Perfil */}
        <button
          id="nav-tab-profile"
          type="button"
          onClick={() => onSelectTab('profile')}
          className="relative flex-1 flex flex-col items-center justify-center h-full py-1 focus:outline-none group"
        >
          <div className="relative z-10 flex flex-col items-center">
            <User
              className="w-[22px] h-[22px]"
              style={{
                color: activeTab === 'profile' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transform: activeTab === 'profile' ? 'scale(1.05)' : 'scale(1)',
                transition: 'all 0.2s var(--ease-apple)'
              }}
            />
            <span
              className="text-[10px] font-semibold mt-1 tracking-tight"
              style={{
                color: activeTab === 'profile' ? 'var(--ios-blue)' : 'var(--ios-label-tertiary)',
                transition: 'color 0.2s var(--ease-apple)'
              }}
            >
              Perfil
            </span>
          </div>
          {activeTab === 'profile' && (
            <motion.div
              layoutId="bottomNavIndicator"
              className="absolute inset-x-2 inset-y-2 rounded-[12px] -z-0"
              style={{ background: 'rgba(0, 122, 255, 0.10)' }}
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            />
          )}
        </button>
      </div>
    </nav>
  );
};
