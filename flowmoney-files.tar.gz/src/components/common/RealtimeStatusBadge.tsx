import React from 'react';
import { RefreshCw, Radio, WifiOff } from 'lucide-react';

interface RealtimeStatusBadgeProps {
  isRealtimeActive: boolean;
  isPollingFallback: boolean;
  lastEventAt?: Date | null;
  onManualRefresh?: () => void;
  className?: string;
}

export const RealtimeStatusBadge: React.FC<RealtimeStatusBadgeProps> = ({
  isRealtimeActive,
  isPollingFallback,
  lastEventAt,
  onManualRefresh,
  className = '',
}) => {
  if (!isRealtimeActive && !isPollingFallback) {
    return null;
  }

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium transition-all ${
        isRealtimeActive
          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/40'
          : 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/40'
      } ${className}`}
      title={
        isRealtimeActive
          ? `Sincronización en vivo activa ${lastEventAt ? `(última actualización: ${lastEventAt.toLocaleTimeString()})` : ''}`
          : 'Modo respaldo: actualizando automáticamente cada 30s'
      }
    >
      {isRealtimeActive ? (
        <>
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="tracking-tight">En vivo</span>
        </>
      ) : (
        <>
          <RefreshCw className="w-2.5 h-2.5 animate-spin" />
          <span className="tracking-tight">Auto 30s</span>
        </>
      )}

      {onManualRefresh && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onManualRefresh();
          }}
          className="ml-0.5 hover:opacity-75 focus:outline-none"
          title="Refrescar ahora"
        >
          <RefreshCw className="w-2.5 h-2.5" />
        </button>
      )}
    </div>
  );
};
