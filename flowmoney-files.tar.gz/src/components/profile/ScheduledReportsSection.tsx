import React, { useState, useEffect, useCallback } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import {
  ScheduledReport,
  ScheduledReportFrequency,
  ScheduledReportFormat,
  ScheduledReportType,
  ReportSectionItem,
  ReportExecutionLog,
} from '../../types/flowmoney.ts';
import {
  Calendar,
  Clock,
  Mail,
  FileText,
  FileSpreadsheet,
  Send,
  Plus,
  Trash2,
  Check,
  AlertCircle,
  Play,
  Loader2,
  CheckCircle2,
  Sliders,
  History,
  ShieldCheck,
  Layers,
  X,
  Sparkles,
} from 'lucide-react';

export const ScheduledReportsSection: React.FC = () => {
  const { token, profile } = useAuthStore();
  const [reports, setReports] = useState<ScheduledReport[]>([]);
  const [logs, setLogs] = useState<ReportExecutionLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'schedules' | 'logs'>('schedules');

  // Estado para crear / editar reporte
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);

  // Campos del formulario
  const [name, setName] = useState('Resumen Financiero Automático');
  const [frequency, setFrequency] = useState<ScheduledReportFrequency>('monthly');
  const [scheduleDayOfWeek, setScheduleDayOfWeek] = useState(1); // Lunes
  const [scheduleDayOfMonth, setScheduleDayOfMonth] = useState(1);
  const [scheduleTime, setScheduleTime] = useState('08:00');
  const [periodType, setPeriodType] = useState<string>('month');
  const [reportType, setReportType] = useState<ScheduledReportType>('financial_summary');
  const [format, setFormat] = useState<ScheduledReportFormat>('pdf');
  const [recipientEmail, setRecipientEmail] = useState(profile?.email || '');
  const [exportDestination, setExportDestination] = useState<'email' | 'download_only'>('email');

  // Secciones a incluir
  const [includedSections, setIncludedSections] = useState<ReportSectionItem[]>([
    'income',
    'expenses',
    'balance',
    'categories',
    'budgets',
    'variation',
  ]);

  const showToast = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3000);
  };

  const fetchReports = useCallback(async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/reports/scheduled', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setReports(data.reports || []);
      }
    } catch (err) {
      console.error('Error cargando reportes programados:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  const fetchLogs = useCallback(async () => {
    if (!token) return;
    setIsLoadingLogs(true);
    try {
      const res = await fetch('/api/reports/logs', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setLogs(data.logs || []);
      }
    } catch (err) {
      console.error('Error cargando historial de reportes:', err);
    } finally {
      setIsLoadingLogs(false);
    }
  }, [token]);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  useEffect(() => {
    if (activeTab === 'logs') {
      fetchLogs();
    }
  }, [activeTab, fetchLogs]);

  const handleToggleActive = async (report: ScheduledReport) => {
    if (!token) return;
    const updatedStatus = !report.is_active;
    try {
      setReports((prev) =>
        prev.map((r) => (r.id === report.id ? { ...r, is_active: updatedStatus } : r))
      );

      await fetch(`/api/reports/scheduled/${report.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: report.name,
          frequency: report.frequency,
          schedule_time: report.schedule_time,
          is_active: updatedStatus,
          recipient_email: report.recipient_email,
        }),
      });

      showToast(updatedStatus ? 'Reporte activado' : 'Reporte pausado');
    } catch {
      fetchReports();
    }
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    try {
      setReports((prev) => prev.filter((r) => r.id !== id));
      await fetch(`/api/reports/scheduled/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      showToast('Programación de reporte eliminada');
    } catch {
      fetchReports();
    }
  };

  const handleRunNow = async (id: string) => {
    if (!token) return;
    setTestingId(id);
    try {
      const res = await fetch(`/api/reports/scheduled/${id}/run-now`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        showToast('¡Reporte generado y enviado con éxito!');
        fetchReports();
        fetchLogs();
      } else {
        const err = await res.json();
        showToast(err.message || 'Error al ejecutar reporte');
      }
    } catch (err) {
      showToast('Fallo temporal al generar el reporte');
    } finally {
      setTestingId(null);
    }
  };

  const toggleSection = (section: ReportSectionItem) => {
    setIncludedSections((prev) =>
      prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]
    );
  };

  const handleCreateReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/reports/scheduled', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          frequency,
          schedule_day_of_week: scheduleDayOfWeek,
          schedule_day_of_month: scheduleDayOfMonth,
          schedule_time: scheduleTime,
          period_type: periodType,
          report_type: reportType,
          include_sections: includedSections,
          format,
          export_destination: exportDestination,
          recipient_email: recipientEmail || profile?.email,
          is_active: true,
        }),
      });

      if (res.ok) {
        showToast('¡Reporte programado exitosamente!');
        setShowCreateModal(false);
        fetchReports();
      } else {
        const data = await res.json();
        showToast(data.error || 'Error al programar reporte');
      }
    } catch (err) {
      showToast('Error de red al guardar reporte');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatFrequencyLabel = (r: ScheduledReport) => {
    switch (r.frequency) {
      case 'daily':
        return `Diario a las ${r.schedule_time}`;
      case 'weekly': {
        const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
        return `Semanal (${days[r.schedule_day_of_week ?? 1]}) a las ${r.schedule_time}`;
      }
      case 'biweekly':
        return `Quincenal (Días 1 y 15) a las ${r.schedule_time}`;
      case 'monthly':
        return `Mensual (Día ${r.schedule_day_of_month ?? 1}) a las ${r.schedule_time}`;
      case 'custom':
        return `Personalizado a las ${r.schedule_time}`;
      default:
        return r.frequency;
    }
  };

  return (
    <section id="scheduled-reports-section" className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
      {/* Encabezado con pestañas */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border border-indigo-100 dark:border-indigo-900/50">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
              Reportes Programados
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
              Emisión automática periódica en PDF, Excel y CSV
            </p>
          </div>
        </div>

        <button
          id="btn-add-scheduled-report"
          type="button"
          onClick={() => {
            setRecipientEmail(profile?.email || '');
            setShowCreateModal(true);
          }}
          className="inline-flex items-center space-x-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white rounded-xl text-xs font-semibold shadow-xs transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Programar</span>
        </button>
      </div>

      {/* Tabs: Programaciones vs Historial */}
      <div className="flex bg-slate-100 dark:bg-slate-800/70 p-1 rounded-2xl text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('schedules')}
          className={`flex-1 py-1.5 rounded-xl font-bold transition-all text-center ${
            activeTab === 'schedules'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'
          }`}
        >
          Programaciones ({reports.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('logs')}
          className={`flex-1 py-1.5 rounded-xl font-bold transition-all text-center ${
            activeTab === 'logs'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'
          }`}
        >
          Historial de Envíos
        </button>
      </div>

      {/* Feedback Toast */}
      {feedback && (
        <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 text-emerald-800 dark:text-emerald-300 text-xs rounded-xl flex items-center space-x-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{feedback}</span>
        </div>
      )}

      {/* Vista de Programaciones */}
      {activeTab === 'schedules' && (
        <>
          {isLoading ? (
            <div className="py-8 flex flex-col items-center justify-center space-y-2 text-slate-400">
              <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
              <span className="text-xs">Cargando programaciones...</span>
            </div>
          ) : reports.length === 0 ? (
            <div className="py-8 text-center bg-slate-50 dark:bg-slate-800/30 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-6 space-y-2">
              <Clock className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                No tienes reportes automáticos programados
              </p>
              <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                Programa resúmenes automáticos (diarios, semanales, mensuales) que llegarán directamente a tu correo electrónico en formato PDF o Excel.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((rep) => {
                const isTesting = testingId === rep.id;
                return (
                  <div
                    key={rep.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      rep.is_active
                        ? 'bg-white dark:bg-slate-850 border-slate-200/90 dark:border-slate-800 shadow-xs'
                        : 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200/40 dark:border-slate-850 opacity-60'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {rep.name}
                          </span>
                          <span className="px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/60">
                            {rep.format.toUpperCase()}
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center space-x-1.5">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{formatFrequencyLabel(rep)}</span>
                        </p>

                        <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center space-x-1.5">
                          <Mail className="w-3 h-3 text-slate-400" />
                          <span className="truncate max-w-[200px]">{rep.recipient_email}</span>
                        </p>
                      </div>

                      {/* Switch On/Off */}
                      <button
                        type="button"
                        onClick={() => handleToggleActive(rep)}
                        className={`w-10 h-5 rounded-full transition-colors relative flex items-center p-0.5 ${
                          rep.is_active ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                        }`}
                        aria-label="Activar o pausar reporte"
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transition-transform ${
                            rep.is_active ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Botonera inferior */}
                    <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-[10px] text-slate-400">
                        {rep.last_run_at
                          ? `Último envío: ${new Date(rep.last_run_at).toLocaleDateString('es-ES')}`
                          : 'Pendiente de primera ejecución'}
                      </span>

                      <div className="flex items-center space-x-1.5">
                        {/* Botón Ejecutar Ahora */}
                        <button
                          type="button"
                          onClick={() => handleRunNow(rep.id)}
                          disabled={isTesting}
                          className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/40 dark:hover:text-indigo-400 text-slate-700 dark:text-slate-300 rounded-lg text-[11px] font-semibold flex items-center space-x-1 transition-colors disabled:opacity-50"
                          title="Ejecutar reporte y enviar prueba inmediata"
                        >
                          {isTesting ? (
                            <Loader2 className="w-3 h-3 animate-spin text-indigo-500" />
                          ) : (
                            <Play className="w-3 h-3" />
                          )}
                          <span>Enviar ahora</span>
                        </button>

                        {/* Botón Eliminar */}
                        <button
                          type="button"
                          onClick={() => handleDelete(rep.id)}
                          className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                          title="Eliminar programación"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Vista de Historial / Auditoría de Envíos */}
      {activeTab === 'logs' && (
        <div className="space-y-2">
          {isLoadingLogs ? (
            <div className="py-8 flex flex-col items-center justify-center space-y-2 text-slate-400">
              <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
              <span className="text-xs">Cargando bitácora de auditoría...</span>
            </div>
          ) : logs.length === 0 ? (
            <div className="py-6 text-center text-slate-400 text-xs">
              Aún no se registran ejecuciones automáticas de reportes.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto pr-1">
              {logs.map((log) => (
                <div key={log.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-1.5">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          log.status === 'success' ? 'bg-emerald-500' : 'bg-rose-500'
                        }`}
                      />
                      <span className="font-bold text-slate-800 dark:text-slate-200">
                        {log.file_name || 'Reporte Financiero'}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400">
                      Enviado a: {log.recipient_email} • {new Date(log.generated_at).toLocaleString('es-ES')}
                    </p>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      log.status === 'success'
                        ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                        : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300'
                    }`}
                  >
                    {log.status === 'success' ? 'Entregado' : 'Fallido'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal para Crear / Programar Reporte */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fade-in overflow-y-auto">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center">
                  <Calendar className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Programar Reporte Automático
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateReport} className="space-y-3.5">
              {/* Nombre */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nombre del Reporte
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ej. Resumen Mensual Familiar"
                  required
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                />
              </div>

              {/* Frecuencia */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Frecuencia
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as ScheduledReportFrequency)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="daily">Diario</option>
                    <option value="weekly">Semanal</option>
                    <option value="biweekly">Quincenal</option>
                    <option value="monthly">Mensual</option>
                    <option value="custom">Personalizado</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Hora de envío
                  </label>
                  <input
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Día según frecuencia */}
              {frequency === 'weekly' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Día de la semana
                  </label>
                  <select
                    value={scheduleDayOfWeek}
                    onChange={(e) => setScheduleDayOfWeek(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value={1}>Lunes</option>
                    <option value={2}>Martes</option>
                    <option value={3}>Miércoles</option>
                    <option value={4}>Jueves</option>
                    <option value={5}>Viernes</option>
                    <option value={6}>Sábado</option>
                    <option value={0}>Domingo</option>
                  </select>
                </div>
              )}

              {frequency === 'monthly' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Día del mes (1 - 31)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={scheduleDayOfMonth}
                    onChange={(e) => setScheduleDayOfMonth(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              )}

              {/* Período de datos y Formato */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Período auditado
                  </label>
                  <select
                    value={periodType}
                    onChange={(e) => setPeriodType(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="month">Mes actual</option>
                    <option value="week">Esta semana</option>
                    <option value="last_7_days">Últimos 7 días</option>
                    <option value="last_30_days">Últimos 30 días</option>
                    <option value="last_90_days">Últimos 90 días</option>
                    <option value="year">Año actual</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Formato de exportación
                  </label>
                  <select
                    value={format}
                    onChange={(e) => setFormat(e.target.value as ScheduledReportFormat)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="pdf">Documento PDF membretado</option>
                    <option value="excel">Hoja de cálculo (Excel)</option>
                    <option value="csv">Archivo CSV de datos</option>
                  </select>
                </div>
              </div>

              {/* Correo destinatario */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Enviar a correo electrónico
                </label>
                <input
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="usuario@ejemplo.com"
                  required
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                />
              </div>

              {/* Contenido / Secciones a incluir */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Contenido incluido en el reporte
                </label>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  {[
                    { id: 'income', label: 'Ingresos' },
                    { id: 'expenses', label: 'Gastos' },
                    { id: 'balance', label: 'Balance' },
                    { id: 'categories', label: 'Categorías' },
                    { id: 'budgets', label: 'Presupuestos' },
                    { id: 'variation', label: 'Variación' },
                    { id: 'subscriptions', label: 'Suscripciones' },
                    { id: 'debts', label: 'Deudas / Grupos' },
                  ].map((sec) => {
                    const isChecked = includedSections.includes(sec.id as ReportSectionItem);
                    return (
                      <label
                        key={sec.id}
                        className={`flex items-center space-x-2 p-2 rounded-xl border cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900/60 text-indigo-700 dark:text-indigo-300'
                            : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSection(sec.id as ReportSectionItem)}
                          className="rounded text-indigo-600 accent-indigo-600"
                        />
                        <span className="text-[11px] font-medium">{sec.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Botones */}
              <div className="flex items-center space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || includedSections.length === 0}
                  className="flex-1 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs disabled:opacity-50 flex items-center justify-center space-x-1"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Check className="w-3.5 h-3.5" />
                  )}
                  <span>Activar Programación</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
