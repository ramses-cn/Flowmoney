import React, { useState, useEffect, useCallback } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { AlertRule } from '../../types/flowmoney.ts';
import {
  Bell,
  Mail,
  AlertTriangle,
  Plus,
  Trash2,
  Check,
  ShieldCheck,
  Percent,
  Sliders,
  Sparkles,
  Info,
  Loader2,
  CheckCircle2,
  X,
  Edit2,
} from 'lucide-react';

interface AlertSettingsSectionProps {
  onTriggerRefresh?: () => void;
}

export const AlertSettingsSection: React.FC<AlertSettingsSectionProps> = ({ onTriggerRefresh }) => {
  const { token, profile } = useAuthStore();
  const [rules, setRules] = useState<AlertRule[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Edición directa de umbral en regla existente
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [editThresholdValue, setEditThresholdValue] = useState<number>(50);
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Modal para nueva regla personalizada
  const [showAddModal, setShowAddModal] = useState(false);
  const [newThreshold, setNewThreshold] = useState<number>(85);
  const [newInApp, setNewInApp] = useState(true);
  const [newEmail, setNewEmail] = useState(false);
  const [newTargetEmail, setNewTargetEmail] = useState(profile?.email || '');
  const [isSavingNew, setIsSavingNew] = useState(false);

  const showToast = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3000);
  };

  const fetchRules = useCallback(async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/alerts/rules', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setRules(data.rules || []);
      }
    } catch (err) {
      console.error('Error cargando reglas de alerta:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchRules();
  }, [fetchRules]);

  const handleToggleRuleActive = async (rule: AlertRule) => {
    if (!token) return;
    const updatedStatus = !rule.is_active;
    try {
      // Optimistic update
      setRules((prev) =>
        prev.map((r) => (r.id === rule.id ? { ...r, is_active: updatedStatus } : r))
      );

      const res = await fetch(`/api/alerts/rules/${rule.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          threshold_percent: rule.threshold_percent,
          is_active: updatedStatus,
          notify_in_app: rule.notify_in_app,
          notify_email: rule.notify_email,
          target_email: rule.target_email,
        }),
      });

      if (!res.ok) {
        fetchRules();
      } else {
        showToast(updatedStatus ? `Alerta del ${rule.threshold_percent}% activada` : `Alerta pausada`);
        onTriggerRefresh?.();
      }
    } catch {
      fetchRules();
    }
  };

  const handleToggleChannel = async (rule: AlertRule, channel: 'in_app' | 'email') => {
    if (!token) return;
    const newInApp = channel === 'in_app' ? !rule.notify_in_app : rule.notify_in_app;
    const newEmail = channel === 'email' ? !rule.notify_email : rule.notify_email;

    // Al menos un canal debe estar activo si la regla está encendida
    if (!newInApp && !newEmail && rule.is_active) {
      showToast('Debes mantener al menos un canal activo (App o Correo)');
      return;
    }

    try {
      setRules((prev) =>
        prev.map((r) =>
          r.id === rule.id
            ? { ...r, notify_in_app: newInApp, notify_email: newEmail }
            : r
        )
      );

      await fetch(`/api/alerts/rules/${rule.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          threshold_percent: rule.threshold_percent,
          is_active: rule.is_active,
          notify_in_app: newInApp,
          notify_email: newEmail,
          target_email: profile?.email || rule.target_email,
        }),
      });

      showToast(`Canal de ${channel === 'in_app' ? 'App' : 'Correo'} actualizado`);
      onTriggerRefresh?.();
    } catch {
      fetchRules();
    }
  };

  const handleDeleteRule = async (id: string) => {
    if (!token) return;
    try {
      setRules((prev) => prev.filter((r) => r.id !== id));
      await fetch(`/api/alerts/rules/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      showToast('Umbral de alerta eliminado');
      onTriggerRefresh?.();
    } catch {
      fetchRules();
    }
  };

  const handleSaveThresholdEdit = async (rule: AlertRule) => {
    if (!token || isNaN(editThresholdValue) || editThresholdValue <= 0) return;
    setIsSavingEdit(true);
    try {
      const res = await fetch(`/api/alerts/rules/${rule.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          threshold_percent: editThresholdValue,
          is_active: rule.is_active,
          notify_in_app: rule.notify_in_app,
          notify_email: rule.notify_email,
          target_email: rule.target_email,
        }),
      });

      if (res.ok) {
        setRules((prev) =>
          prev.map((r) =>
            r.id === rule.id ? { ...r, threshold_percent: editThresholdValue } : r
          )
        );
        showToast(`Umbral actualizado al ${editThresholdValue}%`);
        setEditingRuleId(null);
        onTriggerRefresh?.();
      }
    } catch {
      fetchRules();
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleCreateCustomRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsSavingNew(true);
    try {
      const res = await fetch('/api/alerts/rules', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          threshold_percent: newThreshold,
          is_active: true,
          notify_in_app: newInApp,
          notify_email: newEmail,
          target_email: newEmail ? (newTargetEmail || profile?.email) : null,
        }),
      });

      if (res.ok) {
        showToast(`Alerta de ${newThreshold}% guardada exitosamente`);
        setShowAddModal(false);
        fetchRules();
        onTriggerRefresh?.();
      }
    } catch (err) {
      console.error('Error creando alerta:', err);
    } finally {
      setIsSavingNew(false);
    }
  };

  // Helper para estilizar el umbral
  const getBadgeStyle = (percent: number) => {
    if (percent >= 100) return 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/60';
    if (percent >= 80) return 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-900/60';
    return 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 border-indigo-200 dark:border-indigo-900/60';
  };

  return (
    <section id="alert-settings-section" className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
      {/* Encabezado */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border border-indigo-100 dark:border-indigo-900/50">
            <Bell className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
              Alertas de Presupuesto
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
              Avisos en tiempo real por umbral de gasto y exceso
            </p>
          </div>
        </div>

        <button
          id="btn-add-alert-rule"
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center space-x-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white rounded-xl text-xs font-semibold shadow-xs transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Configurar</span>
        </button>
      </div>

      {/* Feedback Toast */}
      {feedback && (
        <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 text-emerald-800 dark:text-emerald-300 text-xs rounded-xl flex items-center space-x-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{feedback}</span>
        </div>
      )}

      {/* Info explicativa */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-start space-x-2.5">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
          Recibe notificaciones automáticas al alcanzar el <strong>50%, 75%, 80%, 90%, 100%</strong> o al <strong>exceder</strong> tu presupuesto. Puedes activar avisos en pantalla o vía correo electrónico.
        </p>
      </div>

      {/* Lista de Umbrales Configurados */}
      {isLoading ? (
        <div className="py-8 flex flex-col items-center justify-center space-y-2 text-slate-400">
          <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
          <span className="text-xs">Cargando umbrales de presupuesto...</span>
        </div>
      ) : rules.length === 0 ? (
        <div className="py-6 text-center text-slate-400 text-xs">
          No hay reglas configuradas. Haz clic en "Configurar" para añadir un umbral.
        </div>
      ) : (
        <div className="space-y-2.5">
          {rules.map((rule) => {
            const isExcess = rule.threshold_percent >= 100;
            return (
              <div
                key={rule.id}
                className={`p-3 rounded-2xl border transition-all ${
                  rule.is_active
                    ? 'bg-white dark:bg-slate-850 border-slate-200/90 dark:border-slate-800 shadow-xs'
                    : 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200/40 dark:border-slate-850 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  {/* Umbral Porcentual */}
                  <div className="flex items-center space-x-2.5">
                    {editingRuleId === rule.id ? (
                      <div className="flex items-center space-x-1.5">
                        <input
                          type="number"
                          value={editThresholdValue}
                          onChange={(e) => setEditThresholdValue(Math.max(1, Number(e.target.value)))}
                          min="1"
                          max="300"
                          className="w-16 px-2 py-0.5 text-xs font-black bg-white dark:bg-slate-900 border border-indigo-500 rounded-lg text-slate-900 dark:text-white focus:outline-none"
                          autoFocus
                        />
                        <span className="text-xs font-bold text-slate-500">%</span>
                        <button
                          type="button"
                          onClick={() => handleSaveThresholdEdit(rule)}
                          disabled={isSavingEdit}
                          className="p-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                          title="Guardar umbral"
                        >
                          <Check className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingRuleId(null)}
                          className="p-1 bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-400 transition-colors"
                          title="Cancelar"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-1.5">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black border ${getBadgeStyle(
                            rule.threshold_percent
                          )}`}
                        >
                          {rule.threshold_percent}%
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingRuleId(rule.id);
                            setEditThresholdValue(rule.threshold_percent);
                          }}
                          className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                          title="Modificar porcentaje o umbral"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                    <div>
                      <p className="text-xs font-bold text-slate-850 dark:text-slate-200">
                        {isExcess
                          ? rule.threshold_percent === 100
                            ? 'Límite Máximo (100%)'
                            : `Exceso Presupuestario (${rule.threshold_percent}%)`
                          : `Alcanzado el ${rule.threshold_percent}% del presupuesto`}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {rule.category_name || 'Presupuesto general mensual'}
                      </p>
                    </div>
                  </div>

                  {/* Switch On/Off Principal */}
                  <button
                    type="button"
                    onClick={() => handleToggleRuleActive(rule)}
                    className={`w-10 h-5 rounded-full transition-colors relative flex items-center p-0.5 ${
                      rule.is_active ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                    aria-label="Activar o pausar alerta"
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform ${
                        rule.is_active ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Selector de Canales (App / Correo) */}
                {rule.is_active && (
                  <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      Canales:
                    </span>
                    <div className="flex items-center space-x-2">
                      {/* Botón App */}
                      <button
                        type="button"
                        onClick={() => handleToggleChannel(rule, 'in_app')}
                        className={`px-2 py-1 rounded-lg text-[11px] font-medium flex items-center space-x-1.5 transition-colors border ${
                          rule.notify_in_app
                            ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-900/60'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-transparent'
                        }`}
                      >
                        <Bell className="w-3 h-3" />
                        <span>En App</span>
                      </button>

                      {/* Botón Email */}
                      <button
                        type="button"
                        onClick={() => handleToggleChannel(rule, 'email')}
                        className={`px-2 py-1 rounded-lg text-[11px] font-medium flex items-center space-x-1.5 transition-colors border ${
                          rule.notify_email
                            ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-900/60'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-transparent'
                        }`}
                      >
                        <Mail className="w-3 h-3" />
                        <span>Correo</span>
                      </button>

                      {/* Eliminar regla */}
                      <button
                        type="button"
                        onClick={() => handleDeleteRule(rule.id)}
                        className="p-1 text-slate-400 hover:text-rose-500 transition-colors ml-1"
                        title="Eliminar regla"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal para añadir nuevo umbral */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center">
                  <Sliders className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Nuevo Umbral de Alerta
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomRule} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Porcentaje de consumo
                  </label>
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      min="1"
                      max="300"
                      value={newThreshold}
                      onChange={(e) => setNewThreshold(Math.max(1, Math.min(300, Number(e.target.value))))}
                      className="w-16 px-2 py-0.5 text-xs font-bold text-center bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
                    />
                    <span className="text-xs font-bold text-slate-500">%</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="25"
                  max="150"
                  step="5"
                  value={Math.min(150, Math.max(25, newThreshold))}
                  onChange={(e) => setNewThreshold(Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {[50, 75, 80, 90, 100, 120].map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setNewThreshold(t)}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-lg border transition-all ${
                        newThreshold === t
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-indigo-400'
                      }`}
                    >
                      {t}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Selección de canales */}
              <div className="space-y-2 pt-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                  Canales de notificación
                </span>

                <label className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl cursor-pointer">
                  <div className="flex items-center space-x-2 text-xs text-slate-800 dark:text-slate-200">
                    <Bell className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Notificación dentro de la app</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={newInApp}
                    onChange={(e) => setNewInApp(e.target.checked)}
                    className="rounded text-indigo-600 accent-indigo-600 w-4 h-4"
                  />
                </label>

                <label className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl cursor-pointer">
                  <div className="flex items-center space-x-2 text-xs text-slate-800 dark:text-slate-200">
                    <Mail className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Envío por correo electrónico</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={newEmail}
                    onChange={(e) => setNewEmail(e.target.checked)}
                    className="rounded text-indigo-600 accent-indigo-600 w-4 h-4"
                  />
                </label>

                {newEmail && (
                  <div className="pt-1">
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Correo destino
                    </label>
                    <input
                      type="email"
                      value={newTargetEmail}
                      onChange={(e) => setNewTargetEmail(e.target.value)}
                      placeholder="tu@correo.com"
                      required
                      className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                    />
                  </div>
                )}
              </div>

              {/* Botones de acción */}
              <div className="flex items-center space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSavingNew || (!newInApp && !newEmail)}
                  className="flex-1 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs disabled:opacity-50 flex items-center justify-center space-x-1"
                >
                  {isSavingNew ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  <span>Guardar Alerta</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
