import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { applyTheme, getSavedTheme, ThemeMode } from '../../utils/theme.ts';
import { ManageCategoriesModal } from './ManageCategoriesModal.tsx';
import {
  Sun,
  Moon,
  Monitor,
  Bell,
  Globe,
  Clock,
  Check,
  Smartphone,
  ShieldCheck,
  Trash2,
  AlertTriangle,
  Loader2,
  X,
  RotateCcw,
  Sparkles,
  Tag,
  ChevronRight,
} from 'lucide-react';

export const PreferencesSection: React.FC = () => {
  const { profile, updateProfileData, deleteMyAccount, resetUserData } = useAuthStore();
  const [currentTheme, setCurrentTheme] = useState<ThemeMode>(() => getSavedTheme());
  const [showManageCatModal, setShowManageCatModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [groupsWithBalance, setGroupsWithBalance] = useState<Array<{ id: string; name: string; balance: number }>>([]);

  // Reiniciar registros desde 0
  const [showResetModal, setShowResetModal] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  // Notificaciones
  const [notifyBudget, setNotifyBudget] = useState(() => {
    return localStorage.getItem('flowmoney_notify_budget') !== 'false';
  });
  const [notifySubs, setNotifySubs] = useState(() => {
    return localStorage.getItem('flowmoney_notify_subs') !== 'false';
  });
  const [notifyGroups, setNotifyGroups] = useState(() => {
    return localStorage.getItem('flowmoney_notify_groups') !== 'false';
  });

  // Idioma
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('flowmoney_lang') || 'es';
  });

  // Zona Horaria
  const [timezone, setTimezone] = useState(() => {
    return (
      localStorage.getItem('flowmoney_tz') ||
      Intl.DateTimeFormat().resolvedOptions().timeZone ||
      'America/Lima'
    );
  });

  const [savedFeedback, setSavedFeedback] = useState<string | null>(null);

  const showFeedback = (msg: string) => {
    setSavedFeedback(msg);
    setTimeout(() => setSavedFeedback(null), 2000);
  };

  const handleSelectTheme = (mode: ThemeMode) => {
    setCurrentTheme(mode);
    applyTheme(mode);
    updateProfileData({ theme: mode });
    showFeedback(
      mode === 'dark' ? 'Tema oscuro activado' : mode === 'light' ? 'Tema claro activado' : 'Tema automático según sistema'
    );
  };

  const handleToggleBudget = (val: boolean) => {
    setNotifyBudget(val);
    localStorage.setItem('flowmoney_notify_budget', String(val));
    showFeedback('Preferencia de presupuesto guardada');
  };

  const handleToggleSubs = (val: boolean) => {
    setNotifySubs(val);
    localStorage.setItem('flowmoney_notify_subs', String(val));
    showFeedback('Preferencia de suscripciones guardada');
  };

  const handleToggleGroups = (val: boolean) => {
    setNotifyGroups(val);
    localStorage.setItem('flowmoney_notify_groups', String(val));
    showFeedback('Preferencia de grupos guardada');
  };

  const handleLanguageChange = (lang: string) => {
    setLanguage(lang);
    localStorage.setItem('flowmoney_lang', lang);
    showFeedback('Idioma actualizado');
  };

  const handleTimezoneChange = (tz: string) => {
    setTimezone(tz);
    localStorage.setItem('flowmoney_tz', tz);
    showFeedback('Zona horaria actualizada');
  };

  return (
    <div id="preferences-section" className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/90 rounded-2xl p-5 shadow-xs space-y-5 transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Preferencias y Ajustes
          </h3>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
            Personaliza el tema visual, avisos e idioma de la aplicación
          </p>
        </div>
        {savedFeedback && (
          <span className="flex items-center space-x-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold animate-fade-in">
            <Check className="w-3.5 h-3.5" />
            <span>{savedFeedback}</span>
          </span>
        )}
      </div>

      {/* 1. Tema Claro / Oscuro / Sistema */}
      <div className="space-y-2">
        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
          Modo Visual (Tema)
        </label>
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => handleSelectTheme('light')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
              currentTheme === 'light'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Sun className="w-3.5 h-3.5 text-amber-500" />
            <span>Claro</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectTheme('dark')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
              currentTheme === 'dark'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
            <span>Oscuro</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectTheme('system')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
              currentTheme === 'system'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5 text-slate-400" />
            <span>Sistema</span>
          </button>
        </div>
      </div>

      {/* 2. Notificaciones y Alertas */}
      <div className="space-y-2.5 pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <Bell className="w-3.5 h-3.5 text-indigo-500" />
          <span>Notificaciones Inteligentes</span>
        </div>

        <div className="space-y-2">
          {/* Presupuesto */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/70 dark:border-slate-800/70">
            <div>
              <span className="text-xs font-bold text-slate-900 dark:text-white block">
                Alertas de Presupuesto
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Avisar cuando una categoría supere el 80% de su límite mensual
              </span>
            </div>
            <input
              type="checkbox"
              checked={notifyBudget}
              onChange={(e) => handleToggleBudget(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            />
          </div>

          {/* Suscripciones */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/70 dark:border-slate-800/70">
            <div>
              <span className="text-xs font-bold text-slate-900 dark:text-white block">
                Recordatorio de Suscripciones
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Aviso 3 días antes del cobro recurrente de un servicio
              </span>
            </div>
            <input
              type="checkbox"
              checked={notifySubs}
              onChange={(e) => handleToggleSubs(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            />
          </div>

          {/* Grupos */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/70 dark:border-slate-800/70">
            <div>
              <span className="text-xs font-bold text-slate-900 dark:text-white block">
                Actividad de Grupos
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Avisar cuando otro miembro registre gastos o pagos compartidos
              </span>
            </div>
            <input
              type="checkbox"
              checked={notifyGroups}
              onChange={(e) => handleToggleGroups(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 3. Categorías Personalizables */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/70 dark:border-slate-800/70">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 dark:text-white block">
                Categorías de Gastos
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Selecciona solo las categorías que necesitas, crea personalizadas y reordénalas
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowManageCatModal(true)}
            className="flex items-center space-x-1 px-3 py-1.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl transition-colors shadow-xs"
          >
            <span>Configurar</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>
      </div>

      {/* 4. Idioma y Zona Horaria */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <div>
          <label className="flex items-center space-x-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            <Globe className="w-3.5 h-3.5 text-indigo-500" />
            <span>Idioma</span>
          </label>
          <select
            value={language}
            onChange={(e) => handleLanguageChange(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white cursor-pointer"
          >
            <option value="es">Español (Latinoamérica / España)</option>
            <option value="en">English (United States)</option>
            <option value="pt">Português (Brasil)</option>
          </select>
        </div>

        <div>
          <label className="flex items-center space-x-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            <span>Zona Horaria</span>
          </label>
          <select
            value={timezone}
            onChange={(e) => handleTimezoneChange(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white cursor-pointer"
          >
            <option value="America/Lima">América / Lima (GMT-5)</option>
            <option value="America/Bogota">América / Bogotá (GMT-5)</option>
            <option value="America/Mexico_City">América / Ciudad de México (GMT-6)</option>
            <option value="America/Santiago">América / Santiago (GMT-3)</option>
            <option value="America/Argentina/Buenos_Aires">América / Buenos Aires (GMT-3)</option>
            <option value="Europe/Madrid">Europa / Madrid (GMT+1 / GMT+2)</option>
            <option value="America/New_York">América / Nueva York (GMT-5 / GMT-4)</option>
            <option value="UTC">UTC (Tiempo Universal Coordinado)</option>
          </select>
        </div>
      </div>

      {/* Zona de Reinicio: Comenzar registros desde 0 */}
      <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
        {resetSuccess && (
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-700 dark:text-emerald-300 flex items-center space-x-2 animate-fade-in">
            <Check className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{resetSuccess}</span>
          </div>
        )}

        <div className="bg-amber-50/60 dark:bg-amber-950/20 rounded-2xl border border-amber-200/80 dark:border-amber-900/40 p-4 space-y-3">
          <div className="flex items-start space-x-3">
            <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-400 shrink-0">
              <RotateCcw className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-amber-950 dark:text-amber-200">
                Comenzar Registros desde Cero (0.00)
              </h4>
              <p className="text-[11px] text-amber-800/80 dark:text-amber-300/80 mt-0.5 leading-relaxed">
                Limpia todos los gastos, préstamos grupales, suscripciones y cuentas grabadas previamente para iniciar una contabilidad totalmente nueva en <strong>Soles (S/ PEN)</strong>, sin borrar tu cuenta ni perder tu acceso.
              </p>
            </div>
          </div>

          <button
            id="reset-records-button"
            type="button"
            onClick={() => {
              setResetError(null);
              setShowResetModal(true);
            }}
            className="w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all active:scale-[0.99] flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Comenzar registros desde 0 (Limpiar historial)</span>
          </button>
        </div>
      </div>

      {/* Zona de Peligro: Eliminar cuenta */}
      <div className="pt-2">
        <div className="bg-rose-50/50 dark:bg-rose-950/20 rounded-2xl border border-rose-200/80 dark:border-rose-900/40 p-4 space-y-3">
          <div className="flex items-start space-x-3">
            <div className="p-2 rounded-xl bg-rose-100 dark:bg-rose-900/50 text-rose-600 dark:text-rose-400 shrink-0">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-rose-900 dark:text-rose-300">
                Zona de Peligro
              </h4>
              <p className="text-[11px] text-rose-700/80 dark:text-rose-400/80 mt-0.5 leading-relaxed">
                Elimina tu cuenta, perfil y credenciales de forma definitiva de FlowMoney.
              </p>
            </div>
          </div>

          <button
            id="delete-account-button"
            type="button"
            onClick={() => {
              setDeleteConfirmText('');
              setDeleteError(null);
              setGroupsWithBalance([]);
              setShowDeleteModal(true);
            }}
            className="w-full py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all active:scale-[0.99] flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Eliminar mi cuenta permanentemente</span>
          </button>
        </div>
      </div>

      {/* Modal de Reinicio desde 0 */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-amber-600 dark:text-amber-400">
                <RotateCcw className="w-5 h-5 shrink-0" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  ¿Comenzar registros desde cero?
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!isResetting) setShowResetModal(false);
                }}
                disabled={isResetting}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              <p>
                Esta acción restablecerá tu espacio de trabajo para que ingreses tus datos reales desde cero:
              </p>
              <ul className="list-disc list-inside space-y-1.5 text-[11px] text-slate-600 dark:text-slate-400 pl-1">
                <li>Se borrarán todos los gastos y movimientos registrados previamente.</li>
                <li>Se cancelarán deudas compartidas y grupos de prueba.</li>
                <li>Se creará una nueva <strong>Cuenta Principal</strong> limpia con saldo de <strong>S/ 0.00</strong>.</li>
                <li>Se establecerá la moneda <strong>Soles (PEN)</strong> por defecto en todo tu perfil.</li>
                <li>Tu cuenta, correo y sesión permanecerán 100% activas.</li>
              </ul>
            </div>

            {resetError && (
              <p className="text-[11px] text-rose-600 dark:text-rose-400 font-medium">
                {resetError}
              </p>
            )}

            <div className="flex items-center space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowResetModal(false)}
                disabled={isResetting}
                className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors"
              >
                Cancelar
              </button>
              <button
                id="confirm-reset-records-btn"
                type="button"
                disabled={isResetting}
                onClick={async () => {
                  setIsResetting(true);
                  setResetError(null);
                  try {
                    const ok = await resetUserData();
                    if (ok) {
                      setResetSuccess('¡Registros reiniciados exitosamente a 0.00 en Soles (PEN)!');
                      setShowResetModal(false);
                      setTimeout(() => setResetSuccess(null), 4000);
                    } else {
                      setResetError('No fue posible reiniciar los registros. Intenta nuevamente.');
                    }
                  } catch (err: any) {
                    setResetError(err.message || 'Error al reiniciar datos');
                  } finally {
                    setIsResetting(false);
                  }
                }}
                className="flex-1 py-2 px-3 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white transition-all flex items-center justify-center space-x-1.5 shadow-xs cursor-pointer active:scale-[0.98] disabled:opacity-50"
              >
                {isResetting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Reiniciando...</span>
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Sí, Comenzar desde 0</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmación Estricta Eliminar Cuenta */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-rose-600 dark:text-rose-400">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  ¿Eliminar cuenta permanentemente?
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!isDeleting) setShowDeleteModal(false);
                }}
                disabled={isDeleting}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              <p>
                Esta acción es <strong className="text-rose-600 dark:text-rose-400">permanente e irreversible</strong>.
              </p>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-500 dark:text-slate-400 pl-1">
                <li>Se borrarán tus cuentas, presupuestos y categorías.</li>
                <li>Se eliminarán tus suscripciones y gastos registrados.</li>
                <li>Se eliminarán los grupos donde seas el único miembro.</li>
                <li>Si compartes grupos con otras personas, se removerá tu acceso sin borrar el grupo de los demás.</li>
              </ul>
            </div>

            <div className="space-y-1.5 pt-1">
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                Para confirmar, escribe <strong className="text-rose-600 dark:text-rose-400 tracking-wider">ELIMINAR</strong> a continuación:
              </label>
              <input
                id="delete-confirm-input"
                type="text"
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                placeholder="ELIMINAR"
                disabled={isDeleting}
                className="w-full px-3 py-2 text-xs font-mono font-bold bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-rose-500 focus:outline-none"
              />
            </div>

            {groupsWithBalance.length > 0 && (
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-2xl space-y-2">
                <div className="flex items-center space-x-1.5 text-amber-800 dark:text-amber-300 font-semibold text-[11px]">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
                  <span>Saldos pendientes detectados:</span>
                </div>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {groupsWithBalance.map((grp) => (
                    <div
                      key={grp.id}
                      className="flex items-center justify-between text-xs py-1.5 px-2.5 rounded-xl bg-white dark:bg-slate-900/80 border border-amber-100 dark:border-amber-900/40 shadow-2xs"
                    >
                      <span className="font-medium text-slate-800 dark:text-slate-200 truncate pr-2">
                        {grp.name}
                      </span>
                      <span
                        className={`font-mono font-bold text-[11px] shrink-0 ${
                          grp.balance > 0
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {grp.balance > 0 ? `+S/ ${grp.balance.toFixed(2)}` : `-S/ ${Math.abs(grp.balance).toFixed(2)}`}
                      </span>
                    </div>
                  ))}
                </div>
                <p className="text-[10px] text-amber-700 dark:text-amber-400 leading-tight">
                  Debes liquidar y saldar tus deudas en estos grupos antes de poder dar de baja tu cuenta.
                </p>
              </div>
            )}

            {deleteError && (
              <p className="text-[11px] text-rose-600 dark:text-rose-400 font-medium leading-relaxed">
                {deleteError}
              </p>
            )}

            <div className="flex items-center space-x-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowDeleteModal(false);
                  setGroupsWithBalance([]);
                }}
                disabled={isDeleting}
                className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors"
              >
                Cancelar
              </button>
              <button
                id="confirm-delete-account-btn"
                type="button"
                disabled={deleteConfirmText.trim() !== 'ELIMINAR' || isDeleting}
                onClick={async () => {
                  if (deleteConfirmText.trim() !== 'ELIMINAR') return;
                  setIsDeleting(true);
                  setDeleteError(null);
                  setGroupsWithBalance([]);
                  try {
                    const res = await deleteMyAccount();
                    if (!res.success) {
                      setDeleteError(res.message || 'No fue posible eliminar la cuenta.');
                      if (res.groupsWithBalance && res.groupsWithBalance.length > 0) {
                        setGroupsWithBalance(res.groupsWithBalance);
                      }
                      setIsDeleting(false);
                    }
                  } catch (err: any) {
                    setDeleteError(err.message || 'Error al eliminar');
                    setIsDeleting(false);
                  }
                }}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 ${
                  deleteConfirmText.trim() === 'ELIMINAR' && !isDeleting
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-xs cursor-pointer active:scale-[0.98]'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                }`}
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Eliminando...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirmar Borrado</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Modal para Administrar y Personalizar Categorías */}
      <ManageCategoriesModal
        isOpen={showManageCatModal}
        onClose={() => setShowManageCatModal(false)}
      />
    </div>
  );
};
