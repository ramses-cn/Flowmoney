import React, { useState, useEffect, useCallback } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { DEFAULT_CURRENCY } from '../../constants/currencies.ts';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Wallet, Edit3, Check, X, AlertTriangle, TrendingUp, RefreshCw, Loader2, SlidersHorizontal, Plus } from 'lucide-react';
import { ManageCategoriesModal } from './ManageCategoriesModal.tsx';

interface SpendingCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
  monthly_budget: number;
  spent: number;
  percentage_of_total: number;
  budget_usage_percentage: number;
  is_over: boolean;
}

export const BudgetsSection: React.FC = () => {
  const { token, updateCategoryBudget, profile } = useAuthStore();
  const [categories, setCategories] = useState<SpendingCategory[]>([]);
  const [totalSpent, setTotalSpent] = useState<number>(0);
  const [totalBudget, setTotalBudget] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [isSavingBudget, setIsSavingBudget] = useState<boolean>(false);
  const [isManageModalOpen, setIsManageModalOpen] = useState<boolean>(false);
  const currency = profile?.default_currency || DEFAULT_CURRENCY;

  const fetchSpendingData = useCallback(async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/categories/spending', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setCategories(data.categories || []);
        setTotalSpent(data.total_spent || 0);
        setTotalBudget(data.total_budget || 0);
      }
    } catch (err) {
      console.error('Error fetching spending distribution:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchSpendingData();
  }, [fetchSpendingData]);

  const handleStartEdit = (cat: SpendingCategory) => {
    setEditingId(cat.id);
    setEditAmount(String(cat.monthly_budget));
  };

  const handleSaveEdit = async (catId: string) => {
    const num = parseFloat(editAmount);
    if (isNaN(num) || num < 0) return;

    setIsSavingBudget(true);
    try {
      const success = await updateCategoryBudget(catId, num);
      if (success) {
        setCategories((prev) =>
          prev.map((c) =>
            c.id === catId
              ? {
                  ...c,
                  monthly_budget: num,
                  budget_usage_percentage: num > 0 ? Math.round((c.spent / num) * 100) : 0,
                  is_over: c.spent > num && num > 0,
                }
              : c
          )
        );
        // Recalcular total presupuestado
        setTotalBudget((prev) => {
          const old = categories.find((c) => c.id === catId)?.monthly_budget || 0;
          return prev - old + num;
        });
        setEditingId(null);
      }
    } finally {
      setIsSavingBudget(false);
    }
  };

  // Filtrar para el gráfico de dona solo las categorías con gasto real > 0
  const chartData = categories.filter((c) => c.spent > 0);

  // Colores por defecto si faltan
  const defaultColors = ['#4F46E5', '#10B981', '#F59E0B', '#EC4899', '#8B5CF6', '#06B6D4', '#E11D48', '#64748B'];

  return (
    <div id="budgets-section" className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/90 rounded-2xl p-5 shadow-xs space-y-5 transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Presupuestos y Distribución de Gasto
          </h3>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
            Límite mensual por categoría y consumo real del mes
          </p>
        </div>

        <div className="flex items-center space-x-1.5">
          <button
            type="button"
            onClick={() => setIsManageModalOpen(true)}
            className="flex items-center space-x-1 px-2.5 py-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 rounded-xl transition-colors border border-indigo-200 dark:border-indigo-800/60"
            title="Personalizar qué categorías deseas usar o crear nuevas"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Gestionar Categorías</span>
          </button>

          <button
            type="button"
            onClick={fetchSpendingData}
            disabled={isLoading}
            className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Actualizar datos"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Gráfico de Dona con Recharts */}
      <div className="p-4 bg-slate-50/80 dark:bg-slate-950/60 rounded-xl border border-slate-200/70 dark:border-slate-800/70">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="w-full sm:w-1/2 h-48 relative flex items-center justify-center">
            {isLoading ? (
              <div className="flex flex-col items-center space-y-2 text-slate-400 text-xs">
                <Loader2 className="w-6 h-6 animate-spin text-indigo-500" />
                <span>Calculando gastos...</span>
              </div>
            ) : chartData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      dataKey="spent"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={52}
                      outerRadius={75}
                      paddingAngle={3}
                      stroke="none"
                    >
                      {chartData.map((entry, index) => (
                        <Cell
                          key={`cell-${entry.id}`}
                          fill={entry.color || defaultColors[index % defaultColors.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val: any) => [`${currency} ${Number(val).toFixed(2)}`, 'Gastado']}
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderRadius: '0.75rem',
                        border: '1px solid #334155',
                        color: '#F8FAFC',
                        fontSize: '11px',
                        padding: '6px 10px',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>

                {/* Texto al centro de la dona */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                  <span className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">
                    Total Mes
                  </span>
                  <span className="text-sm font-black text-slate-900 dark:text-white leading-tight">
                    {currency} {totalSpent.toFixed(0)}
                  </span>
                </div>
              </>
            ) : (
              <div className="text-center p-4 text-slate-400 text-xs space-y-1">
                <Wallet className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700" />
                <p className="font-medium text-slate-500 dark:text-slate-400">Sin gastos registrados este mes</p>
                <p className="text-[10px]">Los consumos se graficarán automáticamente aquí</p>
              </div>
            )}
          </div>

          {/* Resumen numérico */}
          <div className="w-full sm:w-1/2 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                <span className="text-[10px] text-slate-500 font-medium block">Gastado Real</span>
                <span className="text-sm font-bold text-slate-900 dark:text-white">
                  {currency} {totalSpent.toFixed(2)}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                <span className="text-[10px] text-slate-500 font-medium block">Presupuesto</span>
                <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                  {currency} {totalBudget.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Barra global de consumo */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-500 dark:text-slate-400 font-medium">Ejecución presupuestaria</span>
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  {totalBudget > 0 ? Math.round((totalSpent / totalBudget) * 100) : 0}%
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    totalSpent > totalBudget && totalBudget > 0
                      ? 'bg-rose-500'
                      : totalSpent > totalBudget * 0.8
                      ? 'bg-amber-500'
                      : 'bg-indigo-600'
                  }`}
                  style={{
                    width: `${totalBudget > 0 ? Math.min((totalSpent / totalBudget) * 100, 100) : 0}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lista editable de categorías */}
      <div className="space-y-2.5">
        <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
          <span>Categorías y Presupuesto Asignado</span>
          <span className="text-[10px] text-slate-400 font-normal">Haz clic en el lápiz para editar</span>
        </h4>

        <div className="space-y-2">
          {categories.map((cat) => {
            const isEditing = editingId === cat.id;
            const progress = cat.monthly_budget > 0 ? Math.min((cat.spent / cat.monthly_budget) * 100, 100) : 0;

            return (
              <div
                key={cat.id}
                className="p-3 bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200/70 dark:border-slate-800/70 hover:border-indigo-300 dark:hover:border-indigo-800/80 transition-all space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5 min-w-0">
                    <span
                      className="w-3.5 h-3.5 rounded-full shrink-0 shadow-xs"
                      style={{ backgroundColor: cat.color || '#6366F1' }}
                    />
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {cat.name}
                    </span>
                    {cat.is_over && (
                      <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded-md bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 text-[9px] font-bold">
                        <AlertTriangle className="w-2.5 h-2.5" />
                        <span>Excedido</span>
                      </span>
                    )}
                  </div>

                  {/* Presupuesto y edición */}
                  <div className="flex items-center space-x-2">
                    {isEditing ? (
                      <div className="flex items-center space-x-1">
                        <span className="text-xs text-slate-400">{currency}</span>
                        <input
                          type="number"
                          value={editAmount}
                          onChange={(e) => setEditAmount(e.target.value)}
                          className="w-20 px-2 py-0.5 text-xs font-bold bg-white dark:bg-slate-900 border border-indigo-500 rounded text-slate-900 dark:text-white focus:outline-none"
                          min="0"
                          step="10"
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(cat.id)}
                          disabled={isSavingBudget}
                          className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700"
                          title="Guardar"
                        >
                          <Check className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="p-1 bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded hover:bg-slate-400"
                          title="Cancelar"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-1.5">
                        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                          {currency} {cat.monthly_budget.toFixed(0)}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleStartEdit(cat)}
                          className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                          title="Editar presupuesto"
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Barra de progreso de categoría */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>
                      Gastado: <strong className="text-slate-700 dark:text-slate-300">{currency} {cat.spent.toFixed(2)}</strong>
                    </span>
                    <span>
                      {cat.budget_usage_percentage}% de {currency} {cat.monthly_budget}
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        cat.is_over ? 'bg-rose-500' : 'bg-indigo-600'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal para Administrar Categorías Personalizadas y Activas */}
      <ManageCategoriesModal
        isOpen={isManageModalOpen}
        onClose={() => setIsManageModalOpen(false)}
        onCategoriesChanged={() => {
          fetchSpendingData();
        }}
      />
    </div>
  );
};
