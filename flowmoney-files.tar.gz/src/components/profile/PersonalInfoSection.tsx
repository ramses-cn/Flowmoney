import React, { useState, useRef } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { uploadAvatarImage } from '../../lib/firebase.ts';
import { SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from '../../constants/currencies.ts';
import { Camera, Mail, Check, Loader2, DollarSign, User } from 'lucide-react';

export const PersonalInfoSection: React.FC = () => {
  const { profile, firebaseUser, updateProfileData } = useAuthStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [currency, setCurrency] = useState(profile?.default_currency || DEFAULT_CURRENCY);
  const [isEditingName, setIsEditingName] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 2500);
  };

  const handleAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const uid = profile?.id || firebaseUser?.uid;
    if (!uid) return;

    setIsUploadingAvatar(true);
    try {
      const downloadUrl = await uploadAvatarImage(file, uid);
      await updateProfileData({ avatar_url: downloadUrl });
      showNotification('Avatar actualizado con éxito');
    } catch (err: any) {
      console.error('Error subiendo avatar:', err);
    } finally {
      setIsUploadingAvatar(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSaveName = async () => {
    if (!fullName.trim() || fullName.trim() === profile?.full_name) {
      setIsEditingName(false);
      return;
    }
    setIsSaving(true);
    try {
      await updateProfileData({ full_name: fullName.trim() });
      setIsEditingName(false);
      showNotification('Nombre actualizado');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCurrencyChange = async (newCurr: string) => {
    setCurrency(newCurr);
    setIsSaving(true);
    try {
      await updateProfileData({ default_currency: newCurr });
      showNotification(`Moneda predeterminada: ${newCurr}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div id="personal-info-section" className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/90 rounded-2xl p-5 shadow-xs space-y-5 transition-colors">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Datos Personales
        </h3>
        {successMessage && (
          <span className="flex items-center space-x-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold animate-fade-in">
            <Check className="w-3.5 h-3.5" />
            <span>{successMessage}</span>
          </span>
        )}
      </div>

      {/* Avatar + Nombre */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        {/* Avatar con botón de subida a Firebase Storage */}
        <div className="relative group self-center sm:self-auto">
          <div className="w-20 h-20 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-2xl shadow-md shadow-indigo-600/20 overflow-hidden ring-4 ring-slate-100 dark:ring-slate-800">
            {profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt={profile.full_name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              (profile?.full_name || 'U').slice(0, 2).toUpperCase()
            )}
          </div>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploadingAvatar}
            className="absolute -bottom-1 -right-1 p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md border-2 border-white dark:border-slate-900 transition-transform active:scale-95 disabled:opacity-75"
            title="Cambiar foto de perfil"
            aria-label="Cambiar foto de perfil"
          >
            {isUploadingAvatar ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Camera className="w-3.5 h-3.5" />
            )}
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleAvatarFileChange}
          />
        </div>

        {/* Nombre y correo */}
        <div className="flex-1 min-w-0 space-y-1.5 text-center sm:text-left">
          {isEditingName ? (
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Tu nombre completo"
                autoFocus
                className="w-full px-3 py-1.5 text-sm font-semibold bg-slate-50 dark:bg-slate-950 border border-indigo-400 dark:border-indigo-600 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
              <button
                type="button"
                onClick={handleSaveName}
                disabled={isSaving}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold"
              >
                Guardar
              </button>
              <button
                type="button"
                onClick={() => {
                  setFullName(profile?.full_name || '');
                  setIsEditingName(false);
                }}
                className="px-2.5 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs"
              >
                Cancelar
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center sm:justify-start space-x-2">
              <h2 className="text-base font-bold text-slate-900 dark:text-white truncate">
                {profile?.full_name || 'Usuario FlowMoney'}
              </h2>
              <button
                type="button"
                onClick={() => setIsEditingName(true)}
                className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
              >
                Editar
              </button>
            </div>
          )}

          <div className="flex items-center justify-center sm:justify-start space-x-1.5 text-xs text-slate-500 dark:text-slate-400">
            <Mail className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{profile?.email || firebaseUser?.email || 'Sin correo registrado'}</span>
          </div>
        </div>
      </div>

      {/* Moneda Predeterminada */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <DollarSign className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-900 dark:text-white">
              Moneda Predeterminada
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              Utilizada en presupuestos y reportes
            </div>
          </div>
        </div>

        <select
          id="default-currency-select"
          value={currency}
          onChange={(e) => handleCurrencyChange(e.target.value)}
          disabled={isSaving}
          className="px-3 py-1.5 text-xs font-bold bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white cursor-pointer hover:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-colors"
        >
          {SUPPORTED_CURRENCIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
