import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { Account, AccountType } from '../../types/flowmoney.ts';
import { SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from '../../constants/currencies.ts';
import {
  CreditCard,
  Plus,
  Trash2,
  Check,
  X,
  Building,
  PiggyBank,
  Banknote,
  Smartphone,
  HelpCircle,
  Loader2,
} from 'lucide-react';

export const AccountsSection: React.FC = () => {
  const { accounts, addAccount, deleteAccount, fetchAccounts, profile } = useAuthStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [type, setType] = useState<AccountType>('checking');
  const [currency, setCurrency] = useState(profile?.default_currency || DEFAULT_CURRENCY);
  const [currentBalance, setCurrentBalance] = useState('');
  const [color, setColor] = useState('#4F46E5');

  useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  const colorPresets = [
    '#4F46E5', // Indigo
    '#10B981', // Emerald
    '#0EA5E9', // Sky
    '#F59E0B', // Amber
    '#EC4899', // Pink
    '#8B5CF6', // Purple
    '#64748B', // Slate
  ];

  const getAccountIcon = (accType: AccountType) => {
    switch (accType) {
      case 'checking':
        return <Building className="w-4 h-4" />;
      case 'savings':
        return <PiggyBank className="w-4 h-4" />;
      case 'credit_card':
        return <CreditCard className="w-4 h-4" />;
      case 'cash':
        return <Banknote className="w-4 h-4" />;
      case 'wallet':
        return <Smartphone className="w-4 h-4" />;
      default:
        return <HelpCircle className="w-4 h-4" />;
    }
  };

  const getTypeName = (accType: AccountType) => {
    switch (accType) {
      case 'checking':
        return 'Cuenta Corriente';
      case 'savings':
        return 'Ahorros';
      case 'credit_card':
        return 'Tarjeta de Crédito';
      case 'cash':
        return 'Efectivo';
      case 'wallet':
        return 'Billetera Digital';
      default:
        return 'Otra';
    }
  };

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);
    try {
      const balanceNum = parseFloat(currentBalance) || 0;
      await addAccount({
        name: name.trim(),
        type,
        currency,
        current_balance: balanceNum,
        color,
      });

      // Reset
      setName('');
      setCurrentBalance('');
      setIsModalOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('¿Seguro que deseas eliminar esta cuenta?')) return;
    setDeletingId(id);
    try {
      await deleteAccount(id);
    } finally {
      setDeletingId(null);
    }
  };

  const totalBalance = accounts.reduce((sum, a) => sum + Number(a.current_balance || 0), 0);

  return (
    <div id="accounts-section" className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/90 rounded-2xl p-5 shadow-xs space-y-4 transition-colors">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Cuentas y Métodos de Pago
          </h3>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
            Saldo acumulado: <strong className="text-slate-700 dark:text-slate-300 font-bold">{profile?.default_currency || DEFAULT_CURRENCY} {totalBalance.toFixed(2)}</strong>
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center space-x-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Añadir Cuenta</span>
        </button>
      </div>

      {/* Lista de cuentas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {accounts.length === 0 ? (
          <div className="col-span-full p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-400">
            No tienes cuentas registradas. Pulsa "Añadir Cuenta" para empezar a registrar balances.
          </div>
        ) : (
          accounts.map((acc) => {
            const isDeleting = deletingId === acc.id;
            const balance = Number(acc.current_balance || 0);

            return (
              <div
                key={acc.id}
                className="p-3.5 bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200/70 dark:border-slate-800/70 flex items-center justify-between hover:border-indigo-300 dark:hover:border-indigo-800/80 transition-all"
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div
                    className="w-9 h-9 rounded-xl text-white flex items-center justify-center shrink-0 shadow-xs"
                    style={{ backgroundColor: acc.color || '#4F46E5' }}
                  >
                    {getAccountIcon(acc.type)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {acc.name}
                    </h4>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">
                      {getTypeName(acc.type)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0 ml-2">
                  <div className="text-right">
                    <span
                      className={`text-xs font-black block ${
                        balance >= 0
                          ? 'text-slate-900 dark:text-white'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {acc.currency || profile?.default_currency || DEFAULT_CURRENCY} {balance.toFixed(2)}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDelete(acc.id)}
                    disabled={isDeleting}
                    className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Eliminar cuenta"
                  >
                    {isDeleting ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Trash2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Añadir Cuenta */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Nueva Cuenta o Fondo
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAccount} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nombre de la Cuenta *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ej: BBVA Nómina, Efectivo, Tarjeta Visa"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tipo de Cuenta
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as AccountType)}
                    className="w-full px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="checking">Cuenta Corriente</option>
                    <option value="savings">Ahorros</option>
                    <option value="credit_card">Tarjeta Crédito</option>
                    <option value="cash">Efectivo</option>
                    <option value="wallet">Billetera Digital</option>
                    <option value="other">Otro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Moneda
                  </label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white"
                  >
                    {SUPPORTED_CURRENCIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Saldo Inicial
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={currentBalance}
                  onChange={(e) => setCurrentBalance(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Color Identificador
                </label>
                <div className="flex items-center space-x-2">
                  {colorPresets.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-6 h-6 rounded-full transition-transform ${
                        color === c ? 'ring-2 ring-indigo-500 ring-offset-2 scale-110' : ''
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !name.trim()}
                  className="flex-1 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl disabled:opacity-50"
                >
                  {isSubmitting ? 'Creando...' : 'Crear Cuenta'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
