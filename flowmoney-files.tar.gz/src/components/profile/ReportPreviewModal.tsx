import React, { useRef } from 'react';
import {
  X,
  Printer,
  Download,
  FileSpreadsheet,
  FileText,
  FileCode,
  Calendar,
  Layers,
  CreditCard,
  PieChart,
  ShieldCheck,
  TrendingDown,
  Sparkles,
} from 'lucide-react';

export interface ReportSummaryData {
  user: {
    full_name: string;
    email: string;
    currency: string;
  };
  summary: {
    total_spent: number;
    transaction_count: number;
    days_in_period: number;
    daily_average: number;
    average_ticket: number;
    highest_expense: {
      description: string;
      amount: number;
      date: string;
      category_name: string;
    } | null;
    start_date: string;
    end_date: string;
    lens: string;
  };
  categories_breakdown: Array<{
    name: string;
    color: string;
    total: number;
    count: number;
    percentage: number;
  }>;
  lens_breakdown: {
    personal: { total: number; count: number; percentage: number };
    couple: { total: number; count: number; percentage: number };
    group: { total: number; count: number; percentage: number };
  };
  accounts_breakdown: Array<{
    name: string;
    total: number;
    count: number;
    percentage: number;
  }>;
  expenses_sample: Array<any>;
  total_records: number;
}

interface ReportPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: ReportSummaryData | null;
  onDownloadPdf: () => void;
  onDownloadCsv: () => void;
  onDownloadJson: () => void;
  isDownloadingPdf?: boolean;
  isDownloadingCsv?: boolean;
  isDownloadingJson?: boolean;
}

export const ReportPreviewModal: React.FC<ReportPreviewModalProps> = ({
  isOpen,
  onClose,
  data,
  onDownloadPdf,
  onDownloadCsv,
  onDownloadJson,
  isDownloadingPdf = false,
  isDownloadingCsv = false,
  isDownloadingJson = false,
}) => {
  const printableRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !data) return null;

  const currency = data.user.currency || 'PEN';
  const reportCode = `FM-${data.summary.start_date.replace(/-/g, '').slice(2)}-${data.summary.end_date.replace(/-/g, '').slice(2)}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/90 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col transition-colors">
        {/* Cabecera del Modal */}
        <div className="p-4 sm:px-6 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-xs shadow-xs">
              <PieChart className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center space-x-2">
                <span>Vista Previa del Reporte Ejecutivo</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300">
                  {reportCode}
                </span>
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Auditoría detallada del {data.summary.start_date} al {data.summary.end_date}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={handlePrint}
              type="button"
              className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded-xl transition-colors"
              title="Imprimir reporte"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              type="button"
              className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Contenido Desplazable del Reporte (Hoja Membretada) */}
        <div ref={printableRef} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6 text-slate-800 dark:text-slate-100">
          {/* Membrete Documental */}
          <div className="border-b-2 border-indigo-600 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-lg font-black tracking-tight text-indigo-600 dark:text-indigo-400">
                FLOWMONEY
              </span>
              <p className="text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500">
                Executive Financial Intelligence Report
              </p>
            </div>
            <div className="text-left sm:text-right text-[11px] text-slate-500 dark:text-slate-400 space-y-0.5">
              <div>
                <span className="font-semibold text-slate-700 dark:text-slate-300">Titular:</span>{' '}
                {data.user.full_name}
              </div>
              <div>
                <span className="font-semibold text-slate-700 dark:text-slate-300">Correo:</span>{' '}
                {data.user.email}
              </div>
              <div>
                <span className="font-semibold text-slate-700 dark:text-slate-300">Moneda Base:</span>{' '}
                {currency}
              </div>
            </div>
          </div>

          {/* Tarjetas de Métricas Clave (KPIs) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/60 rounded-2xl">
              <div className="flex items-center justify-between text-indigo-600 dark:text-indigo-400 mb-1">
                <span className="text-[10px] uppercase font-bold tracking-wider">Total Egresos</span>
                <TrendingDown className="w-3.5 h-3.5" />
              </div>
              <div className="text-xl font-black text-slate-900 dark:text-white">
                {currency} {data.summary.total_spent.toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                {data.summary.transaction_count} movimientos registrados
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 rounded-2xl">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
                <span className="text-[10px] uppercase font-bold tracking-wider">Promedio Diario</span>
                <Calendar className="w-3.5 h-3.5" />
              </div>
              <div className="text-xl font-black text-slate-900 dark:text-white">
                {currency} {data.summary.daily_average.toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                En {data.summary.days_in_period} días &bull; Ticket: {currency}{' '}
                {data.summary.average_ticket.toFixed(2)}
              </div>
            </div>

            <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/60 rounded-2xl">
              <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400 mb-1">
                <span className="text-[10px] uppercase font-bold tracking-wider">Categoría Top</span>
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div className="text-lg font-black text-slate-900 dark:text-white truncate">
                {data.categories_breakdown[0]?.name || 'Sin registros'}
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                {data.categories_breakdown[0]
                  ? `${currency} ${data.categories_breakdown[0].total.toFixed(2)} (${data.categories_breakdown[0].percentage}%)`
                  : 'N/A'}
              </div>
            </div>
          </div>

          {/* Desglose Gráfico: Categorías y Lentes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Categorías Principales */}
            <div className="p-4 bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center space-x-1.5">
                  <PieChart className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Distribución por Categorías</span>
                </h4>
                <span className="text-[10px] text-slate-400">Top 5</span>
              </div>

              {data.categories_breakdown.length === 0 ? (
                <p className="text-xs text-slate-400 py-4 text-center">Sin datos en este período</p>
              ) : (
                <div className="space-y-2.5">
                  {data.categories_breakdown.slice(0, 5).map((cat) => (
                    <div key={cat.name} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center space-x-1.5">
                          <span
                            className="w-2.5 h-2.5 rounded-full inline-block"
                            style={{ backgroundColor: cat.color || '#6366F1' }}
                          />
                          <span className="truncate max-w-[150px]">{cat.name}</span>
                        </span>
                        <span className="text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                          {currency} {cat.total.toFixed(2)} ({cat.percentage}%)
                        </span>
                      </div>
                      <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${Math.min(100, Math.max(3, cat.percentage))}%`,
                            backgroundColor: cat.color || '#6366F1',
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Ámbitos y Cuentas de Pago */}
            <div className="p-4 bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-2xl space-y-4">
              {/* Lentes */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center space-x-1.5">
                  <Layers className="w-3.5 h-3.5 text-pink-500" />
                  <span>Distribución por Ámbito (Lente)</span>
                </h4>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <div className="text-[10px] text-slate-400 font-bold">Personal</div>
                    <div className="text-xs font-black text-slate-900 dark:text-white mt-0.5">
                      {currency} {data.lens_breakdown.personal.total.toFixed(0)}
                    </div>
                    <div className="text-[9px] text-indigo-500 font-semibold">
                      {data.lens_breakdown.personal.percentage}%
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <div className="text-[10px] text-slate-400 font-bold">Pareja</div>
                    <div className="text-xs font-black text-slate-900 dark:text-white mt-0.5">
                      {currency} {data.lens_breakdown.couple.total.toFixed(0)}
                    </div>
                    <div className="text-[9px] text-pink-500 font-semibold">
                      {data.lens_breakdown.couple.percentage}%
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <div className="text-[10px] text-slate-400 font-bold">Grupos</div>
                    <div className="text-xs font-black text-slate-900 dark:text-white mt-0.5">
                      {currency} {data.lens_breakdown.group.total.toFixed(0)}
                    </div>
                    <div className="text-[9px] text-cyan-500 font-semibold">
                      {data.lens_breakdown.group.percentage}%
                    </div>
                  </div>
                </div>
              </div>

              {/* Cuentas */}
              <div className="space-y-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center space-x-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Cuentas Utilizadas</span>
                </h4>
                <div className="space-y-1.5">
                  {data.accounts_breakdown.slice(0, 3).map((acc) => (
                    <div key={acc.name} className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-600 dark:text-slate-300 font-medium truncate max-w-[170px]">
                        {acc.name}
                      </span>
                      <span className="font-mono text-slate-700 dark:text-slate-200 font-bold">
                        {currency} {acc.total.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Muestra de Transacciones Auditadas */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200">
                Muestra de Transacciones Auditadas ({data.expenses_sample.length} de {data.total_records})
              </h4>
              <span className="text-[10px] text-slate-400">
                El PDF y CSV completos incluyen todos los registros
              </span>
            </div>

            <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 font-bold text-[10px] uppercase">
                    <th className="py-2 px-3">Fecha</th>
                    <th className="py-2 px-3">Concepto</th>
                    <th className="py-2 px-3">Categoría</th>
                    <th className="py-2 px-3">Cuenta</th>
                    <th className="py-2 px-3">Ámbito</th>
                    <th className="py-2 px-3 text-right">Importe</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-[11px]">
                  {data.expenses_sample.slice(0, 8).map((e) => (
                    <tr key={e.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-2 px-3 text-slate-500 font-mono text-[10px]">
                        {String(e.expense_date || '').slice(0, 10)}
                      </td>
                      <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-100 max-w-[140px] truncate">
                        {e.description}
                      </td>
                      <td className="py-2 px-3 text-slate-500">
                        {e.category_name || 'General'}
                      </td>
                      <td className="py-2 px-3 text-slate-400 truncate max-w-[100px]">
                        {e.account_name || 'Sin cuenta'}
                      </td>
                      <td className="py-2 px-3">
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                          e.lens === 'couple'
                            ? 'bg-pink-100 text-pink-700 dark:bg-pink-950/60 dark:text-pink-300'
                            : e.lens === 'group'
                            ? 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/60 dark:text-cyan-300'
                            : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                        }`}>
                          {e.lens === 'couple' ? 'Pareja' : e.lens === 'group' ? 'Grupo' : 'Personal'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-bold text-slate-900 dark:text-white font-mono">
                        {currency} {Number(e.amount).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sello de Auditoría */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-slate-200/60 dark:border-slate-800 flex items-center space-x-2 text-[10px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>
              Certificado de integridad financiera FlowMoney. Registro respaldado en Google Cloud SQL y Firebase Firestore.
            </span>
          </div>
        </div>

        {/* Barra Inferior con Acciones de Descarga */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/70 border-t border-slate-200/80 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Cerrar Vista Previa
          </button>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={onDownloadJson}
              disabled={isDownloadingJson}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl flex items-center space-x-1.5 transition-colors disabled:opacity-50"
              title="Descargar copia de seguridad en JSON"
            >
              <FileCode className="w-3.5 h-3.5 text-amber-500" />
              <span>JSON</span>
            </button>

            <button
              type="button"
              onClick={onDownloadCsv}
              disabled={isDownloadingCsv}
              className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-xl flex items-center space-x-1.5 transition-colors disabled:opacity-50 border border-emerald-200 dark:border-emerald-800/80"
              title="Descargar formato Excel compatible"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Excel / CSV</span>
            </button>

            <button
              type="button"
              onClick={onDownloadPdf}
              disabled={isDownloadingPdf}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center space-x-1.5 shadow-sm transition-colors disabled:opacity-50"
              title="Descargar reporte oficial en PDF"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Descargar PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
