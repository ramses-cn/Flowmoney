import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { Category } from '../../types/flowmoney.ts';
import {
  X,
  Plus,
  Pencil,
  Trash2,
  Check,
  Power,
  PowerOff,
  ArrowUp,
  ArrowDown,
  Sparkles,
  Tag,
  AlertTriangle,
  Loader2,
  Search,
} from 'lucide-react';

interface ManageCategoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCategoriesChanged?: () => void;
}

const COLOR_PALETTE = [
  '#4F46E5', // Indigo
  '#3B82F6', // Blue
  '#06B6D4', // Cyan
  '#10B981', // Emerald
  '#84CC16', // Lime
  '#F59E0B', // Amber
  '#F97316', // Orange
  '#EF4444', // Red
  '#EC4899', // Pink
  '#8B5CF6', // Purple
  '#6366F1', // Violet
  '#64748B', // Slate
];

const AVAILABLE_ICONS = [
  { key: 'tag', label: 'Etiqueta' },
  { key: 'utensils', label: 'Comida' },
  { key: 'car', label: 'Transporte' },
  { key: 'home', label: 'Hogar' },
  { key: 'film', label: 'Ocio' },
  { key: 'heart-pulse', label: 'Salud' },
  { key: 'shopping-bag', label: 'Compras' },
  { key: 'repeat', label: 'Suscripciones' },
  { key: 'coffee', label: 'Café' },
  { key: 'gift', label: 'Regalo' },
  { key: 'plane', label: 'Viaje' },
  { key: 'book', label: 'Educación' },
  { key: 'dumbbell', label: 'Deporte' },
  { key: 'paw', label: 'Mascotas' },
  { key: 'wrench', label: 'Servicios' },
  { key: 'smartphone', label: 'Tecnología' },
];

export const ManageCategoriesModal: React.FC<ManageCategoriesModalProps> = ({
  isOpen,
  onClose,
  onCategoriesChanged,
}) => {
  const {
    fetchAllCategories,
    toggleCategoryActive,
    addCustomCategory,
    updateCategory,
    deleteCustomCategory,
    reorderCategories,
    fetchCategories,
  } = useAuthStore();

  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'active' | 'inactive'>('all');

  // Modo Crear / Editar
  const [isEditing, setIsEditing] = useState(false);
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formColor, setFormColor] = useState('#4F46E5');
  const [formIcon, setFormIcon] = useState('tag');
  const [formBudget, setFormBudget] = useState('0');
  const [formError, setFormError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Modal confirmación eliminar
  const [catToDelete, setCatToDelete] = useState<Category | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Toast / Aviso
  const [feedback, setFeedback] = useState<string | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await fetchAllCategories();
      setCategories(data);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
      setIsEditing(false);
      setEditingCatId(null);
      setFormError(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const showNotification = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleToggle = async (cat: Category) => {
    const newStatus = !(cat.is_active !== false);
    const ok = await toggleCategoryActive(cat.id, newStatus);
    if (ok) {
      setCategories((prev) =>
        prev.map((c) => (c.id === cat.id ? { ...c, is_active: newStatus } : c))
      );
      showNotification(
        newStatus ? `"${cat.name}" ahora está activa` : `"${cat.name}" desactivada de las vistas`
      );
      onCategoriesChanged?.();
    }
  };

  const handleStartCreate = () => {
    setEditingCatId(null);
    setFormName('');
    setFormColor(COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)]);
    setFormIcon('tag');
    setFormBudget('0');
    setFormError(null);
    setIsEditing(true);
  };

  const handleStartEdit = (cat: Category) => {
    setEditingCatId(cat.id);
    setFormName(cat.name);
    setFormColor(cat.color || '#4F46E5');
    setFormIcon(cat.icon || 'tag');
    setFormBudget(String(cat.monthly_budget || 0));
    setFormError(null);
    setIsEditing(true);
  };

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setFormError('El nombre de la categoría es obligatorio');
      return;
    }

    setIsSaving(true);
    setFormError(null);

    try {
      if (editingCatId) {
        // Actualizar
        const updated = await updateCategory(editingCatId, {
          name: formName.trim(),
          color: formColor,
          icon: formIcon,
          monthly_budget: parseFloat(formBudget) || 0,
        });
        if (updated) {
          setCategories((prev) =>
            prev.map((c) => (c.id === editingCatId ? { ...c, ...updated } : c))
          );
          showNotification(`Categoría "${updated.name}" actualizada`);
          setIsEditing(false);
          await fetchCategories();
          onCategoriesChanged?.();
        } else {
          setFormError('No se pudo actualizar la categoría');
        }
      } else {
        // Crear nueva categoría personalizada
        const created = await addCustomCategory({
          name: formName.trim(),
          color: formColor,
          icon: formIcon,
          monthly_budget: parseFloat(formBudget) || 0,
          type: 'expense',
        });
        if (created) {
          setCategories((prev) => [...prev, created]);
          showNotification(`Categoría "${created.name}" creada exitosamente`);
          setIsEditing(false);
          await fetchCategories();
          onCategoriesChanged?.();
        } else {
          setFormError('Error al crear categoría personalizada');
        }
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!catToDelete) return;
    setIsDeleting(true);
    try {
      const res = await deleteCustomCategory(catToDelete.id);
      if (res.success) {
        if (res.wasDeactivated) {
          // Fue desactivada
          setCategories((prev) =>
            prev.map((c) => (c.id === catToDelete.id ? { ...c, is_active: false } : c))
          );
          showNotification(`Categoría de sistema "${catToDelete.name}" desactivada`);
        } else {
          // Fue eliminada
          setCategories((prev) => prev.filter((c) => c.id !== catToDelete.id));
          showNotification(`Categoría "${catToDelete.name}" eliminada`);
        }
        await fetchCategories();
        onCategoriesChanged?.();
        setCatToDelete(null);
      } else {
        alert(res.message || 'No se pudo eliminar la categoría');
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const handleMoveOrder = async (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= categories.length) return;

    const newCategories = [...categories];
    const temp = newCategories[index];
    newCategories[index] = newCategories[targetIndex];
    newCategories[targetIndex] = temp;

    setCategories(newCategories);

    // Persistir nuevo orden
    const orderedIds = newCategories.map((c) => c.id);
    await reorderCategories(orderedIds);
    await fetchCategories();
    onCategoriesChanged?.();
  };

  // Filtrado de categorías en la vista
  const filteredCategories = categories.filter((c) => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase().trim());
    if (!matchesSearch) return false;
    if (filterMode === 'active') return c.is_active !== false;
    if (filterMode === 'inactive') return c.is_active === false;
    return true;
  });

  const activeCount = categories.filter((c) => c.is_active !== false).length;

  return (
    <div
      id="manage-categories-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in"
    >
      <div
        id="manage-categories-modal"
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-lg rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden transition-all duration-200"
      >
        {/* Cabecera del modal */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/40">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border border-indigo-200 dark:border-indigo-800/80 shadow-xs">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Personalizar Categorías
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Selecciona solo las que necesitas ({activeCount} activas)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Feedback flotante si hay acción */}
        {feedback && (
          <div className="bg-indigo-500/10 border-b border-indigo-500/20 px-4 py-2 text-center text-xs font-medium text-indigo-700 dark:text-indigo-300 flex items-center justify-center space-x-1.5 animate-fade-in">
            <Check className="w-3.5 h-3.5 text-indigo-500" />
            <span>{feedback}</span>
          </div>
        )}

        {/* Contenido principal */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {isEditing ? (
            /* Formulario para Crear / Editar Categoría */
            <form onSubmit={handleSaveForm} className="space-y-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800/80 animate-fade-in">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/70 dark:border-slate-800/70">
                <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{editingCatId ? 'Editar Categoría' : 'Nueva Categoría Personalizada'}</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  Cancelar
                </button>
              </div>

              {formError && (
                <div className="p-2.5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 rounded-xl text-xs flex items-center space-x-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Nombre de la categoría */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nombre de la categoría
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="Ej. Mascotas, Cafetería, Cursos..."
                  required
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              {/* Selector de Color */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Color identificador
                </label>
                <div className="flex flex-wrap gap-2">
                  {COLOR_PALETTE.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormColor(c)}
                      className={`w-6 h-6 rounded-full border-2 transition-transform ${
                        formColor === c ? 'scale-115 border-slate-900 dark:border-white shadow-xs' : 'border-transparent hover:scale-105'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Selector de Ícono */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Ícono sugerido
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {AVAILABLE_ICONS.map((ic) => (
                    <button
                      key={ic.key}
                      type="button"
                      onClick={() => setFormIcon(ic.key)}
                      className={`p-2 rounded-xl border text-center text-[10px] font-medium transition-all ${
                        formIcon === ic.key
                          ? 'bg-indigo-50 dark:bg-indigo-950/80 border-indigo-600 text-indigo-600 dark:text-indigo-400 font-bold'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                      }`}
                    >
                      {ic.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Presupuesto mensual inicial */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Presupuesto mensual estimado (opcional)
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={formBudget}
                  onChange={(e) => setFormBudget(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              {/* Botones formulario */}
              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  disabled={isSaving}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex items-center space-x-1.5 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-sm transition-colors disabled:opacity-50"
                >
                  {isSaving ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Check className="w-3.5 h-3.5" />
                  )}
                  <span>{editingCatId ? 'Guardar Cambios' : 'Crear Categoría'}</span>
                </button>
              </div>
            </form>
          ) : (
            /* Barra de controles: Buscador + Filtros + Botón Agregar */
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filtrar categorías..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2 pointer-events-none" />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-2 text-[10px] text-slate-400 hover:text-slate-600"
                    >
                      ×
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleStartCreate}
                  className="flex items-center space-x-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nueva</span>
                </button>
              </div>

              {/* Filtro pestañas: Todas / Activas / Inactivas */}
              <div className="flex p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl text-xs">
                <button
                  type="button"
                  onClick={() => setFilterMode('all')}
                  className={`flex-1 py-1 text-center rounded-lg font-medium transition-all ${
                    filterMode === 'all'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs'
                      : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Todas ({categories.length})
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('active')}
                  className={`flex-1 py-1 text-center rounded-lg font-medium transition-all ${
                    filterMode === 'active'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs'
                      : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Activas ({activeCount})
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('inactive')}
                  className={`flex-1 py-1 text-center rounded-lg font-medium transition-all ${
                    filterMode === 'inactive'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs'
                      : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Inactivas ({categories.length - activeCount})
                </button>
              </div>

              <div className="p-2.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 text-[11px] text-slate-600 dark:text-slate-300">
                💡 <span className="font-semibold text-indigo-700 dark:text-indigo-300">Enfoque limpio:</span> Solo las categorías con el interruptor activo aparecerán en tus formularios de gastos, dashboard y reportes.
              </div>
            </div>
          )}

          {/* Listado interactivo de categorías */}
          {isLoading ? (
            <div className="py-10 text-center text-xs text-slate-400 flex flex-col items-center space-y-2">
              <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
              <span>Cargando categorías...</span>
            </div>
          ) : filteredCategories.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-950/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-6 space-y-2">
              <Tag className="w-6 h-6 text-slate-300 mx-auto" />
              <p>No se encontraron categorías coincidentes.</p>
              <button
                type="button"
                onClick={handleStartCreate}
                className="text-indigo-600 dark:text-indigo-400 font-semibold underline text-xs"
              >
                Crear tu primera categoría personalizada
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredCategories.map((cat, idx) => {
                const isActive = cat.is_active !== false;
                const isCustom = Boolean(cat.is_custom);

                return (
                  <div
                    key={cat.id}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                      isActive
                        ? 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800/90 shadow-xs'
                        : 'bg-slate-50/70 dark:bg-slate-950/40 border-slate-200/50 dark:border-slate-800/50 opacity-60'
                    }`}
                  >
                    {/* Badge de color y nombre */}
                    <div className="flex items-center space-x-2.5 min-w-0 flex-1">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 shadow-xs"
                        style={{
                          backgroundColor: `${cat.color || '#6366F1'}20`,
                          color: cat.color || '#6366F1',
                        }}
                      >
                        {cat.name.slice(0, 1).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {cat.name}
                          </span>
                          {isCustom && (
                            <span className="px-1.5 py-0.2 rounded-md bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 text-[9px] font-semibold border border-indigo-200 dark:border-indigo-800/50">
                              Personalizada
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center space-x-2 mt-0.5">
                          <span>Presupuesto: ${Number(cat.monthly_budget || 0).toFixed(0)}</span>
                          <span>•</span>
                          <span className={isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}>
                            {isActive ? 'Visible' : 'Oculta'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Acciones: Reordenar + Editar + Activar/Desactivar + Eliminar */}
                    <div className="flex items-center space-x-1 shrink-0">
                      {/* Reordenar arriba / abajo */}
                      <button
                        type="button"
                        onClick={() => handleMoveOrder(idx, 'up')}
                        disabled={idx === 0}
                        title="Subir posición"
                        className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveOrder(idx, 'down')}
                        disabled={idx === filteredCategories.length - 1}
                        title="Bajar posición"
                        className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      {/* Editar */}
                      <button
                        type="button"
                        onClick={() => handleStartEdit(cat)}
                        title="Editar nombre, ícono o presupuesto"
                        className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>

                      {/* Toggle Activar / Desactivar */}
                      <button
                        type="button"
                        onClick={() => handleToggle(cat)}
                        title={isActive ? 'Ocultar categoría' : 'Activar categoría'}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isActive
                            ? 'text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/50'
                            : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        {isActive ? <Power className="w-3.5 h-3.5" /> : <PowerOff className="w-3.5 h-3.5" />}
                      </button>

                      {/* Eliminar (personalizada) o Desactivar rápida */}
                      {isCustom && (
                        <button
                          type="button"
                          onClick={() => setCatToDelete(cat)}
                          title="Eliminar categoría personalizada"
                          className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal de confirmación para eliminar */}
        {catToDelete && (
          <div className="p-4 bg-red-50/90 dark:bg-red-950/90 border-t border-red-200 dark:border-red-900 animate-fade-in flex items-center justify-between gap-3">
            <div className="flex items-center space-x-2 text-xs text-red-800 dark:text-red-200">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
              <span>
                ¿Eliminar permanentemente la categoría <strong>"{catToDelete.name}"</strong>?
              </span>
            </div>
            <div className="flex items-center space-x-1.5 shrink-0">
              <button
                type="button"
                onClick={() => setCatToDelete(null)}
                disabled={isDeleting}
                className="px-2.5 py-1 text-xs text-slate-600 dark:text-slate-300 hover:underline"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold shadow-xs disabled:opacity-50"
              >
                {isDeleting ? 'Eliminando...' : 'Eliminar'}
              </button>
            </div>
          </div>
        )}

        {/* Pie del modal */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            {activeCount} de {categories.length} categorías en uso
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 dark:hover:bg-white transition-colors shadow-xs"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
