import React, { useState, useEffect, useCallback } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import {
  Download,
  FileSpreadsheet,
  FileText,
  Calendar,
  Filter,
  Check,
  AlertCircle,
  Loader2,
  Eye,
  FileCode,
  Printer,
  PieChart,
  Layers,
  Sparkles,
  TrendingDown,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { ReportPreviewModal, ReportSummaryData } from './ReportPreviewModal.tsx';

interface ExportDataSectionProps {
  hideHeader?: boolean;
}

export const ExportDataSection: React.FC<ExportDataSectionProps> = ({ hideHeader = false }) => {
  const { token, profile } = useAuthStore();

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();

  const [startDate, setStartDate] = useState(() =>
    new Date(year, month, 1).toISOString().slice(0, 10)
  );
  const [endDate, setEndDate] = useState(() => now.toISOString().slice(0, 10));
  const [lens, setLens] = useState<'all' | 'personal' | 'couple' | 'group'>('all');

  const [isExportingCsv, setIsExportingCsv] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingJson, setIsExportingJson] = useState(false);

  const [summaryData, setSummaryData] = useState<ReportSummaryData | null>(null);
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);

  const [exportMessage, setExportMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Cargar métricas en vivo del período para la vista previa
  const loadSummary = useCallback(async () => {
    if (!token) return;
    setIsLoadingSummary(true);
    try {
      const queryParams = new URLSearchParams({
        start_date: startDate,
        end_date: endDate,
      });
      if (lens !== 'all') {
        queryParams.append('lens', lens);
      }

      const res = await fetch(`/api/expenses/report-summary?${queryParams.toString()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        const data = await res.json();
        setSummaryData(data);
      }
    } catch (err) {
      console.error('Error cargando resumen de reporte:', err);
    } finally {
      setIsLoadingSummary(false);
    }
  }, [token, startDate, endDate, lens]);

  useEffect(() => {
    loadSummary();
  }, [loadSummary]);

  const applyPreset = (type: 'thisMonth' | 'lastMonth' | 'last30' | 'last90' | 'thisYear') => {
    const today = new Date();
    if (type === 'thisMonth') {
      setStartDate(new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    } else if (type === 'lastMonth') {
      const prevMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const prevMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
      setStartDate(prevMonthStart.toISOString().slice(0, 10));
      setEndDate(prevMonthEnd.toISOString().slice(0, 10));
    } else if (type === 'last30') {
      const past = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
      setStartDate(past.toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    } else if (type === 'last90') {
      const past = new Date(today.getTime() - 90 * 24 * 60 * 60 * 1000);
      setStartDate(past.toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    } else if (type === 'thisYear') {
      setStartDate(new Date(today.getFullYear(), 0, 1).toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    }
  };

  const handleExport = async (format: 'csv' | 'pdf' | 'json') => {
    if (!token) return;

    if (format === 'csv') setIsExportingCsv(true);
    else if (format === 'pdf') setIsExportingPdf(true);
    else setIsExportingJson(true);

    setExportMessage(null);
    setErrorMessage(null);

    try {
      const queryParams = new URLSearchParams({
        format,
        start_date: startDate,
        end_date: endDate,
      });

      if (lens !== 'all') {
        queryParams.append('lens', lens);
      }

      const res = await fetch(`/api/expenses/export?${queryParams.toString()}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        throw new Error('Error al generar el archivo en el servidor');
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const extension = format === 'csv' ? 'csv' : format === 'pdf' ? 'pdf' : 'json';
      a.download = `flowmoney_${format === 'pdf' ? 'reporte_ejecutivo' : format === 'csv' ? 'movimientos' : 'backup'}_${startDate}_${endDate}.${extension}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setExportMessage(
        format === 'csv'
          ? 'Planilla CSV/Excel generada y descargada con éxito'
          : format === 'pdf'
          ? 'Reporte PDF membretado generado y descargado'
          : 'Copia de respaldo JSON generada y descargada'
      );
      setTimeout(() => setExportMessage(null), 3500);
    } catch (err: any) {
      console.error('Error exportando datos:', err);
      setErrorMessage(err.message || 'Error descargando archivo');
    } finally {
      if (format === 'csv') setIsExportingCsv(false);
      else if (format === 'pdf') setIsExportingPdf(false);
      else setIsExportingJson(false);
    }
  };

  const currency = summaryData?.user.currency || profile?.default_currency || 'PEN';

  return (
    <div
      id="export-data-section"
      className={`${
        hideHeader
          ? 'space-y-4'
          : 'bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5 transition-colors'
      }`}
    >
      {/* Encabezado del Bloque */}
      {!hideHeader && (
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                Centro de Reportes y Exportación
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                En tiempo real
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Genera auditorías detalladas con membrete en PDF, planillas Excel compatibles y copias de seguridad de tus finanzas.
            </p>
          </div>

          <button
            type="button"
            onClick={() => loadSummary()}
            disabled={isLoadingSummary}
            className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            title="Actualizar métricas"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingSummary ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
        </div>
      )}

      {/* Alertas y Mensajes */}
      {exportMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 rounded-2xl flex items-center space-x-2.5 text-xs text-emerald-700 dark:text-emerald-300 animate-fade-in shadow-xs">
          <Check className="w-4 h-4 shrink-0 text-emerald-600" />
          <span className="font-semibold">{exportMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 rounded-2xl flex items-center space-x-2.5 text-xs text-rose-700 dark:text-rose-300">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* 1. Selector de Rango de Fechas con Presets */}
      <div className="space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-1 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <span className="flex items-center space-x-1.5">
            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
            <span>Período del Reporte</span>
          </span>

          {/* Presets rápidos */}
          <div className="flex items-center flex-wrap gap-1">
            <button
              type="button"
              onClick={() => applyPreset('thisMonth')}
              className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-600 dark:text-slate-300 rounded-lg transition-colors"
            >
              Este mes
            </button>
            <button
              type="button"
              onClick={() => applyPreset('lastMonth')}
              className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-600 dark:text-slate-300 rounded-lg transition-colors"
            >
              Mes ant.
            </button>
            <button
              type="button"
              onClick={() => applyPreset('last30')}
              className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-600 dark:text-slate-300 rounded-lg transition-colors"
            >
              30 días
            </button>
            <button
              type="button"
              onClick={() => applyPreset('last90')}
              className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-600 dark:text-slate-300 rounded-lg transition-colors"
            >
              90 días
            </button>
            <button
              type="button"
              onClick={() => applyPreset('thisYear')}
              className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-600 dark:text-slate-300 rounded-lg transition-colors"
            >
              Año actual
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1">
              Fecha Inicial
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1">
              Fecha Final
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>
      </div>

      {/* 2. Filtro por Ámbito / Lente */}
      <div className="space-y-2">
        <label className="flex items-center space-x-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <Filter className="w-3.5 h-3.5 text-indigo-500" />
          <span>Filtrar por Ámbito de Gasto</span>
        </label>
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-center">
          <button
            type="button"
            onClick={() => setLens('all')}
            className={`py-1.5 rounded-xl transition-all ${
              lens === 'all'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Todos
          </button>
          <button
            type="button"
            onClick={() => setLens('personal')}
            className={`py-1.5 rounded-xl transition-all ${
              lens === 'personal'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Personal
          </button>
          <button
            type="button"
            onClick={() => setLens('couple')}
            className={`py-1.5 rounded-xl transition-all ${
              lens === 'couple'
                ? 'bg-white dark:bg-slate-800 text-pink-600 dark:text-pink-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Pareja
          </button>
          <button
            type="button"
            onClick={() => setLens('group')}
            className={`py-1.5 rounded-xl transition-all ${
              lens === 'group'
                ? 'bg-white dark:bg-slate-800 text-cyan-600 dark:text-cyan-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Grupos
          </button>
        </div>
      </div>

      {/* 3. Tarjeta de Métricas en Vivo & Vista Previa Interactiva */}
      <div className="p-4 bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/90 dark:border-slate-800/90 rounded-2xl space-y-3.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center space-x-1.5">
            <PieChart className="w-4 h-4 text-indigo-600" />
            <span>Resumen Previsto del Período</span>
          </span>

          <button
            type="button"
            onClick={() => setIsPreviewModalOpen(true)}
            disabled={isLoadingSummary || !summaryData}
            className="flex items-center space-x-1 px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 rounded-xl text-[11px] font-bold transition-colors disabled:opacity-50"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Ver Vista Previa Completa</span>
          </button>
        </div>

        {/* Métricas rápidas */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          <div className="p-2.5 bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 rounded-xl">
            <span className="text-[10px] text-slate-400 font-bold block">Total Egresos</span>
            <span className="text-sm font-black text-slate-900 dark:text-white">
              {currency} {summaryData ? summaryData.summary.total_spent.toFixed(2) : '0.00'}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {summaryData?.summary.transaction_count || 0} movimientos
            </span>
          </div>

          <div className="p-2.5 bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 rounded-xl">
            <span className="text-[10px] text-slate-400 font-bold block">Promedio Diario</span>
            <span className="text-sm font-black text-slate-900 dark:text-white">
              {currency} {summaryData ? summaryData.summary.daily_average.toFixed(2) : '0.00'}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              En {summaryData?.summary.days_in_period || 1} días
            </span>
          </div>

          <div className="col-span-2 sm:col-span-1 p-2.5 bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 rounded-xl">
            <span className="text-[10px] text-slate-400 font-bold block">Categoría Top</span>
            <span className="text-xs font-bold text-slate-900 dark:text-white truncate block">
              {summaryData?.categories_breakdown[0]?.name || 'Sin registros'}
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold block mt-0.5">
              {summaryData?.categories_breakdown[0]
                ? `${currency} ${summaryData.categories_breakdown[0].total.toFixed(2)} (${summaryData.categories_breakdown[0].percentage}%)`
                : '-'}
            </span>
          </div>
        </div>

        {/* Barras de desglose rápido de categorías */}
        {summaryData && summaryData.categories_breakdown.length > 0 && (
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Top Categorías de impacto</span>
              <span>% del total</span>
            </div>
            <div className="space-y-1.5">
              {summaryData.categories_breakdown.slice(0, 3).map((cat) => (
                <div key={cat.name} className="space-y-0.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-slate-700 dark:text-slate-300 truncate max-w-[170px]">
                      {cat.name}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 font-mono">
                      {currency} {cat.total.toFixed(2)} ({cat.percentage}%)
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${Math.min(100, Math.max(4, cat.percentage))}%`,
                        backgroundColor: cat.color || '#6366F1',
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 4. Formatos de Exportación y Descarga */}
      <div className="space-y-2">
        <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
          Formatos Disponibles para Exportación
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {/* Opción PDF */}
          <button
            type="button"
            onClick={() => handleExport('pdf')}
            disabled={isExportingPdf || isExportingCsv || isExportingJson}
            className="p-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white rounded-2xl font-bold text-xs flex flex-col justify-between space-y-3 transition-all shadow-sm disabled:opacity-50 text-left"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 bg-white/20 rounded-xl">
                <FileText className="w-4 h-4 text-white" />
              </div>
              <span className="text-[10px] font-semibold bg-white/20 px-2 py-0.5 rounded-full">
                Oficial
              </span>
            </div>
            <div>
              <div className="text-xs font-black">Reporte PDF Membretado</div>
              <div className="text-[10px] text-indigo-100 font-normal mt-0.5">
                KPIs ejecutivos, gráficos y tabla auditada completa
              </div>
            </div>
            <div className="flex items-center space-x-1.5 text-[11px] font-bold text-indigo-200">
              {isExportingPdf ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generando PDF...</span>
                </>
              ) : (
                <>
                  <span>Descargar PDF</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </div>
          </button>

          {/* Opción CSV */}
          <button
            type="button"
            onClick={() => handleExport('csv')}
            disabled={isExportingPdf || isExportingCsv || isExportingJson}
            className="p-3.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/50 active:scale-[0.98] border border-emerald-200 dark:border-emerald-800/80 rounded-2xl font-bold text-xs flex flex-col justify-between space-y-3 transition-all disabled:opacity-50 text-left"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 bg-emerald-100 dark:bg-emerald-900/60 rounded-xl text-emerald-700 dark:text-emerald-300">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-100/80 dark:bg-emerald-900/60 px-2 py-0.5 rounded-full">
                Excel / Sheets
              </span>
            </div>
            <div>
              <div className="text-xs font-black text-slate-900 dark:text-white">Planilla Excel / CSV</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 font-normal mt-0.5">
                Columnas estructuradas, codificación universal UTF-8
              </div>
            </div>
            <div className="flex items-center space-x-1.5 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
              {isExportingCsv ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Exportando CSV...</span>
                </>
              ) : (
                <>
                  <span>Descargar CSV</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </div>
          </button>

          {/* Opción JSON */}
          <button
            type="button"
            onClick={() => handleExport('json')}
            disabled={isExportingPdf || isExportingCsv || isExportingJson}
            className="p-3.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/60 dark:hover:bg-slate-800 active:scale-[0.98] border border-slate-200 dark:border-slate-700/80 rounded-2xl font-bold text-xs flex flex-col justify-between space-y-3 transition-all disabled:opacity-50 text-left"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 bg-amber-100 dark:bg-amber-950/60 rounded-xl text-amber-700 dark:text-amber-300">
                <FileCode className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-semibold text-amber-700 dark:text-amber-300 bg-amber-100/80 dark:bg-amber-950/60 px-2 py-0.5 rounded-full">
                Backup Portátil
              </span>
            </div>
            <div>
              <div className="text-xs font-black text-slate-900 dark:text-white">Copia de Seguridad JSON</div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 font-normal mt-0.5">
                Exportación pura con metadatos para respaldo local
              </div>
            </div>
            <div className="flex items-center space-x-1.5 text-[11px] font-bold text-slate-700 dark:text-slate-300">
              {isExportingJson ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generando JSON...</span>
                </>
              ) : (
                <>
                  <span>Descargar JSON</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </div>
          </button>
        </div>
      </div>

      {/* Modal de Vista Previa Completa */}
      <ReportPreviewModal
        isOpen={isPreviewModalOpen}
        onClose={() => setIsPreviewModalOpen(false)}
        data={summaryData}
        onDownloadPdf={() => handleExport('pdf')}
        onDownloadCsv={() => handleExport('csv')}
        onDownloadJson={() => handleExport('json')}
        isDownloadingPdf={isExportingPdf}
        isDownloadingCsv={isExportingCsv}
        isDownloadingJson={isExportingJson}
      />
    </div>
  );
};
