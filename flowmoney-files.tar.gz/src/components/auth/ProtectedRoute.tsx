import React, { useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { LoginScreen } from './LoginScreen.tsx';
import { Loader2 } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { profile, firebaseUser, isLoading, isInitialized, initializeAuth, checkEmailLinkCallback } = useAuthStore();

  useEffect(() => {
    const unsubscribe = initializeAuth();
    // Revisar si la URL actual proviene de un magic link de correo
    checkEmailLinkCallback();
    return () => unsubscribe();
  }, [initializeAuth, checkEmailLinkCallback]);

  // Pantalla de carga mientras se verifica la sesión en Firebase y Cloud SQL
  if (isLoading && !isInitialized) {
    return (
      <div id="auth-loading-state" className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 p-6">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
            <span className="text-xl font-black tracking-tighter">FM</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-500 dark:text-slate-400 text-sm font-medium">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-600 dark:text-indigo-400" />
            <span>Verificando credenciales con FlowMoney...</span>
          </div>
        </div>
      </div>
    );
  }

  // Si no hay usuario autenticado ni perfil de Cloud SQL, mostrar pantalla de login
  if (!firebaseUser && !profile) {
    return <LoginScreen />;
  }

  return <>{children}</>;
};
