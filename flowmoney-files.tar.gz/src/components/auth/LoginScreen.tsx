import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore.ts';
import { Mail, ArrowRight, ShieldCheck, CheckCircle2, Sparkles, Moon, Sun, AlertCircle, X } from 'lucide-react';

export const LoginScreen: React.FC = () => {
  const { loginWithGoogle, sendEmailLink, loginAsDemoUser, isLoading, error, clearError } = useAuthStore();
  const [email, setEmail] = useState('');
  const [emailSent, setEmailSent] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => document.documentElement.classList.contains('dark'));

  useEffect(() => {
    if (error && (error.toLowerCase().includes('cloud sql') || error.includes('production'))) {
      clearError();
    }
  }, [error, clearError]);

  const toggleTheme = () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    if (next) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleGoogleLogin = async () => {
    clearError();
    try {
      await loginWithGoogle();
    } catch {
      // El error se guarda en useAuthStore
    }
  };

  const handleEmailLinkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return;
    clearError();
    try {
      await sendEmailLink(email.trim());
      setEmailSent(true);
    } catch {
      // El error se guarda en useAuthStore
    }
  };

  return (
    <div
      id="login-container"
      className="min-h-screen flex flex-col justify-between hero-gradient safe-area-top safe-area-bottom text-black dark:text-white transition-colors duration-300 px-6 sm:px-8"
      style={{ background: 'var(--ios-bg-primary)' }}
    >
      {/* Barra superior con selector de tema */}
      <header className="w-full max-w-md mx-auto flex items-center justify-between pt-4">
        <div className="flex items-center space-x-2.5">
          {/* SF Symbol-style icon: rounded square gradient */}
          <div
            className="w-8 h-8 rounded-[8px] flex items-center justify-center text-white font-bold text-[13px] tracking-tight"
            style={{
              background: 'linear-gradient(135deg, #007AFF 0%, #5856D6 100%)',
              boxShadow: '0 1px 3px rgba(0, 122, 255, 0.4), 0 2px 8px rgba(88, 86, 214, 0.25)'
            }}
          >
            FM
          </div>
          <span className="font-semibold tracking-tight text-[15px]" style={{ color: 'var(--ios-label)' }}>
            FlowMoney
          </span>
        </div>

        <button
          id="theme-toggle-btn"
          onClick={toggleTheme}
          className="p-2.5 rounded-full transition-all active:scale-90"
          style={{ color: 'var(--ios-label-secondary)' }}
          title="Alternar tema claro/oscuro"
          aria-label="Alternar tema"
        >
          {isDarkMode ? <Sun className="w-[18px] h-[18px]" /> : <Moon className="w-[18px] h-[18px]" />}
        </button>
      </header>

      {/* Contenedor central */}
      <main className="w-full max-w-md mx-auto my-auto py-8 animate-fade-in">
        {/* Hero — Apple-style large title */}
        <div className="mb-10">
          <h1
            className="text-[40px] sm:text-[44px] font-bold mb-3 tracking-tight"
            style={{ color: 'var(--ios-label)', letterSpacing: '-0.022em', lineHeight: 1.1 }}
          >
            Tu centro<br />financiero.
          </h1>
          <p
            className="text-[17px] leading-relaxed"
            style={{ color: 'var(--ios-label-secondary)', letterSpacing: '-0.01em' }}
          >
            Gastos personales, finanzas de pareja y división grupal en un solo lugar conectado.
          </p>
        </div>

        {/* Tarjeta de inicio de sesión — Apple elevated card */}
        <div
          className="rounded-[20px] p-7 sm:p-8 animate-slide-up"
          style={{
            background: 'var(--ios-bg-elevated)',
            boxShadow: 'var(--shadow-lg)',
            border: '0.5px solid var(--ios-separator)'
          }}
        >
          {error && !error.toLowerCase().includes('cloud sql') && (
            <div
              id="login-error-alert"
              className="mb-5 p-3.5 rounded-[12px] flex items-start justify-between space-x-2"
              style={{
                background: 'rgba(255, 59, 48, 0.08)',
                border: '0.5px solid rgba(255, 59, 48, 0.2)'
              }}
            >
              <div className="flex items-start space-x-2.5 flex-1">
                <AlertCircle className="w-[18px] h-[18px] flex-shrink-0 mt-0.5" style={{ color: 'var(--ios-red)' }} />
                <span className="flex-1 text-[13px] leading-relaxed" style={{ color: 'var(--ios-label)' }}>
                  {error}
                </span>
              </div>
              <button
                type="button"
                onClick={clearError}
                className="p-1 rounded-md transition-colors active:scale-90"
                style={{ color: 'var(--ios-label-secondary)' }}
                aria-label="Cerrar"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {emailSent ? (
            <div id="email-sent-card" className="text-center py-3 space-y-4 animate-scale-in">
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center mx-auto"
                style={{
                  background: 'rgba(52, 199, 89, 0.12)',
                  color: 'var(--ios-green)'
                }}
              >
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-[19px] font-semibold mb-1.5" style={{ color: 'var(--ios-label)' }}>
                  Enlace de acceso enviado
                </h2>
                <p className="text-[14px] leading-relaxed" style={{ color: 'var(--ios-label-secondary)' }}>
                  Revisa tu bandeja en{' '}
                  <span className="font-semibold" style={{ color: 'var(--ios-label)' }}>{email}</span>{' '}
                  y haz clic en el enlace para entrar sin contraseña.
                </p>
              </div>
              <button
                id="reset-email-form-btn"
                onClick={() => setEmailSent(false)}
                className="text-[14px] font-medium transition-colors"
                style={{ color: 'var(--ios-blue)' }}
              >
                Volver a ingresar otro correo
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {/* Botón Google — Apple secondary button style */}
              <button
                id="google-login-btn"
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoading}
                className="w-full flex items-center justify-center space-x-3 px-5 py-[14px] rounded-[14px] font-medium text-[15px] transition-all active:scale-[0.98] disabled:opacity-50"
                style={{
                  background: 'rgba(120, 120, 128, 0.12)',
                  color: 'var(--ios-label)',
                  letterSpacing: '-0.01em'
                }}
              >
                <svg className="w-[18px] h-[18px] flex-shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>Continuar con Google</span>
              </button>

              {/* Separador Apple-style */}
              <div className="flex items-center my-4">
                <div className="flex-grow h-px" style={{ background: 'var(--ios-separator)' }} />
                <span
                  className="px-3 text-[11px] uppercase tracking-wider font-medium"
                  style={{ color: 'var(--ios-label-tertiary)' }}
                >
                  o con correo
                </span>
                <div className="flex-grow h-px" style={{ background: 'var(--ios-separator)' }} />
              </div>

              {/* Formulario Email Link */}
              <form onSubmit={handleEmailLinkSubmit} className="space-y-3">
                <div className="relative">
                  <Mail
                    className="w-[18px] h-[18px] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
                    style={{ color: 'var(--ios-label-tertiary)' }}
                  />
                  <input
                    id="email-input"
                    type="email"
                    required
                    placeholder="nombre@ejemplo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-11 pr-4 py-[14px] rounded-[12px] text-[16px] transition-all focus:outline-none"
                    style={{
                      background: 'var(--ios-bg-tertiary)',
                      border: '0.5px solid var(--ios-separator)',
                      color: 'var(--ios-label)',
                      letterSpacing: '-0.01em'
                    }}
                  />
                </div>

                <button
                  id="send-email-link-btn"
                  type="submit"
                  disabled={isLoading || !email.trim()}
                  className="w-full flex items-center justify-center space-x-2 px-5 py-[14px] rounded-[14px] font-medium text-[15px] text-white transition-all active:scale-[0.98] disabled:opacity-50"
                  style={{
                    background: 'var(--ios-blue)',
                    boxShadow: '0 1px 2px rgba(0, 122, 255, 0.3), 0 4px 12px rgba(0, 122, 255, 0.18)',
                    letterSpacing: '-0.01em'
                  }}
                >
                  <span>Enviar enlace mágico</span>
                  <ArrowRight className="w-[18px] h-[18px]" />
                </button>
              </form>
            </div>
          )}

          {/* Modo Demo */}
          {(!import.meta.env.PROD || import.meta.env.VITE_ALLOW_DEMO_AUTH === 'true') && (
            <div className="mt-6 pt-5" style={{ borderTop: '0.5px solid var(--ios-separator)' }}>
              <p className="text-[12px] text-center mb-2.5" style={{ color: 'var(--ios-label-secondary)' }}>
                ¿Deseas probar la plataforma antes de iniciar sesión?
              </p>
              <button
                id="demo-login-btn"
                type="button"
                onClick={() => loginAsDemoUser('demo_carlos_flow', 'Carlos Sandoval')}
                disabled={isLoading}
                className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 rounded-[12px] text-[13px] font-medium transition-all active:scale-[0.98]"
                style={{
                  background: 'rgba(175, 82, 222, 0.10)',
                  color: 'var(--ios-purple)'
                }}
              >
                <Sparkles className="w-4 h-4" />
                <span>Explorar en Modo Demo (Carlos Sandoval)</span>
              </button>
            </div>
          )}
        </div>

        {/* Garantías de seguridad */}
        <div
          className="mt-6 flex items-center justify-center space-x-2 text-[12px]"
          style={{ color: 'var(--ios-label-secondary)' }}
        >
          <ShieldCheck className="w-[14px] h-[14px]" style={{ color: 'var(--ios-green)' }} />
          <span>Acceso seguro y encriptado</span>
        </div>
      </main>

      {/* Footer minimal */}
      <footer className="w-full max-w-md mx-auto py-4 text-center">
        <p className="text-[11px]" style={{ color: 'var(--ios-label-tertiary)' }}>
          FlowMoney · Hecho con Gemini AI
        </p>
      </footer>
    </div>
  );
};
