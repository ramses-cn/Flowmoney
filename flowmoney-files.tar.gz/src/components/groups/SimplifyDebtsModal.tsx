import React from 'react';
import { SimplifiedDebt } from '../../types/flowmoney.ts';
import { X, Sparkles, ArrowRight, CheckCircle2, HandCoins } from 'lucide-react';

interface SimplifyDebtsModalProps {
  isOpen: boolean;
  onClose: () => void;
  debts: SimplifiedDebt[];
  currency: string;
  isLoading: boolean;
  onSettleDebt: (debt: SimplifiedDebt) => void;
}

export const SimplifyDebtsModal: React.FC<SimplifyDebtsModalProps> = ({
  isOpen,
  onClose,
  debts,
  currency,
  isLoading,
  onSettleDebt,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Simplificación de Deudas
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Algoritmo determinista para minimizar el número de transferencias
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="py-12 text-center text-xs text-slate-400 space-y-2">
            <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
            <p>Calculando transferencias óptimas...</p>
          </div>
        ) : debts.length === 0 ? (
          <div className="py-10 text-center space-y-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700/60 p-6">
            <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              ¡Cuentas saldadas!
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
              No hay deudas pendientes entre los miembros del grupo. Todos los balances están compensados.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">
              {debts.length} {debts.length === 1 ? 'Transferencia sugerida' : 'Transferencias sugeridas'}
            </div>

            <div className="space-y-2.5">
              {debts.map((debt, index) => (
                <div
                  key={`${debt.debtor_id}-${debt.creditor_id}-${index}`}
                  className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 rounded-2xl space-y-2.5 hover:border-indigo-300 dark:hover:border-indigo-800/70 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    {/* Deudor -> Flecha -> Acreedor */}
                    <div className="flex items-center space-x-2 truncate max-w-[70%]">
                      <span className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                        {debt.debtor_name}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                        {debt.creditor_name}
                      </span>
                    </div>

                    {/* Monto */}
                    <div className="text-right">
                      <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                        {debt.currency || currency} {Number(debt.amount).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Botón Saldar individual */}
                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => {
                        onClose();
                        onSettleDebt(debt);
                      }}
                      className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
                    >
                      <HandCoins className="w-3.5 h-3.5" />
                      <span>Saldar esta deuda</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-2.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
