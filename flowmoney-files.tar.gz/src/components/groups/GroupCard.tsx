import React from 'react';
import { Group } from '../../types/flowmoney.ts';
import { Users, ChevronRight, Calendar, ArrowUpRight, ArrowDownLeft, CheckCircle2 } from 'lucide-react';

interface GroupCardProps {
  group: Group;
  currentUserId?: string;
  onClick: () => void;
}

export const GroupCard: React.FC<GroupCardProps> = ({ group, onClick }) => {
  const net = Number(group.net_balance ?? 0);
  const isPositive = net > 0.01;
  const isNegative = net < -0.01;
  const isSettled = !isPositive && !isNegative;

  // Portadas temáticas o personalizadas
  const defaultCovers: Record<string, string> = {
    couple: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&auto=format&fit=crop&q=80',
    trip: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&auto=format&fit=crop&q=80',
    home: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600&auto=format&fit=crop&q=80',
    project: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&auto=format&fit=crop&q=80',
    other: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?w=600&auto=format&fit=crop&q=80',
  };

  const coverImage = group.cover_url || defaultCovers[group.type] || defaultCovers.other;

  const typeLabels: Record<string, string> = {
    couple: 'Pareja',
    trip: 'Viaje',
    home: 'Hogar',
    project: 'Proyecto',
    other: 'Grupo',
  };

  const formattedDate = (dateStr?: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
  };

  return (
    <div
      id={`group-card-${group.id}`}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
      className="group relative overflow-hidden bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer text-left focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
    >
      {/* Portada con overlay */}
      <div className="relative h-28 w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img
          src={coverImage}
          alt={group.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent" />

        {/* Badge tipo & badge miembros */}
        <div className="absolute top-3 left-3 flex items-center space-x-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-white/90 dark:bg-slate-900/90 text-slate-800 dark:text-slate-100 backdrop-blur-md shadow-sm">
            {typeLabels[group.type] || group.type}
          </span>
          {group.user_role === 'admin' && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/90 text-white backdrop-blur-md">
              Admin
            </span>
          )}
        </div>

        <div className="absolute top-3 right-3 flex items-center space-x-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-950/60 text-white backdrop-blur-md">
          <Users className="w-3 h-3" />
          <span>{group.members_count ?? 1}</span>
        </div>

        {/* Nombre sobre el gradiente */}
        <div className="absolute bottom-2.5 left-3 right-3">
          <h3 className="text-base font-bold text-white drop-shadow-sm truncate">
            {group.name}
          </h3>
        </div>
      </div>

      {/* Contenido inferior */}
      <div className="p-4 space-y-3">
        {/* Saldo neto con estado cromático estricto */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Tu balance
          </span>

          <div className="flex items-center space-x-1.5 font-bold text-sm">
            {isPositive && (
              <span className="inline-flex items-center text-emerald-600 dark:text-emerald-400">
                <ArrowDownLeft className="w-3.5 h-3.5 mr-0.5" />
                Te deben {group.currency} {net.toFixed(2)}
              </span>
            )}
            {isNegative && (
              <span className="inline-flex items-center text-rose-600 dark:text-rose-400">
                <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                Debes {group.currency} {Math.abs(net).toFixed(2)}
              </span>
            )}
            {isSettled && (
              <span className="inline-flex items-center text-slate-500 dark:text-slate-400 font-semibold text-xs">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-slate-400" />
                En paz (0.00 {group.currency})
              </span>
            )}
          </div>
        </div>

        {/* Divisor */}
        <div className="h-px bg-slate-100 dark:bg-slate-800" />

        {/* Último gasto registrado */}
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center space-x-1.5 truncate max-w-[85%]">
            <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            {group.last_expense ? (
              <span className="truncate">
                Último:{' '}
                <strong className="text-slate-700 dark:text-slate-200 font-medium">
                  {group.last_expense.description}
                </strong>{' '}
                ({group.last_expense.currency || group.currency} {Number(group.last_expense.amount).toFixed(2)}) &bull;{' '}
                {formattedDate(group.last_expense.expense_date)}
              </span>
            ) : (
              <span className="text-slate-400 italic">Sin gastos registrados</span>
            )}
          </div>

          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 group-hover:translate-x-0.5 transition-all shrink-0" />
        </div>
      </div>
    </div>
  );
};
