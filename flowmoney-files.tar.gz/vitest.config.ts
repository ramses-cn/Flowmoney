import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['server/tests/**/*.test.ts', 'src/**/*.test.{ts,tsx}'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html'],
      include: ['server/**/*.ts', 'src/**/*.{ts,tsx}'],
      exclude: ['**/*.test.*', '**/node_modules/**'],
    },
  },
  resolve: {
    alias: {
      // Alias para imports con .ts en runtime (tsx-style)
      'src': '/src',
    },
  },
});
